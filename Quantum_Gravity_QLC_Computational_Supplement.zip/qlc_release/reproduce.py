"""Run source consistency, the full exact counting chain and worked example."""
from pathlib import Path
import argparse,json,os,subprocess,sys,time
from check_consistency import check,require,sha

ROOT=Path(__file__).resolve().parent

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--workers',type=int,choices=range(1,5),default=1)
    args=p.parse_args()
    out=args.output.resolve()
    require(not out.exists(),'complete replay output must be new')
    require(not out.is_relative_to(ROOT),'complete replay output must be outside package')
    consistency=check()
    out.mkdir(parents=True)
    (out/'consistency.json').write_text(json.dumps(consistency,indent=2,sort_keys=True)+'\n')
    start=time.monotonic()
    report={'status':'RUNNING','schema':'qlc-complete-synchronized-replay-1',
            'source_consistency':'PASS','source_manifest_sha256':sha(ROOT/'synchronization.json')}
    receipt=out/'RESULT.json'
    receipt.write_text(json.dumps(report,indent=2)+'\n')
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
    try:
        subprocess.run([sys.executable,'-B',str(ROOT/'verify.py'),'--output',str(out/'counting'),
                        '--workers',str(args.workers)],check=True,cwd=ROOT,env=env)
        example_out=out/'worked_example'
        env['QLC_WORKED_OUTPUT_DIR']=str(example_out)
        with (out/'worked_example.log').open('wb') as log:
            subprocess.run([sys.executable,'-B',str(ROOT/'examples/worked_connection/replay_worked_example.py')],
                           check=True,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
        counting=json.loads((out/'counting/RESULT.json').read_text())
        example=json.loads((example_out/'worked_example_results.json').read_text())
        require(counting['status']=='PASS','counting chain did not pass')
        require(example['source_binding']['manifest_sha256']==sha(ROOT/'examples/worked_connection/source_binding.json'),
                'worked example source binding differs')
        require(check()==consistency,'source changed during complete replay')
        report.update(status='PASS',fresh_normal_jobs=len(counting['jobs']['normal']),
                      fresh_optimized_jobs=len(counting['jobs']['optimized']),
                      equal_mathematical_result_pairs=len(counting['normal_optimized_mathematical_results_equal']),
                      counting_result_sha256=sha(out/'counting/RESULT.json'),
                      worked_example_result_sha256=sha(example_out/'worked_example_results.json'),
                      worked_example_freshly_replayed=True,all_sources_unchanged=True,
                      elapsed_seconds=round(time.monotonic()-start,3))
    except BaseException as exc:
        report.update(status='FAIL',error=str(exc),elapsed_seconds=round(time.monotonic()-start,3))
        receipt.write_text(json.dumps(report,indent=2)+'\n')
        raise
    receipt.write_text(json.dumps(report,indent=2)+'\n')
    print('PASS synchronized sources, complete counting chain and fresh worked example',flush=True)

if __name__=='__main__': main()
