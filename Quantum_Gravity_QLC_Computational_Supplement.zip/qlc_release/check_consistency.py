"""Read-only audit of complete shared prose, references and package paths."""
from pathlib import Path
import argparse,hashlib,json,re

ROOT=Path(__file__).resolve().parent
REGIONS={
 'counting':('% BEGIN SHARED COUNTING EXPOSITION\n','% END SHARED COUNTING EXPOSITION\n'),
 'consequences':('% BEGIN SHARED GEOMETRIC CONSEQUENCES\n','% END SHARED GEOMETRIC CONSEQUENCES\n'),
 'aw_comparison':('% BEGIN SHARED AW COMPARISON\n','% END SHARED AW COMPARISON\n')}
GENERATED={'RESULT.json','counting/RESULT.json','REPRODUCTION_RESULTS.md',
           'evidence/replay/consistency.json','evidence/replay/counting/RESULT.json'}

def require(ok,message):
    if not ok: raise RuntimeError(message)

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def region(text,pair):
    a,b=pair
    require(text.count(a)==text.count(b)==1,'shared-region markers must be unique')
    return text.split(a,1)[1].split(b,1)[0]

def check(root=ROOT):
    root=Path(root).resolve()
    manifest=json.loads((root/'synchronization.json').read_text())
    require(manifest['schema']=='qlc-source-synchronization-1','synchronization schema')
    for rel,h in manifest['source_files_sha256'].items():
        p=root/rel
        require(p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(root),'internal regular source: '+rel)
        require(sha(p)==h,'release source changed: '+rel)
    texts={name:(root/name).read_text() for name in ['manuscript.tex','supplement.tex']}
    shared={}
    for name,pair in REGIONS.items():
        a,b=[region(t,pair) for t in texts.values()]
        require(a==b,'complete shared exposition differs: '+name)
        h=hashlib.sha256(a.encode()).hexdigest()
        require(h==manifest['shared_regions'][name]['sha256'],'shared-region source binding: '+name)
        shared[name]={'sha256':h,'lines':len(a.splitlines()),'byte_identical':True}
    require(shared['counting']['lines']>2500,'complete counting exposition required')
    references={}
    for name,t in texts.items():
        labels=re.findall(r'\\label\{([^}]+)\}',t)
        refs=re.findall(r'\\(?:ref|eqref)\{([^}]+)\}',t)
        require(len(labels)==len(set(labels)),'duplicate equation/theorem label: '+name)
        require(set(refs)<=set(labels),'unresolved references: '+name+str(sorted(set(refs)-set(labels))))
        citations={x for row in re.findall(r'\\cite(?:\[[^\]]*\])?\{([^}]+)\}',t) for x in row.split(',')}
        bib=set(re.findall(r'\\bibitem\{([^}]+)\}',t))
        require(citations<=bib,'unresolved bibliography: '+name)
        require('theory/count_proof.tex' not in t,'obsolete proof path: '+name)
        require('short guide' not in t.lower() and 'six-page guide' not in t.lower(),'obsolete supplement description: '+name)
        require(r'T_0=-P_T|_{q_*}' not in t,'ambiguous old top-polynomial convention: '+name)
        paths={}
        for rel in sorted(set(re.findall(r'\\path\{([^}]+)\}',t))):
            if rel in GENERATED:
                paths[rel]='generated execution/report output'
                continue
            candidates=[root/rel]
            if '/' not in rel:
                candidates.extend([root/'audit'/rel,root/'certificates/centre'/rel])
            p=next((p for p in candidates if p.exists()),None)
            require(p is not None,'missing cited package path: '+name+': '+rel)
            require(p.resolve().is_relative_to(root),'external cited package path: '+rel)
            paths[rel]=p.relative_to(root).as_posix()
        references[name]={'labels':len(labels),'reference_occurrences':len(refs),'unresolved':[],
                          'cited_package_paths':paths}
    required_example=['README.md','pilot.py','replay_worked_example.py','source_binding.json']
    require(all((root/'examples/worked_connection'/n).is_file() for n in required_example),'incomplete worked example')
    require(not any(p.suffix in ['.zip','.tar','.gz'] for p in root.rglob('*') if p.is_file()),'nested archive')
    return {'status':'PASS','schema':'qlc-complete-source-consistency-1','shared_regions':shared,
            'comparison':'Complete literal shared text, including all intervening prose and equations; no whitespace normalization.',
            'documents':references,'worked_example_portable_files_present':True,'nested_archives':0}

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    result=check()
    text=json.dumps(result,indent=2,sort_keys=True)+'\n'
    if args.output:
        require(not args.output.exists(),'consistency output must be new')
        args.output.write_text(text)
    print(text,end='')
