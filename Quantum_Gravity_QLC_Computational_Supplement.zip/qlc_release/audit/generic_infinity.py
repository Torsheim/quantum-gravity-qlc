#!/usr/bin/env python3
"""Exact moving-base source support and proper-boundary verification.

Global coefficients, continuous pole cones, endpoint colon identities and
six signed resultant eliminations are reconstructed using exact arithmetic."""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
from pathlib import Path

import sympy as s
from sympy.polys.rings import ring
from sympy.polys.domains import ZZ

P = 65537
U = s.symbols('u1 u2 u3 m')
qs = s.symbols('q1 q2 q3')
t, M = s.symbols('t M')


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def sparse_payload(poly, modulus=None):
    return [[list(mon), int(c) if modulus is None else int(c) % modulus]
            for mon, c in sorted(poly.items(), reverse=True) if c]


def parse_poly(path, variables):
    return s.Poly(s.sympify(path.read_text(), locals={str(v): v for v in variables}),
                  *variables, domain=s.ZZ)


def source_binding(reference):
    rr, x, y, z, mm, a, b, c = ring('u1,u2,u3,m,q1,q2,q3', ZZ)
    us, qv = (x, y, z), (a, b, c)
    alpha = [q-(u-1)**2 for u, q in zip(us, qv)]
    beta = [q+u-1 for u, q in zip(us, qv)]
    A = b*alpha[0]*y**2+a*alpha[1]*x**2
    B = c*alpha[1]*z**2+b*alpha[2]*y**2
    z12, z23 = b*alpha[0]+a*alpha[1], c*alpha[1]+b*alpha[2]
    Q = a*b*c
    globals_ = {
        'PH4': A*B+4*Q*alpha[1]*x*y**2*z,
        'PL4': A*B*mm+y*z*z23*A+x*y*z12*B,
        'FT4': Q*mm**2+b*c*alpha[0]+a*c*alpha[1]+a*b*alpha[2]-Q,
    }
    hv = s.symbols('x1 x2 x3 y1 y2 y3 m')
    h = parse_poly(reference/'triangle_H.txt', hv)
    tri = rr.zero
    local_cache = {}
    for exps, coeff in h.terms():
        term = rr.ground_new(int(coeff))
        for i in range(3):
            ai, bi = exps[i], exps[i+3]
            require(bi-ai+4 >= 0 and 4-bi >= 0, 'triangle clearing denominator')
            key = i, ai, bi
            if key not in local_cache:
                local_cache[key] = alpha[i]**ai*beta[i]**(bi-ai+4)*qv[i]**(4-bi)
            term *= local_cache[key]
        term *= mm**exps[6]
        tri += term
    globals_['PTH4'] = tri
    source, report = {}, {}
    qstar = (4, 9, 49)
    expected_counts = {'PH4': 23, 'PL4': 55, 'FT4': 8, 'PTH4': 1198}
    for name, globalpoly in globals_.items():
        coefficients = {}
        global_support = set()
        for mon, coeff in globalpoly.items():
            core, qpow = mon[:4], mon[4:]
            global_support.add(core)
            coefficients[core] = coefficients.get(core, 0) + int(coeff)*s.prod(q**e for q,e in zip(qstar,qpow))
        coefficients = {mon: int(c) for mon,c in coefficients.items() if c}
        frozen = parse_poly(reference/(name+'.txt'), U).as_dict()
        require(set(coefficients) == global_support == set(frozen), name+' global support mismatch')
        require(len(frozen) == expected_counts[name], name+' unexpected count')
        first = next(iter(frozen))
        ratio = s.Rational(coefficients[first], frozen[first])
        require(ratio != 0 and all(coefficients[k] == ratio*v for k,v in frozen.items()), name+' scalar binding')
        require(int(s.numer(ratio)) % P != 0 and int(s.denom(ratio)) % P != 0, name+' scalar nonunit')
        require(all(c % P for c in coefficients.values()), name+' moving-base coefficient vanishes')
        source[name] = s.Poly.from_dict(frozen, U, domain=s.ZZ)
        report[name] = {'global_integer_terms': len(globalpoly), 'global_u_m_support': len(global_support),
                        'all_global_coefficients_specialize_to_units': True,
                        'global_over_frozen_scalar': str(ratio), 'frozen_sha256': digest(reference/(name+'.txt'))}
    return source, report, globals_


def expression_face(poly, positive, include_m=False):
    terms = poly.as_dict()
    if not include_m:
        terms = {mon:c for mon,c in terms.items() if mon[3] == 0}
    maxima = tuple(max(mon[i] for mon in terms) for i in positive)
    selected = {mon:c for mon,c in terms.items() if tuple(mon[i] for i in positive) == maxima}
    require(bool(selected), 'no common exponent maximum')
    return maxima, s.Poly.from_dict(selected, U, domain=s.ZZ).as_expr()


def cone_checks(source):
    x,y,z,mm = U
    ph, th, ft = (source[n] for n in ('PH4','PTH4','FT4'))
    max3, face3 = expression_face(ph, (0,1,2))
    require(max3 == (2,4,2) and face3 == 377*x**2*y**4*z**2, 'all positive face')
    expected = {
        (1,2): (29*y**4*z**2*(13*x**2-18*x-27), 1377894400*y**8*z**8*(x+3)**4, x, -3),
        (0,2): (x**2*z**2*(13*y**2-8*y-32)*(29*y**2-49*y-196), 37320444225*x**8*z**8*(y+8)**4, y, -8),
        (0,1): (13*x**2*y**4*(29*z**2-9*z-216), 24356284225*x**8*y**8*(z+48)**4, z, -48),
    }
    free = [mon for mon in th.monoms() if mon[3] == 0]
    linear = [mon for mon in th.monoms() if mon[3] == 1]
    require(len(linear) == 501 and set(th.degree_list()[3:]) == {1}, 'triangle m degree')
    pairs = []
    for ij,(p_expected,h_expected,finite,forced) in expected.items():
        _, pface = expression_face(ph, ij)
        tmax, hface = expression_face(th, ij)
        require(s.expand(pface-p_expected) == 0 and s.expand(hface-h_expected) == 0, 'two pole faces')
        require(tmax == (8,8), 'triangle joint maxima')
        require(all(mon[ij[0]] <= 7 and mon[ij[1]] <= 7 for mon in linear), 'continuous m margin')
        require(all(mon[ij[0]] <= 8 and mon[ij[1]] <= 8 for mon in free), 'continuous free margin')
        monomial_removed = pface.subs({U[i]:1 for i in ij})
        residual = int(monomial_removed.subs(finite, forced)) % P
        require(residual != 0, 'finite root contradiction')
        constant = int(hface.subs({U[i]:1 for i in ij}).coeff(finite,4)) % P
        require(constant != 0, 'triangle face coefficient unit')
        pairs.append({'positive_coordinates':[str(U[i]) for i in ij], 'PH_face':str(s.factor(pface)),
                      'PTH_face':str(s.factor(hface)), 'forced_finite_value':forced,
                      'full_PH_residual_mod_p':residual, 'm_linear_terms_checked':len(linear),
                      'margin_lower_bound':'min(r_i,r_j)>0 using r_m<=max(r_i,r_j)'})
    leading = {mon:int(c)%P for mon,c in ft.terms() if sum(mon) == 2}
    require(leading == {(2,0,0,0):441, (0,2,0,0):196, (0,0,2,0):36, (0,0,0,2):(-1764)%P}, 'top equation')
    return {'all_positive_face':str(face3), 'quadratic_top_terms':sparse_payload(leading),
            'two_pole_cases':pairs, 'all_real_nonnegative_rate_cones_covered':True}


# Polynomial arithmetic in F_p[b], ascending coefficient order.
def trim(f):
    f=[int(c)%P for c in f]
    while f and f[-1] == 0: f.pop()
    return f


def add(f,g):
    h=[0]*max(len(f),len(g))
    for i,c in enumerate(f): h[i]+=c
    for i,c in enumerate(g): h[i]+=c
    return trim(h)


def mul(f,g):
    h=[0]*max(0,len(f)+len(g)-1)
    for i,c in enumerate(f):
        for j,d in enumerate(g): h[i+j]+=c*d
    return trim(h)


def divrem(f,g):
    f,g=trim(f),trim(g)
    require(bool(g),'division by zero')
    q=[0]*max(0,len(f)-len(g)+1)
    inv=pow(g[-1],-1,P)
    while len(f)>=len(g):
        k=len(f)-len(g); c=f[-1]*inv%P; q[k]=c
        for j,d in enumerate(g): f[k+j]=(f[k+j]-c*d)%P
        f=trim(f)
    return trim(q),f


def xgcd(f,g):
    f,g=trim(f),trim(g); a,b,c,d=[1],[],[],[1]
    while g:
        q,r=divrem(f,g)
        f,g=g,r
        a,c=c,add(a,[-v for v in mul(q,c)])
        b,d=d,add(b,[-v for v in mul(q,d)])
    require(bool(f),'zero gcd')
    inv=pow(f[-1],-1,P)
    return ([v*inv%P for v in f], [v*inv%P for v in a], [v*inv%P for v in b])


def determinant(matrix):
    matrix=[[int(x)%P for x in row] for row in matrix]
    n=len(matrix); det=1
    for col in range(n):
        k=next((j for j in range(col,n) if matrix[j][col]),None)
        if k is None:return 0
        if k!=col:
            matrix[col],matrix[k]=matrix[k],matrix[col];det=-det
        pivot=matrix[col][col];det=det*pivot%P;iv=pow(pivot,-1,P)
        for j in range(col+1,n):
            coeff=matrix[j][col]*iv%P
            if coeff:
                for i in range(col,n):matrix[j][i]=(matrix[j][i]-coeff*matrix[col][i])%P
    return det%P


def resultant_by_interpolation(f,g,a,b):
    f=s.Poly(f,a,b,modulus=P);g=s.Poly(g,a,b,modulus=P)
    n,k=int(f.degree(a)),int(g.degree(a))
    bound=n*int(g.degree(b))+k*int(f.degree(b))
    require(0 <= bound+1 < P, 'interpolation degree bound')
    def evaluate(poly,j,deg):
        coeff=[0]*(deg+1)
        for (e,v),c in poly.terms(): coeff[e]=(coeff[e]+int(c)*pow(j,v,P))%P
        return coeff[::-1]
    samples=[]
    for j in range(bound+1):
        ff,gg=evaluate(f,j,n),evaluate(g,j,k)
        rows=[]
        for shift in range(k):rows.append([0]*shift+ff+[0]*(k-shift-1))
        for shift in range(n):rows.append([0]*shift+gg+[0]*(n-shift-1))
        samples.append(determinant(rows))
    # Newton forward interpolation at consecutive residues, using binomial basis.
    differences=samples[:];coeffs=[]
    while differences:
        coeffs.append(differences[0]); differences=[(v-u)%P for u,v in zip(differences,differences[1:])]
    result=[];basis=[1]
    for j,c in enumerate(coeffs):
        result=add(result,[c*v for v in basis])
        basis=[v*pow(j+1,-1,P)%P for v in mul(basis,[-j,1])]
    for j,target in enumerate(samples):
        require(sum(c*pow(j,i,P) for i,c in enumerate(result))%P == target,'interpolation residual')
    return result, {'degree_bound':bound,'sylvester_matrix_size':n+k,'sample_count':bound+1}


def charts(source,global_polys):
    x,y,z,mm=U
    q1,q2,q3=qs
    # Independent symbolic polynomial expressions from the sparse ring.
    gp={name:s.Poly.from_dict(dict(poly),(*U,*qs),domain=s.ZZ).as_expr() for name,poly in global_polys.items() if name!='PTH4'}
    alpha=[q-(u-1)**2 for u,q in zip(U[:3],qs)]
    A=q2*alpha[0]*y**2+q1*alpha[1]*x**2
    B=q3*alpha[1]*z**2+q2*alpha[2]*y**2
    colon=[];signs=[]
    for idx,divisor in enumerate((2,3,7)):
        pole=U[idx];finite=[u for u in U[:3] if u!=pole]
        a,b=finite
        leading={}
        for name,poly in source.items():
            degree=max(mon[idx]+mon[3] for mon in poly.monoms())
            expr=s.Poly.from_dict({mon:c for mon,c in poly.terms() if mon[idx]+mon[3]==degree},U).as_expr()
            leading[name]=s.expand(expr.subs({pole:1,mm:M}))
        if idx in (0,2):
            E=B if idx==0 else A
            D=qs[idx]*alpha[1]-q2*y**2
            N=M*D-q2*y
            FH=s.Poly(s.expand(t**2*gp['PH4'].subs({pole:1/t,mm:M/t})),t,*finite,M,*qs,domain=s.ZZ)
            FL=s.Poly(s.expand(t**3*gp['PL4'].subs({pole:1/t,mm:M/t})),t,*finite,M,*qs,domain=s.ZZ)
            require(s.expand(FH.as_expr().subs(t,0)-E*D)==0,'global leading H')
            require(s.expand(FL.as_expr().subs(t,0)-E*N)==0,'global leading L')
            numerator=s.Poly(s.expand(D*FL.as_expr()-N*FH.as_expr()),*FH.gens,domain=s.ZZ)
            yindex=FH.gens.index(y)
            require(all(mon[0]>=1 and mon[yindex]>=1 for mon in numerator.monoms()),'t*u2 divisibility')
            kd={tuple(e-1 if i in (0,yindex) else e for i,e in enumerate(mon)):c for mon,c in numerator.terms()}
            K=s.Poly.from_dict(kd,FH.gens,domain=s.ZZ)
            require(s.expand(t*y*K.as_expr()-numerator.as_expr())==0,'global colon identity')
            require(len(K.terms()) == 269,'global K count')
            specialization=dict(zip(qs,(4,9,49)))
            E0=s.expand(E.subs(specialization))
            K0=s.expand(K.as_expr().subs(t,0).subs(specialization))
            colon.append({'chart':str(pole),'variables':list(map(str,FH.gens)),
                          'global_terms':len(K.terms()),'identity_exact_over_Zq':True,
                          'K':sparse_payload(K.as_dict()),
                          'equation':'t*u2*K=D*FL-N*FH',
                          'E_nonzero_branch_excluded': 'D=N=0 implies u2=0 and D=q_i*(q2-1)!=0'})
        for sign in (1,-1):
            root=sign*pow(divisor,-1,P)%P
            if idx in (0,2):
                sources=[(E0,K0.subs(M,root)),(E0,leading['PTH4'].subs(M,root))]
            else:
                sources=[(leading['PH4'].subs(M,root),leading[name].subs(M,root)) for name in ('PL4','PTH4')]
            resultants=[];metadata=[];payload=[]
            for f,g in sources:
                r,meta=resultant_by_interpolation(f,g,a,b)
                resultants.append(r);metadata.append(meta)
                payload.append({'variables':[str(a),str(b)],'left':sparse_payload(s.Poly(f,a,b,modulus=P).as_dict(),P),
                                'right':sparse_payload(s.Poly(g,a,b,modulus=P).as_dict(),P)})
            gcd,aa,bb=xgcd(*resultants)
            require(gcd==[1],'nonunit resultant gcd')
            require(add(mul(aa,resultants[0]),mul(bb,resultants[1])) == [1],'explicit Bezout identity')
            require([len(r)-1 for r in resultants] == ([8,32] if idx==1 else [18,32]),'resultant degrees')
            signs.append({'chart':str(pole),'sign':sign,'m_over_u_mod_p':root,
                          'resultant_degrees':[len(r)-1 for r in resultants],
                          'resultant_methods':metadata,'resultants_ascending':resultants,
                          'bezout_ascending':[aa,bb],'identity_is_one':True,'source_polynomials':payload})
    return colon,signs


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('subject',type=Path)
    parser.add_argument('output',type=Path)
    args=parser.parse_args()
    source,binding,gp=source_binding(args.subject/'reference')
    cones=cone_checks(source)
    colon,signs=charts(source,gp)
    report={'schema':'generic-proper-boundary-certificate-v1','status':'PASS','prime':P,
            'old_audit_code_imported':False,
            'moving_base_global_support_binding':binding,'continuous_pole_cones':cones,
            'global_endpoint_colon':colon,'six_signed_one_pole_eliminations':signs,
            'valuation_scope':{'base_may_move':True,'equal_and_mixed_characteristic':True,
                               'all_source_coefficients_are_units':True,
                               'DVR_uniformizer_power_sampled':False,
                               'finite_coordinates_may_reduce_to_zero':True},
            'conclusion':'Genuine source infinity is empty over the algebraic closure of F_65537, conditional only on the declared global family construction.'}
    args.output.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':'PASS','signed_cases':len(signs),'global_colon_identities':len(colon),'output':str(args.output)}))


if __name__=='__main__':main()
