#!/usr/bin/env python3
"""Recompute the generic-degree certificate from flat polynomial inputs.

This adapts existing exact computational proof implementations to one flat
data tree. Every mathematical job is actually executed. No stored PASS field,
nested archive, or earlier project module supplies an accepted conclusion.
The prose geometry (DVR traits, properness, and the Jacobian criterion) is
proved in the accompanying manuscript, not certified by this runner.
"""
from __future__ import annotations
import argparse
from concurrent.futures import ThreadPoolExecutor
import copy
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time

ROOT=Path(__file__).resolve().parents[1]
AUDIT=ROOT/'audit'
DATA=ROOT/'certificates/generic'
RESULT_NAMES=(
    'finite_chart_boundary.json','exceptional_lines.json',
    'exceptional_lines_standardlib.json','finite_projection.json',
    'projection_exclusion.json','finite_rur.json','support_reconstruction.json',
    'proper_boundary.json','graph_jacobian.json',
)

def require(condition,message):
    if not condition:raise RuntimeError(message)

def run_job(module,args,output):
    command=[sys.executable,'-B']+(['-O'] if sys.flags.optimize else [])
    command += [str(AUDIT/module),*[str(a) for a in args]]
    result=subprocess.run(command,text=True,capture_output=True)
    (output/(module+'.log')).write_text(result.stdout+result.stderr)
    require(result.returncode==0,module+' failed; see '+str(output/(module+'.log')))
    print(module+' completed',flush=True)

def line_rejections(output):
    spec=importlib.util.spec_from_file_location('generic_lines_standardlib',AUDIT/'generic_lines_standardlib.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    reference=json.loads((output/'exceptional_lines.json').read_text())
    attacks=[]
    wrong=copy.deepcopy(reference);wrong['line_screens'][0]['bezout_T'][0] ^= 1
    attacks.append(('false Bezout coefficient',wrong,'Bezout equals one'))
    wrong=copy.deepcopy(reference);wrong['line_screens'][-1]=copy.deepcopy(wrong['line_screens'][0])
    attacks.append(('duplicate exceptional line',wrong,'duplicate line'))
    result=[]
    with tempfile.TemporaryDirectory(prefix='generic_line_rejections_') as temporary:
        path=Path(temporary)/'altered.json'
        for name,data,expected in attacks:
            path.write_text(json.dumps(data))
            try:module.verify(DATA,path)
            except ValueError as error:
                require(expected in str(error),'wrong rejection reason for '+name)
                result.append({'mutation':name,'rejected_by':expected})
            else:raise RuntimeError('accepted mutation: '+name)
    return result

def execute(output):
    output=output.resolve()
    require(not output.exists(),'generic output directory must be fresh')
    output.mkdir(parents=True)
    # These duplicate views are intentionally joined by exact bytes here;
    # both mathematical reconstruction routes read the same global model.
    for name in ('EA','EB','E12','E13','E23','Hp','Lp','T','Htriangle'):
        require((DATA/'reference'/f'{name}.txt').read_bytes()==(DATA/'generated'/f'{name}.txt').read_bytes(),
                'different global model in the finite-chart and graph computations: '+name)
    start=time.monotonic()
    jobs=[
        ('generic_charts.py',[DATA,DATA,output/'finite_chart_boundary.json']),
        ('generic_exceptional.py',[DATA,DATA,output/'exceptional_lines.json']),
        ('generic_support.py',['--compact',DATA/'compact','--four',DATA/'reference','--output',output]),
        ('generic_infinity.py',[DATA,output/'proper_boundary.json']),
    ]
    with ThreadPoolExecutor(max_workers=int(os.environ.get('QLC_VERIFY_WORKERS','1'))) as executor:
        futures=[executor.submit(run_job,module,args,output) for module,args in jobs]
        for future in futures:future.result()
    run_job('generic_lines_standardlib.py',[DATA,output/'exceptional_lines.json',output/'exceptional_lines_standardlib.json'],output)
    run_job('generic_graph.py',[DATA,output,output/'graph_jacobian.json'],output)
    for name in RESULT_NAMES:
        result=json.loads((output/name).read_text())
        require(result.get('status')=='PASS','job failed: '+name)
    result={
        'schema':'flat-generic-degree-replay-v1','status':'PASS',
        'all_mathematical_jobs_freshly_executed':True,
        'optimization':sys.flags.optimize,'result_files':list(RESULT_NAMES),
        'stored_reference_results_used':False,
        'targeted_line_certificate_rejections':line_rejections(output),
        'elapsed_seconds':round(time.monotonic()-start,3),
        'scope':'exact arithmetic certificates for the generic-degree proof; geometric arguments remain the manuscript proof',
        'externally_independently_authored_peer_review_claimed':False,
    }
    (output/'generic_replay.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(json.dumps({'status':'PASS','result_files':len(RESULT_NAMES),'elapsed_seconds':result['elapsed_seconds']}),flush=True)
    return result

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args()
    execute(args.output)
