"""Independent ZZ sparse pseudo-division replay, no pdiv/division routine.
Usage: independent_sparse_audit.py SOURCE_419_DIR QUADRATIC_DIR OUTPUT_JSON [MINORS_DIR]
"""
from pathlib import Path
import sys,json,hashlib,itertools,ast
import sympy as s
u1,y,z,v=s.symbols('u1 u2 u3 v')
PIN={'Hp':'2d48d1e4adcb3953cb6c8346e967e26aee6643a8903fa1c655e0b5b7967d6555','F':'233a6b3b1e2463c1196ff8fea0042630fa1e14ff5af04d9e9e9976817f9e3adf','Htriangle':'f74b6763c65fe4c5de88528f2c3767e78e2813151874e7da8e21bf7bea018807'}
checks=[]
def need(ok,label):
 if not ok:raise RuntimeError(label)
 checks.append(label)
def parse(path,variables):
 text=path.read_text()
 if len(text)<1000:return {e:int(c)for e,c in s.Poly(s.sympify(text),*variables,domain=s.ZZ).terms()}
 indices={str(x):i for i,x in enumerate(variables)};zero=(0,)*len(variables)
 tree=ast.parse(text,mode='eval').body
 def decode(node):
  if isinstance(node,ast.Constant) and type(node.value)is int:return {zero:node.value} if node.value else {}
  if isinstance(node,ast.Name) and node.id in indices:
   ex=list(zero);ex[indices[node.id]]=1;return {tuple(ex):1}
  if isinstance(node,ast.UnaryOp) and isinstance(node.op,ast.USub):return {e:-c for e,c in decode(node.operand).items()}
  if isinstance(node,ast.BinOp) and isinstance(node.op,ast.Mult):return mul(decode(node.left),decode(node.right))
  if isinstance(node,ast.BinOp) and isinstance(node.op,ast.Pow) and isinstance(node.right,ast.Constant) and type(node.right.value)is int and node.right.value>=0:return power(decode(node.left),node.right.value)
  if isinstance(node,ast.BinOp) and isinstance(node.op,(ast.Add,ast.Sub)):
   stack=[(node,1)];out={}
   while stack:
    current,sign=stack.pop()
    if isinstance(current,ast.BinOp) and isinstance(current.op,(ast.Add,ast.Sub)):
     stack.extend([(current.left,sign),(current.right,sign if isinstance(current.op,ast.Add) else -sign)])
    else:
     for e,c in decode(current).items():out[e]=out.get(e,0)+sign*c
   return {e:c for e,c in out.items()if c}
  raise RuntimeError('Invalid polynomial AST input')
 return decode(tree)

def add(a,b,scale=1):
 out=a.copy()
 for e,c in b.items():
  out[e]=out.get(e,0)+scale*c
  if not out[e]:out.pop(e)
 return out
def mul(a,b):
 out={}
 for e,c in a.items():
  for f,d in b.items():
   k=tuple(x+y for x,y in zip(e,f));out[k]=out.get(k,0)+c*d
 return {e:c for e,c in out.items()if c}
def shift(a,k):return {(e[0]+k,*e[1:]):c for e,c in a.items()}
def power(a,n):
 out={(0,0,0):1}
 for _ in range(n):out=mul(out,a)
 return out
def coeff(a,k):return {(0,*e[1:]):c for e,c in a.items()if e[0]==k}
def expr(a):return sum(c*v**e[0]*y**e[1]*z**e[2]for e,c in a.items())
def degree(a):return max((e[0]for e in a),default=-1)
def payload(a):return [[list(e),c]for e,c in sorted(a.items())]
def digest(a):return hashlib.sha256(json.dumps(payload(a),separators=(',',':')).encode()).hexdigest()
if len(sys.argv) not in (4,5):raise SystemExit(__doc__)
source,quad,out=map(Path,sys.argv[1:4])
minors_dir=Path(sys.argv[4]) if len(sys.argv)==5 else None
sys.setrecursionlimit(max(sys.getrecursionlimit(),20000))
rev={};result={'schema':'point4.20-independent-sparse-integer-replay-v1','arithmetic':'Custom Python dict/int arithmetic for full integer identities and expanded minors; SymPy handles short expressions, content factorization, and generic symbolic matrix checks'}
for name,h in PIN.items():
 path=source/(name+'.txt');need(hashlib.sha256(path.read_bytes()).hexdigest()==h,'frozen source hash '+name)
 a=parse(path,(u1,y,z));n=max(e[0]for e in a);rev[name]={(n-e[0],*e[1:]):c for e,c in a.items()}
 need(rev[name]==parse(quad/(name+'_reversed.txt'),(v,y,z)),'exact coefficient reversal '+name)
f=rev['Hp'];A=coeff(f,2);C=coeff(f,1);D=coeff(f,0)
Bpoly=27*y*y*z*z-32*y*y*z+4*y*y-22*y*z*z-z*z
need(expr(A)==s.expand(-3*y*y*Bpoly),'leading coefficient old-unit support')
z2=1-s.Rational(11,12)*(y-1)**2;z3=1-s.Rational(4,3)*(z-1)**2
need(s.cancel(Bpoly+12*y*z*(z2*z/y+z3*y/z))==0,'D equals minus 12 u2 u3 B original')
need(s.expand(11*y*y-22*y-1+12*z2)==0,'J equals minus 12 z2')
need(expr(D)==s.expand(Bpoly*(20*y*y-22*y-1)),'quadratic constant coefficient')
J=11*y*y-22*y-1;E=3*Bpoly+8*z*J
need(expr(C)==s.expand(-6*y*y*E),'compact middle coefficient gives 2E/Bpoly')
need(s.cancel(expr(D)/expr(A)+(20*y*y-22*y-1)/(3*y*y))==0,'compact constant coefficient gives minus K/(3u2 squared)')
result['quadratic_coefficients']={name:digest(poly)for name,poly in [('A',A),('C',C),('D',D)]}
rows={};linears={}
for name in ['F','Htriangle']:
 g=rev[name];n=degree(g);r=g.copy();q={}
 for k in range(n,1,-1):
  ck=coeff(r,k);term=shift(ck,k-2)
  r=add(mul(A,r),mul(term,f),-1);q=add(mul(A,q),term)
  need(degree(r)<k,name+' independent cancellation degree '+str(k))
 need(add(mul(power(A,n-1),g),mul(q,f),-1)==r,name+' exact pseudo-division identity')
 need(q==parse(quad/(name+'_quotient.txt'),(v,y,z)),name+' supplied quotient equals independent quotient')
 cont=parse(quad/(name+'_content.txt'),(v,y,z));linear=parse(quad/(name+'_linear.txt'),(v,y,z))
 need(mul(cont,linear)==r,name+' supplied content times linear equals independent remainder')
 need(degree(linear)<=1,name+' supplied remainder linear')
 linears[name]=linear
 fact=s.factor_list(expr(cont),y,z)
 factors=[]
 # Every nonconstant content factor must be an old unit: u2, alpha2, Bpoly.
 accepted=[y,11*y*y-22*y-1,Bpoly]
 for fac,exp in fact[1]:
  matched=False
  for unit in accepted:
   ratio=s.cancel(fac/unit)
   if not ratio.free_symbols and ratio!=0:matched=True;break
  need(matched,name+' content factor supported on old unit '+str(fac))
  factors.append({'factor':str(fac),'exponent':int(exp)})
 rows[name]={'input_v_degree':n,'A_power':n-1,'remainder_terms':len(r),'linear_terms':len(linear),'content_factors':factors,'independent_remainder_sha256':digest(r),'independent_quotient_sha256':digest(q)}
# Independently bind the six primitive integer minors to the actual coefficients.
minor_rows={}
if minors_dir is not None:
 meta=json.loads((minors_dir/'minor_summary.json').read_text())['minors']
 rr,ss=coeff(linears['F'],1),coeff(linears['F'],0)
 tt,ww=coeff(linears['Htriangle'],1),coeff(linears['Htriangle'],0)
 cols=[(ss,rr),(mul(D,rr),add(mul(A,ss),mul(C,rr),-1)),(ww,tt),(mul(D,tt),add(mul(A,ww),mul(C,tt),-1))]
 cols[1]=({e:-c for e,c in cols[1][0].items()},cols[1][1]);cols[3]=({e:-c for e,c in cols[3][0].items()},cols[3][1])
 base_units={'u2':{(0,1,0):1},'u3':{(0,0,1):1},'J':{e:int(c)for e,c in s.Poly(J,v,y,z).terms()},'D':{e:int(c)for e,c in s.Poly(Bpoly,v,y,z).terms()}}
 for i,j in itertools.combinations(range(4),2):
  name=f'minor_{i+1}{j+1}';row=meta[name];raw=add(mul(cols[i][0],cols[j][1]),mul(cols[j][0],cols[i][1]),-1)
  prim=parse(minors_dir/(name+'.txt'),(v,y,z));factor={(0,0,0):1}
  for unit,exponent in row['unit_factors'].items():
   need(unit in base_units and type(exponent)is int and exponent>=0,name+' removed factor is existing unit '+unit)
   factor=mul(factor,power(base_units[unit],exponent))
  scalar=s.Rational(row['scalar']);need(scalar!=0 and scalar.q==1,name+' primitive integer scalar')
  rhs={e:c*int(scalar) for e,c in mul(factor,prim).items()}
  need(raw==rhs,name+' full exact reconstruction from matrix')
  need(row['degree']==max(sum(e)for e in prim) and row['multidegree']==[max(e[k]for e in prim)for k in (1,2)] and row['terms']==len(prim),name+' metadata')
  minor_rows[name]={'raw_sha256':digest(raw),'primitive_sha256':digest(prim),'terms':len(prim)}
# Companion-module presentation and Fitting generators checked symbolically.
b,c,r0,r1,s0,s1=s.symbols('b c r0 r1 s0 s1');w=s.symbols('w');Q=w*w+b*w+c
M=s.Matrix([[r0,-c*r1,s0,-c*s1],[r1,r0-b*r1,s1,s0-b*s1]])
for j,L in enumerate([r0+r1*w,w*(r0+r1*w),s0+s1*w,w*(s0+s1*w)]):
 need(s.rem(L,Q,w)==M[0,j]+M[1,j]*w,'companion multiplication column '+str(j))
minors=[s.expand(M[:,pair].det())for pair in itertools.combinations(range(4),2)]
expected=[r0*r0-b*r0*r1+c*r1*r1,r0*s1-r1*s0,r0*s0-b*r0*s1+c*r1*s1,-r0*s0+b*r1*s0-c*r1*s1,c*(r0*s1-r1*s0),s0*s0-b*s0*s1+c*s1*s1]
need(minors==list(map(s.expand,expected)),'all six signed companion minors')
result.update(status='PASS',source_sha256=PIN,remainders=rows,primitive_minor_reconstruction=minor_rows,companion_minors=list(map(str,minors)),checks=checks,check_count=len(checks),scope='Exact inverse-variable identities and finite-module presentation only. No complete fibre count or finite-etale assertion.')
out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':'PASS','check_count':len(checks),'output':str(out)}))
