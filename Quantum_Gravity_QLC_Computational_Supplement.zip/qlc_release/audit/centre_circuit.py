"""Flat, standalone finite-residue verification of the complete rational circuit.

The polynomial quotient kernel is centre_modular.py, included beside this
file. No historical folder, previous verdict or earlier evidence is read.
Characteristic-zero validity follows from the determinant/unit proofs in the
manuscript, not from modular equality alone.
"""
import hashlib
import itertools
import json
from pathlib import Path
import sys
import centre_modular as a

def need(b,m):
    if not b:raise ValueError(m)

def determinant(M,ring):
    n=len(M);need(n==6 and all(len(r)==n for r in M),'six-by-six determinant')
    value=ring(0)
    for perm in itertools.permutations(range(n)):
        factors=[M[i][perm[i]] for i in range(n)]
        if any(not x for x in factors):continue
        term=ring(1)
        for x in factors:term*=x
        inversions=sum(perm[i]>perm[j] for i in range(n) for j in range(i+1,n))
        value+=(-term if inversions%2 else term)
    return value

def original_residuals(data,values,ring):
    need(len(values)==13 and len(data['equations'])==10,'full original source inventory')
    result=[]
    for equation in data['equations']:
        value=ring(0)
        for t in equation['terms']:
            x=ring(int(t['coefficient']))
            need(len(t['exponents'])==13,'source exponents')
            for v,n in zip(values,t['exponents']):
                if n:x*=v**n
            value+=x
        result.append(value)
    return result

def run(data,output):
    names=['candidate_mod101.json','rational_circuit.json','u2_reconstruction.json',
           'source_equations.json','F_linear.txt','Hp.txt','F.txt','Htriangle.txt']
    raw={n:(data/n).read_bytes() for n in names}
    modular,circuit,u2,source=[json.loads(raw[n]) for n in names[:4]]
    need(modular['prime']==101 and len(modular['components'])==11,'all modular components')
    need(source['variable_order']==['u1','u2','u3','m','a','b','c','p','r','t','q1','q2','q3'],
         'full source variable order')
    linear=a.parse(raw['F_linear.txt'].decode().replace('v','u1'))
    for name,power,count in [('r_terms',1,157),('s_terms',0,173)]:
        expected=[[c,e[1],e[2]] for e,c in sorted(linear.items()) if e[0]==power]
        need(len(expected)==count and circuit[name]==expected,'literal linear remainder '+name)
    polys=[a.parse(raw[n].decode()) for n in ['Hp.txt','F.txt','Htriangle.txt']]
    records=[]
    for k,component in enumerate(modular['components']):
        ring=a.Ring(101,component['h']);env={};divisions=[]
        def univariate(cs,x):
            out=ring(0)
            for c in reversed(cs):out=out*x+c
            return out
        def ev(e):
            if type(e)is int:return ring(e)
            if type(e)is str:return env[e]
            need(type(e)is list and e,'literal expression')
            op,*args=e
            if op=='parameter':need(not args,'parameter arity');return ring([0,1])
            if op=='univariate':return univariate(u2[args[0]],ev(args[1]))
            if op=='bivariate':
                return a.evaluate({(0,i,j):c for c,i,j in circuit[args[0]]},[ring(0),ev(args[1]),ev(args[2])])
            if op=='det':return determinant([[ev(x) for x in row] for row in args[0]],ring)
            if op=='pow':need(type(args[1])is int and args[1]>=0,'power');return ev(args[0])**args[1]
            vals=[ev(x) for x in args]
            if op=='neg':need(len(vals)==1,'negation');return -vals[0]
            if op=='add':return sum(vals,ring(0))
            if op=='mul':
                v=ring(1)
                for x in vals:v*=x
                return v
            need(op=='div' and len(vals)==2,'division')
            need(vals[1].unit(),'every actual circuit denominator is a unit')
            inverse=ring(1)/vals[1];need(vals[1]*inverse==1,'explicit division inverse')
            divisions.append({'residue':list(vals[1].a) or [0],'inverse':list(inverse.a) or [0]})
            return vals[0]*inverse
        for name,expression in circuit['nodes_in_evaluation_order']:
            need(name not in env,'unique ordered circuit node');env[name]=ev(expression)
        need(len(env)==53 and len(divisions)==30,'complete53-node30-division circuit')
        for name in ['u1','u2','u3']:
            need(env[name]==ring(component['coordinates'][name]),'modular coordinate '+name)
        u=[env[n] for n in ['u1','u2','u3']]
        need(all(a.evaluate(p,u)==0 for p in polys),'three full source numerators')
        x=[env[n] for n in ['u1','u2','u3','m','a','b','c','p','r1','t1']]
        q=[env[n] for n in ['q1','q2','q3']]
        need(all(v==0 for v in original_residuals(source,x+q,ring)),
             'ten original source residuals')
        need(len(circuit['original_23_units'])==23,'original23-unit inventory')
        for name in circuit['original_23_units']:need(env[name].unit(),'original localization '+name)
        need(a.localization_checks(u)==[
            '2-p','2-p0','2-r1','2-t0','2-t1','A','B','E1','S','d1','d2','d3',
            'p','p0','q-d1','q-d2','q-d2_1','q-d2_2','q-d2_3','q-d3','r1','t0','t1'],
            'separate original localization reconstruction')
        need(env['triangle_determinant']==env['Y3']*env['E1'],'triangle determinant')
        need(env['r_slope']/env['u1']+env['s_constant']==0,'linear remainder')
        records.append({'index':k,'degree':ring.d,'nodes':53,'divisions':30,'original_units':23,
                        'original_residuals':10,'denominator_inverse_records':divisions})
    need(sum(r['degree'] for r in records)==512,'complete512 geometric residue points')
    result={'status':'PASS','schema':'standalone-centre-rational-circuit-v1',
        'input_sha256':{n:hashlib.sha256(b).hexdigest() for n,b in raw.items()},
        'components':records,'all512_original_coordinates_and_localizations_verified':True,
        'char_zero_equality_requires_manuscript_determinant_and_unit_proofs':True}
    output.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print('PASS complete circuit512',flush=True)

if __name__=='__main__':
    if len(sys.argv)!=3:raise SystemExit('usage: centre_circuit.py FLAT_DATA OUTPUT')
    run(*(Path(x).resolve() for x in sys.argv[1:]))
