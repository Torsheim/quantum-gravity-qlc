"""Independent exact endpoint signs and coverage of delivered real intervals.

Usage: POLYNOMIAL_JSON DESCARTES_JSON OUTPUT_JSON
This does not prove Descartes upper bounds. It proves the claimed one-root
leaves contain a root by the intermediate value theorem, with disjoint leaves
covering both bounded half-lines and no root at any subdivision endpoint.
No imports from producer or Descartes checker; standard library only.
"""
from fractions import Fraction
from pathlib import Path
import hashlib
import json
import sys


def need(value, message):
    if not value:
        raise ValueError(message)


def sign_at(coefficients, x):
    numerator, denominator = x.numerator, x.denominator
    value = coefficients[-1]
    power = 1
    for coefficient in reversed(coefficients[:-1]):
        power *= denominator
        value = value * numerator + coefficient * power
    return (value > 0) - (value < 0)


def main():
    need(len(sys.argv) == 4, "usage POLYNOMIAL_JSON DESCARTES_JSON OUTPUT_JSON")
    hp, cp, op = map(Path, sys.argv[1:])
    raw_h, raw_c = hp.read_bytes(), cp.read_bytes()
    a = json.loads(raw_h)["coefficients_ascending"]
    cert = json.loads(raw_c)
    h_sha = hashlib.sha256(raw_h).hexdigest()
    need(cert["polynomial_sha256"] == h_sha, "polynomial hash")
    need(all(type(x) is int for x in a) and len(a) == 513 and a[-1] != 0,
         "degree-512 integer polynomial required")
    exponent = cert["root_bound_power_of_two"]
    need(type(exponent) is int and exponent >= 0, "bound exponent")
    bound = 2 ** exponent
    need(sum(abs(x) * bound ** i for i, x in enumerate(a[:-1]))
         < abs(a[-1]) * bound ** (len(a) - 1), "strict root bound")
    signs = {}

    def cached_sign(x):
        if x not in signs:
            signs[x] = sign_at(a, x)
        need(signs[x] != 0, "root at subdivision endpoint")
        return signs[x]

    result = {}
    for label, orientation in (("negative", -1), ("positive", 1)):
        tree = cert[label]
        need(tree["sign"] == orientation, "half-line orientation")
        need(tree["exact_midpoint_paths"] == [], "this checker expects no midpoint roots")
        intervals = []
        for leaf in tree["leaves"]:
            path = leaf["path"]
            need(type(path) is str and all(x in "01" for x in path), "binary path")
            n = int(path or "0", 2)
            denominator = 2 ** len(path)
            lo = orientation * Fraction(bound * n, denominator)
            hi = orientation * Fraction(bound * (n + 1), denominator)
            lo, hi = sorted((lo, hi))
            variation = leaf["variation"]
            need(type(variation) is int and variation in (0, 1), "leaf variation")
            left_sign, right_sign = cached_sign(lo), cached_sign(hi)
            need((left_sign != right_sign) == (variation == 1), "endpoint sign mismatch")
            intervals.append((lo, hi, variation, left_sign, right_sign))
        intervals.sort()
        need(intervals, "no leaves")
        need(intervals[0][0] == (-bound if orientation < 0 else 0), "left coverage")
        need(intervals[-1][1] == (0 if orientation < 0 else bound), "right coverage")
        need(all(row[0] < row[1] for row in intervals), "empty interval")
        need(all(left[1] == right[0] for left, right in zip(intervals, intervals[1:])),
             "overlap or gap")
        roots = [row for row in intervals if row[2] == 1]
        need(len(roots) == tree["count"], "root count mismatch")
        result[label] = {
            "disjoint_sign_change_intervals": len(roots),
            "all_leaf_intervals": len(intervals),
            "intervals": [{"left": str(row[0]), "right": str(row[1]),
                           "left_sign": row[3], "right_sign": row[4]} for row in roots],
        }
    total = sum(result[label]["disjoint_sign_change_intervals"]
                for label in ("negative", "positive"))
    need(total == cert["real_root_count"] == 204, "expected real count")
    result.update({
        "status": "PASS_EXACT_SIGN_CHANGE_LOWER_BOUND_AND_PARTITION",
        "polynomial_sha256": h_sha,
        "descartes_certificate_sha256": hashlib.sha256(raw_c).hexdigest(),
        "arithmetic": "Python integers and Fraction; independent homogeneous Horner evaluation",
        "distinct_real_roots_at_least": total,
        "distinct_endpoints_evaluated": len(signs),
        "every_endpoint_nonzero": True,
        "partition_covers_both_open_half_lines_within_bound": True,
        "strict_absolute_root_bound": bound,
        "upper_bound_requires_separate_Descartes_replay": True,
    })
    op.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(result["status"], total)


if __name__ == "__main__":
    main()
