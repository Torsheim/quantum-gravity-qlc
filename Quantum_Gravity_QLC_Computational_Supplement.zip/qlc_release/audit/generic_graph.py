#!/usr/bin/env python3
"""Exact global graph/source bridge and full relative Jacobian certificate.

The quotient ring need not be a field; determinant evaluation uses a
division-free recurrence and every inverse has an exact product check."""
import argparse
import ast
import hashlib
import itertools
import json
import os
from pathlib import Path
import sys
import time

import sympy as sp
from flint import nmod_poly
from sympy.polys.rings import ring
from sympy.polys.domains import ZZ

P = 65537
U = sp.symbols('u1:4')
QVAR = sp.symbols('q1:4')
M, XI, ETA, C12, C13, C23 = sp.symbols('m xi eta c12 c13 c23')
V4 = (*U, M)
V9 = (*U, M, XI, ETA, C12, C13, C23)
QS = dict(zip(QVAR, (4, 9, 49)))
ONE = nmod_poly([1], P)
ZERO = nmod_poly([], P)

def trace(stage):
    if os.environ.get('POINT415D_BRIDGE_TRACE')=='1':
        print(str(round(time.monotonic(),2))+' '+stage,file=sys.stderr,flush=True)

def need(condition, code):
    if not condition:
        raise RuntimeError('GRAPH_BRIDGE:' + code)

def member(archive, suffix):
    """Resolve a declared semantic polynomial input; no archive is opened."""
    base=Path(__file__).resolve().parents[1]/'certificates/generic'
    mapping={
        'reference/point4_13_H0.txt':'reference/invariant_constant.txt',
        'reference/point4_13_H1.txt':'reference/invariant_linear.txt',
        'reference/point4_10/E512_mod65537.txt':'compact/E512_mod65537.txt',
    }
    rel=mapping.get(suffix,suffix)
    path=base/rel
    need(path.is_file(),'SEMANTIC_INPUT:'+rel)
    return path.read_bytes()

def expr(data):
    return sp.sympify(data.decode('utf-8'))

def expanded_control_poly(data):
    """Specialize an expanded global integer polynomial via a strict AST.

    The long frozen factor sums are already expanded. Evaluating each
    monomial avoids quadratic symbolic Add construction while keeping the
    substitution an exact ring homomorphism. No source text is executed.
    """
    sys.setrecursionlimit(max(sys.getrecursionlimit(),10000))
    root=ast.parse(data.decode('utf-8'),mode='eval').body
    qvalues={'q1':4,'q2':9,'q3':49}
    indices={str(v):i for i,v in enumerate(V4)}
    zero=(0,0,0,0)
    def monomial(node):
        if isinstance(node,ast.Constant):
            need(type(node.value)is int,'FACTOR_INTEGER');return node.value%P,zero
        if isinstance(node,ast.Name):
            if node.id in qvalues:return qvalues[node.id],zero
            need(node.id in indices,'FACTOR_SYMBOL:'+node.id)
            powers=list(zero);powers[indices[node.id]]=1;return 1,tuple(powers)
        if isinstance(node,ast.UnaryOp)and isinstance(node.op,ast.USub):
            c,e=monomial(node.operand);return -c%P,e
        if isinstance(node,ast.BinOp)and isinstance(node.op,ast.Mult):
            c,e=monomial(node.left);d,f=monomial(node.right)
            return c*d%P,tuple(a+b for a,b in zip(e,f))
        if isinstance(node,ast.BinOp)and isinstance(node.op,ast.Pow):
            need(isinstance(node.right,ast.Constant)and type(node.right.value)is int and node.right.value>=0,'FACTOR_EXPONENT')
            c,e=monomial(node.left);n=node.right.value
            return pow(c,n,P),tuple(n*a for a in e)
        raise RuntimeError('GRAPH_BRIDGE:FACTOR_MONOMIAL_SYNTAX')
    stack=[(root,1)];terms={}
    while stack:
        node,sign=stack.pop()
        if isinstance(node,ast.BinOp)and isinstance(node.op,(ast.Add,ast.Sub)):
            stack.append((node.left,sign));stack.append((node.right,sign if isinstance(node.op,ast.Add)else-sign))
        else:
            c,e=monomial(node);terms[e]=(terms.get(e,0)+sign*c)%P
    return sp.Poly.from_dict({e:c for e,c in terms.items()if c},V4,modulus=P)

def ratio(a, b, variables):
    aa = sp.Poly(a, *variables, domain=sp.QQ).as_dict()
    bb = sp.Poly(b, *variables, domain=sp.QQ).as_dict()
    need(bool(aa) and aa.keys() == bb.keys(), 'SUPPORT_RATIO')
    k = next(iter(aa))
    r = aa[k] / bb[k]
    need(r != 0 and all(aa[k] == r * bb[k] for k in aa), 'COEFFICIENT_RATIO')
    return r

def evaluate(poly, values, modulus):
    if poly.is_zero:
        return ZERO
    powers = []
    for value, degree in zip(values, poly.degree_list(), strict=True):
        row = [ONE]
        for _ in range(degree):
            row.append(row[-1] * value % modulus)
        powers.append(row)
    answer = ZERO
    for exponents, coefficient in poly.terms():
        term = nmod_poly([int(coefficient) % P], P)
        for power, exponent in zip(powers, exponents, strict=True):
            term = term * power[exponent] % modulus
        answer = (answer + term) % modulus
    return answer

def determinant(matrix, modulus):
    """Subset recurrence: determinant over any commutative quotient ring.

    Uses no pivot division and never treats Fp[t]/E as a field.
    """
    n = len(matrix)
    minors = {0: ONE}
    for mask in range(1, 1 << n):
        row = mask.bit_count() - 1
        total = ZERO
        for column in range(n):
            if not (mask >> column) & 1:
                continue
            previous = mask ^ (1 << column)
            sign = -1 if (mask >> (column + 1)).bit_count() % 2 else 1
            total = (total + sign * minors[previous] * matrix[row][column]) % modulus
        minors[mask] = total
    return minors[(1 << n) - 1]

def coeff(poly):
    return list(map(int, poly.coeffs()))

def inverse(poly, modulus):
    g,s,_=poly.xgcd(modulus)
    need(g==ONE,'POLYNOMIAL_INVERSE_GCD')
    return s % modulus

def unit_record(poly, modulus, label):
    need(poly.gcd(modulus).degree() == 0, 'NONUNIT:' + label)
    inv = inverse(poly,modulus)
    need(poly * inv % modulus == ONE, 'INVERSE:' + label)
    return {'residue': coeff(poly), 'inverse': coeff(inv), 'product_mod_E': [1]}

def execute(droot, croot):
    trace('start')
    prerequisite = droot
    names = ('EA', 'EB', 'E12', 'E13', 'E23', 'Hp', 'Lp', 'T', 'Htriangle')
    generators = {n: expr(member(prerequisite, 'generated/' + n + '.txt')) for n in names}
    a = [q - (u - 1)**2 for q, u in zip(QVAR, U)]
    b = [q + u - 1 for q, u in zip(QVAR, U)]
    q1, q2, q3 = QVAR
    u1, u2, u3 = U
    Q = q1*q2*q3
    abar = q2*a[0]*u2**2 + q1*a[1]*u1**2
    bbar = q3*a[1]*u3**2 + q2*a[2]*u2**2
    da, db = q1*q2*u1*u2, q2*q3*u2*u3
    expected = {'EA': da*XI-abar, 'EB': db*ETA-bbar,
                'Hp': q2*XI*ETA+4*a[1],
                'Lp': Q*XI*ETA*M + XI*(q1*q3*a[1]+q1*q2*a[2]) + ETA*(q2*q3*a[0]+q1*q3*a[1]),
                'T': Q*(M**2-1)+q2*q3*a[0]+q1*q3*a[1]+q1*q2*a[2]}
    sections = {XI: abar/da, ETA: bbar/db}
    denominators = {'EA': da, 'EB': db}
    for i,j,c,n in ((0,1,C12,'E12'),(0,2,C13,'E13'),(1,2,C23,'E23')):
        den = QVAR[i]*QVAR[j]*b[i]*b[j]
        num = QVAR[i]*a[i]*b[j]**2+QVAR[j]*a[j]*b[i]**2
        expected[n] = den*c-num
        sections[c] = num/den
        denominators[n] = den
    for n,e in expected.items():
        need(sp.expand(generators[n]-e) == 0, 'GLOBAL_GENERATOR:' + n)
    trace('global elementary generators')
    ph = abar*bbar + 4*Q*a[1]*u1*u2**2*u3
    pl = abar*bbar*M + u2*u3*(q3*a[1]+q2*a[2])*abar + u1*u2*(q2*a[0]+q1*a[1])*bbar
    need(sp.cancel(generators['Hp'].subs(sections)*da*db/q2-ph) == 0, 'GLOBAL_PH')
    need(sp.cancel(generators['Lp'].subs(sections)*da*db/Q-pl) == 0, 'GLOBAL_PL')
    trace('global path sections')

    # Universal invariant pullback, before inserting q or reducing modulo p.
    z = sp.symbols('z1:4'); edges = sp.symbols('a12 a13 a23')
    xx = sp.symbols('x1:4'); yy = sp.symbols('y1:4')
    h0 = expr(member(prerequisite, 'reference/point4_13_H0.txt'))
    h1 = expr(member(prerequisite, 'reference/point4_13_H1.txt'))
    universal = h0 + M*h1
    pull = dict(zip(z, [xx[i]*yy[i] for i in range(3)]))
    pull.update(dict(zip(edges, [xx[0]*yy[1]+xx[1]*yy[0], xx[0]*yy[2]+xx[2]*yy[0], xx[1]*yy[2]+xx[2]*yy[1]])))
    frozen_h = sp.sympify((droot/'reference/triangle_H.txt').read_text())
    universal_ratio = ratio(sp.expand(universal.subs(pull)), frozen_h, (*xx,*yy,M))
    trace('universal triangle pullback')
    graph_sub = dict(zip(z,[a[i]/QVAR[i] for i in range(3)]))
    graph_sub.update(dict(zip(edges,(C12,C13,C23))))
    graph_ratio = ratio(sp.expand(Q**4*universal.subs(graph_sub)), generators['Htriangle'], (*V9,*QVAR))
    trace('global Htriangle normalization')
    need(int(sp.numer(graph_ratio)) % P != 0 and int(sp.denom(graph_ratio)) % P != 0, 'GRAPH_NORMALIZATION_UNIT')
    need(int(sp.numer(universal_ratio)) % P != 0 and int(sp.denom(universal_ratio)) % P != 0, 'TRIANGLE_NORMALIZATION_UNIT')

    # Source equality is exact over Q at q*, with all normalization scalars
    # nonzero mod p. Global identity above supplies its family-level origin.
    four = {n: sp.sympify((droot/'reference'/f'{n}.txt').read_text()) for n in ('PH4','PL4','FT4','PTH4')}
    ratios = {'PH4':ratio(sp.expand(ph.subs(QS)),four['PH4'],V4),
              'PL4':ratio(sp.expand(pl.subs(QS)),four['PL4'],V4),
              'FT4':ratio(sp.expand(generators['T'].subs(QS)),four['FT4'],V4)}
    section_at_star = {k:sp.cancel(v.subs(QS)) for k,v in sections.items()}
    clearing = (Q**4*sp.prod(x**4 for x in b)).subs(QS)
    # Universal pullback already proves Hgraph(section) =
    # (universal_ratio/graph_ratio)*Q^4*H(alpha/beta,beta/q,m).
    # Rebuild the latter clearing with sparse integer arithmetic.
    rr,rx,ry,rz,rm=ring('u1,u2,u3,m',ZZ)
    ru=(rx,ry,rz);rq=(4,9,49)
    ra=[q-(u-1)**2 for q,u in zip(rq,ru)]
    rb=[q+u-1 for q,u in zip(rq,ru)]
    raw=rr.zero
    for mon,c in sp.Poly(frozen_h,*xx,*yy,M,domain=sp.ZZ).terms():
        term=rr.ground_new(int(c))*rm**mon[6]
        for i in range(3):
            need(mon[i+3]-mon[i]+4>=0 and 4-mon[i+3]>=0,'TRIANGLE_DENOMINATORS')
            term*=ra[i]**mon[i]*rb[i]**(mon[i+3]-mon[i]+4)*rq[i]**(4-mon[i+3])
        raw+=term
    raw_ratio=ratio(sp.Poly.from_dict(dict(raw),V4).as_expr(),four['PTH4'],V4)
    ratios['PTH4'] = sp.cancel(universal_ratio/graph_ratio*Q.subs(QS)**4*raw_ratio)
    trace('four source normalizations')
    for k,r in ratios.items():
        need(int(sp.numer(r)) % P != 0 and int(sp.denom(r)) % P != 0, 'SOURCE_NORMALIZATION_UNIT:' + k)

    historical_c = croot
    t=sp.Symbol('t')
    ep=sp.Poly(expr(member(historical_c,'reference/point4_10/E512_mod65537.txt')),t,modulus=P)
    e=nmod_poly([int(ep.nth(i))%P for i in range(ep.degree()+1)],P)
    need(e.degree()==512 and e.gcd(e.derivative()).degree()==0,'SQUAREFREE512')
    rur=json.loads((croot/'finite_rur.json').read_text())['RUR']
    v4=[nmod_poly(rur[str(v)],P) for v in V4]
    need(v4[2]==nmod_poly([0,1],P),'PARAMETER_U3')
    def ev4(ex):return evaluate(sp.Poly(ex,*V4,modulus=P),v4,e)
    v9=list(v4)
    section_units={}
    for var in (XI,ETA,C12,C13,C23):
        n,d=sp.fraction(section_at_star[var])
        nr,dr=ev4(n),ev4(d)
        section_units[str(var)]=unit_record(dr,e,'SECTION:'+str(var))
        v9.append(nr*inverse(dr,e)%e)
    specialized={n:sp.Poly(g.subs(QS),*V9,modulus=P) for n,g in generators.items()}
    for n,g in specialized.items():
        need(not evaluate(g,v9,e),'GRAPH_RESIDUAL:'+n)
    trace('nine graph residuals')
    jac9=[[evaluate(g.diff(v),v9,e) for v in V9] for g in specialized.values()]
    j9=determinant(jac9,e)
    j9record=unit_record(j9,e,'GRAPH_JACOBIAN9')
    trace('nine determinant')
    jac4=[[ev4(sp.diff(g,v)) for v in V4] for g in four.values()]
    j4=determinant(jac4,e)
    j4record=unit_record(j4,e,'SOURCE_JACOBIAN4')

    # Schur-complement identity: moving the five section columns in front
    # of the four source columns is an even permutation (5*4 swaps).
    scales=[(q2/(da*db)).subs(QS)*ratios['PH4'],(Q/(da*db)).subs(QS)*ratios['PL4'],ratios['FT4'],ratios['PTH4']/clearing]
    multiplier=ONE
    for d in denominators.values():multiplier=multiplier*ev4(d.subs(QS))%e
    for scale in scales:
        n,d=sp.fraction(sp.cancel(scale)); multiplier=multiplier*ev4(n)*inverse(ev4(d),e)%e
    need(j9==multiplier*j4%e,'SCHUR_JACOBIAN_IDENTITY')
    trace('Schur identity')

    # Directly check the declared GLOBAL localization factors, including m.
    factor_names=json.loads(member(prerequisite,'generated/factor_inventory.json'))['localization_factor_names']
    need(factor_names==['u1','u2','u3','alpha1','alpha2','alpha3','beta1','beta2','beta3','Sbar','Abar','Bbar','path_p','path_2mp','path_s','path_2ms','Etri','tri_p','tri_2mp','tri_r','tri_2mr','tri_s','tri_2ms'],'EXACT_23_FACTOR_INVENTORY')
    factors={}
    for name in factor_names:
        f=expanded_control_poly(member(prerequisite,'generated/factor_'+name+'.txt'))
        need(f.gens==V4,'GLOBAL_FACTOR_VARIABLES:'+name)
        factors[name]=unit_record(evaluate(f,v4,e),e,'GLOBAL_FACTOR:'+name)
        trace('factor '+name)
    return {'schema':'generic-global-graph-certificate-v1','status':'PASS',
            'global_eight_elementary_generators_exact':True,'global_path_section_identities_exact':True,
            'universal_invariant_to_triangle_H_ratio':str(universal_ratio),
            'Q4_invariant_to_global_Htriangle_ratio':str(graph_ratio),
            'global_triangle_pullback_before_specialization':True,
            'specialized_source_normalization_ratios':{k:str(v) for k,v in ratios.items()},
            'RUR_parameter':'u3','E_degree':512,'E_squarefree':True,'E_coefficients':coeff(e),
            'all_nine_graph_residuals_zero':list(names),'section_denominator_units':section_units,
            'all_23_global_factor_units':factors,'four_equation_Jacobian':j4record,
            'nine_equation_Jacobian':j9record,'Schur_Jacobian_identity':True,
            'determinant_algorithm':'division-free subset recurrence in Fp[t]/E512; no field assumption',
            'source_irreducibility_claim':False,'old_characteristic_zero_lower_bound_used':False}

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('d_source',type=Path);parser.add_argument('c_review',type=Path);parser.add_argument('output',type=Path)
    args=parser.parse_args()
    data=execute(args.d_source,args.c_review)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':'PASS','global_pullback':True,'graph_Jacobian_unit':True,'localization_units':23}))

if __name__=='__main__':main()
