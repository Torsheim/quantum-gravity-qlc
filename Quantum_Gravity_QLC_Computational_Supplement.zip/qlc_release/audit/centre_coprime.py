#!/usr/bin/env python3
"""Exact, standard-library certificate: minors 12 and 23 are coprime over QQ.

Usage: python finite_fibre_certificate.py MODEL_DIRECTORY OUTPUT_JSON
MODEL_DIRECTORY contains minors/minor_12.txt and minors/minor_23.txt.
Output is deterministic and is identical under python -O.
"""
import ast
import hashlib
import json
import math
from pathlib import Path
import sys
sys.setrecursionlimit(20000)


def require(ok, message):
    if not ok:
        raise ValueError(message)


def padd(a, b):
    c = dict(a)
    for k, v in b.items():
        c[k] = c.get(k, 0) + v
        if not c[k]:
            del c[k]
    return c


def pscale(a, s):
    return {k: v*s for k, v in a.items() if v*s}


def pmul(a, b):
    c = {}
    for (i, j), v in a.items():
        for (k, l), w in b.items():
            key = (i+k, j+l)
            c[key] = c.get(key, 0) + v*w
    return {k: v for k, v in c.items() if v}


def parse_polynomial(source):
    def rec(node):
        if isinstance(node, ast.Constant) and type(node.value) is int:
            return {} if not node.value else {(0, 0): node.value}
        if isinstance(node, ast.Name) and node.id in ('u2', 'u3'):
            return {(1, 0) if node.id == 'u2' else (0, 1): 1}
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
            return pscale(rec(node.operand), -1 if isinstance(node.op, ast.USub) else 1)
        if isinstance(node, ast.BinOp):
            if isinstance(node.op, ast.Add):
                return padd(rec(node.left), rec(node.right))
            if isinstance(node.op, ast.Sub):
                return padd(rec(node.left), pscale(rec(node.right), -1))
            if isinstance(node.op, ast.Mult):
                return pmul(rec(node.left), rec(node.right))
            if isinstance(node.op, ast.Pow):
                require(isinstance(node.right, ast.Constant) and type(node.right.value) is int and 0 <= node.right.value <= 200,
                        'Unsupported exponent')
                out, base = {(0, 0): 1}, rec(node.left)
                for _ in range(node.right.value):
                    out = pmul(out, base)
                return out
        raise ValueError('Unsupported polynomial syntax')
    return rec(ast.parse(source, mode='eval').body)


def trim(a, p):
    a = [x % p for x in a]
    while a and a[-1] == 0:
        a.pop()
    return a


def add(a, b, p):
    c = [0]*max(len(a), len(b))
    for i, x in enumerate(a): c[i] += x
    for i, x in enumerate(b): c[i] += x
    return trim(c, p)


def mul(a, b, p):
    if not a or not b: return []
    c = [0]*(len(a)+len(b)-1)
    for i, x in enumerate(a):
        for j, y in enumerate(b): c[i+j] += x*y
    return trim(c, p)


def neg(a, p): return trim([-x for x in a], p)


def divmodp(a, b, p):
    a, b = trim(a, p), trim(b, p)
    require(bool(b), 'Division by zero polynomial')
    out = [0]*max(0, len(a)-len(b)+1)
    inv = pow(b[-1], -1, p)
    while len(a) >= len(b):
        shift, coeff = len(a)-len(b), a[-1]*inv % p
        out[shift] = coeff
        for j, x in enumerate(b): a[j+shift] = (a[j+shift]-coeff*x) % p
        a = trim(a, p)
    return trim(out, p), a


def xgcd(a, b, p):
    oldr, r = trim(a, p), trim(b, p)
    olds, s, oldt, t = [1], [], [], [1]
    degrees = [len(oldr)-1, len(r)-1]
    while r:
        q, rr = divmodp(oldr, r, p)
        oldr, r = r, rr
        olds, s = s, add(olds, neg(mul(q, s, p), p), p)
        oldt, t = t, add(oldt, neg(mul(q, t, p), p), p)
        degrees.append(len(r)-1)
    inv = pow(oldr[-1], -1, p)
    return trim([x*inv for x in oldr], p), trim([x*inv for x in olds], p), trim([x*inv for x in oldt], p), degrees


def coefficients(poly, coord, fixed_degree):
    out = {}
    for powers, value in poly.items():
        if powers[coord] == fixed_degree:
            out[powers[1-coord]] = value
    if not out: return []
    return [out.get(k, 0) for k in range(max(out)+1)]


def specialize_z(poly, z):
    out = [0]*(max(k[0] for k in poly)+1)
    for (i, j), value in poly.items(): out[i] += value*z**j
    while out and not out[-1]: out.pop()
    return out


def main(model_dir, output):
    sources = {name: model_dir/('minor_'+name+'.txt') for name in ('12', '23')}
    polys = {name: parse_polynomial(path.read_text()) for name, path in sources.items()}
    f, g = polys['12'], polys['23']
    degs = {name: {'total_degree': max(i+j for i,j in poly), 'bidegree': [max(i for i,j in poly), max(j for i,j in poly)], 'terms':len(poly)} for name,poly in polys.items()}
    require(degs['12'] == {'total_degree':40, 'bidegree':[24,16], 'terms':281}, 'Unexpected minor12 degrees')
    require(degs['23'] == {'total_degree':61, 'bidegree':[37,25], 'terms':833}, 'Unexpected minor23 degrees')
    f0, f24 = coefficients(f, 0, 0), coefficients(f, 0, 24)
    require(f0 == [0]*16+[-1], 'f coefficient of y^0 differs from -z^16')
    require(f24[0] == -40960000, 'Unexpected nonzero constant of y^24 coefficient')
    f1, g1 = specialize_z(f, 1), specialize_z(g, 1)
    require(len(f1)-1 == 24, 'Specialization loses y degree of f')
    p = 101
    require(p > 1 and all(p%d for d in range(2, math.isqrt(p)+1)), 'Modulus not prime')
    fm, gm = trim(f1, p), trim(g1, p)
    require(len(fm) == len(f1), 'Modular reduction loses degree of f(y,1)')
    require(len(gm) == len(g1), 'Modular reduction loses degree of g(y,1)')
    gcd, bez_f, bez_g, remainder_degrees = xgcd(fm, gm, p)
    require(gcd == [1], 'Specialization is not coprime mod101')
    identity = add(mul(bez_f, fm, p), mul(bez_g, gm, p), p)
    require(identity == [1], 'Bezout identity verification failed')
    bound = degs['12']['bidegree'][0]*degs['23']['bidegree'][1] + degs['12']['bidegree'][1]*degs['23']['bidegree'][0]
    require(bound == 1192, 'P1xP1 intersection number differs')
    out = {
        'status':'PASS', 'claim':'QQ-coprime minors 12 and 23; finite projected complex support',
        'source_sha256':{str(path.relative_to(model_dir)):hashlib.sha256(path.read_bytes()).hexdigest() for path in sources.values()},
        'source_degrees':degs,
        'coefficient_order':'ascending degree in all arrays',
        'content_certificate':{'f_y0':f0,'f_y24':f24,'f_y24_constant':f24[0],'argument':'A common divisor of all y-coefficients divides z^16 and the y^24 coefficient, which is not divisible by z. Hence content_y(f)=1 over QQ.'},
        'specialization':{'z':1,'f_integer':f1,'g_integer':g1,'f_degree':len(f1)-1,'g_degree':len(g1)-1,'f_leading_integer':f1[-1],'g_leading_integer':g1[-1]},
        'modular_bezout':{'prime':p,'f_mod':fm,'g_mod':gm,'f_bezout_multiplier':bez_f,'g_bezout_multiplier':bez_g,'gcd':[1],'checked_identity':[1],'remainder_degrees':remainder_degrees},
        'lift_argument':'Degree preservation of f(y,1) mod101 forces any primitive nonconstant QQ[y] common factor to retain positive degree modulo101, contradicting the Bezout identity. Degree preservation of f under z=1 forces every common QQ[y,z] factor with positive y-degree to remain nonconstant at z=1. Content_y(f)=1 rules out nonconstant z-only factors.',
        'bounds':{'projective_plane_bezout':40*61,'P1xP1_bezout':bound,'complex_candidate_distinct_points_rank_two_bound':2*bound},
        'not_claimed':['complete real count','reducedness','membership of q0 in rank512 open','constant full count in metric neighborhood'],
    }
    output.write_text(json.dumps(out, indent=2, sort_keys=True)+'\n')
    print(json.dumps({'status':'PASS','output':str(output),'P1xP1_support_bound':bound,'bezout_modulus':p,'f_specialization_leading':f1[-1],'f_leading_mod101':fm[-1]}))


if __name__ == '__main__':
    require(len(sys.argv) == 3, 'Usage: finite_fibre_certificate.py MODEL_DIRECTORY OUTPUT_JSON')
    main(Path(sys.argv[1]), Path(sys.argv[2]))
