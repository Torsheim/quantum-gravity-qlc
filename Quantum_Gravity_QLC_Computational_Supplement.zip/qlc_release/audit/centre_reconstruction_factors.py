"""Independent exact factor and unit proof for the u2 reconstruction.

Usage: COFACTOR_CERT MODULAR_CERT H_JSON U2_JSON OUTPUT_JSON
Standard library only. The determinant identity is separately certified.
"""
from pathlib import Path
import hashlib
import json
import math
import sys

if hasattr(sys, "set_int_max_str_digits"):
    sys.set_int_max_str_digits(0)


def need(value, message):
    if not value:
        raise ValueError(message)


def convolution(a, b):
    out = [0] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        if x:
            for j, y in enumerate(b):
                out[i + j] += x * y
    return out


def trim(a):
    while a and not a[-1]:
        a.pop()
    return a


def remainder(a, b, p):
    a, b = trim([x % p for x in a]), trim([x % p for x in b])
    need(bool(b), "zero divisor polynomial")
    inv = pow(b[-1], -1, p)
    while len(a) >= len(b):
        k, c = len(a) - len(b), a[-1] * inv % p
        for j, x in enumerate(b):
            a[k + j] = (a[k + j] - c * x) % p
        trim(a)
    return a


def gcd(a, b, p):
    a, b = trim([x % p for x in a]), trim([x % p for x in b])
    while b:
        a, b = b, remainder(a, b, p)
    return [x * pow(a[-1], -1, p) % p for x in a] if a else []


def main():
    need(len(sys.argv) == 6, "usage COFACTOR MODULAR H U2 OUTPUT")
    paths = list(map(Path, sys.argv[1:]))
    raw = [p.read_bytes() for p in paths[:-1]]
    certificate, modular, h_json, u2_json = map(json.loads, raw)
    a = certificate["a_coefficients_ascending"]
    b = certificate["b_coefficients_ascending"]
    g = certificate["cancelled_polynomial_coefficients_ascending"]
    n = certificate["numerator_coefficients_ascending"]
    d = certificate["denominator_coefficients_ascending"]
    h = h_json["coefficients_ascending"]
    c = certificate["cancelled_integer_content"]
    for name, poly in (("a", a), ("b", b), ("G", g), ("N", n), ("D", d), ("H", h)):
        need(isinstance(poly, list) and poly and poly[-1] != 0
             and all(type(x) is int for x in poly), name + " integer polynomial")
    need(type(c) is int and c != 0, "nonzero scalar")
    need(math.gcd(*g) == 1, "G primitive")
    need([c * x for x in convolution(g, d)] == a, "a != c G D")
    need([-c * x for x in convolution(g, n)] == b, "b != -c G N")
    need(u2_json["numerator_coefficients_ascending"] == n
         and u2_json["denominator_coefficients_ascending"] == d, "published coordinate arrays")
    p = modular["prime"]
    need(p == 101 and h[-1] % p, "good characteristic")
    product, rows = [1], []
    for component in modular["components"]:
        hi, coords = component["h"], component["coordinates"]
        need(hi[-1] == 1 and gcd(hi, [i * hi[i] for i in range(1, len(hi))], p) == [1],
             "monic squarefree component")
        need(gcd(product, hi, p) == [1], "component collision")
        need(remainder(coords["u3"], hi, p) == remainder([0, 1], hi, p), "primitive coordinate")
        for label, poly in (("G", g), ("N", n), ("D", d)):
            need(gcd(poly, hi, p) == [1], label + " is not a unit")
        product_dy = convolution(d, coords["u2"])
        delta = [0] * max(len(n), len(product_dy))
        for i, x in enumerate(n): delta[i] += x
        for i, x in enumerate(product_dy): delta[i] -= x
        need(remainder(delta, hi, p) == [], "N/D fails accepted u2 coordinate")
        rows.append({"degree": len(hi) - 1, "G_N_D_units": True, "u2_identity": True})
        product = [x % p for x in convolution(product, hi)]
    inv = pow(h[-1], -1, p)
    need([x * inv % p for x in h] == product and len(h) == 513,
         "full accepted H reduction")
    need(sum(row["degree"] for row in rows) == 512, "total degree")
    output = {
        "status": "PASS_EXACT_RECONSTRUCTION_FACTOR_AND_UNIT_IDENTITIES",
        "input_sha256": {label: hashlib.sha256(data).hexdigest()
                         for label, data in zip(("cofactor_certificate", "accepted_modular", "H", "u2"), raw)},
        "degree_a": len(a) - 1, "degree_b": len(b) - 1,
        "degree_G": len(g) - 1, "degree_N": len(n) - 1, "degree_D": len(d) - 1,
        "integer_content_bits": abs(c).bit_length(), "integer_content_mod101": c % 101,
        "exact_a_equals_cGD": True, "exact_b_equals_minus_cGN": True,
        "G_primitive": True, "all_G_N_D_units_on_accepted_components": True,
        "u2_identity_on_every_accepted_component": True,
        "H_monic_reduction_is_full_accepted_product": True, "components": rows,
        "source_determinants_recomputed": False,
        "arithmetic": "Independent standard-library integer convolution and modular Euclidean arithmetic",
    }
    paths[-1].write_text(json.dumps(output, sort_keys=True, indent=2) + "\n")
    print(output["status"])


if __name__ == "__main__":
    main()
