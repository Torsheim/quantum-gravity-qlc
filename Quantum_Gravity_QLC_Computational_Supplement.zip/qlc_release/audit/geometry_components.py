#!/usr/bin/env python3
"""Independent original-coefficient audit, with no historical code imports.

This checks identities between the supplied component definitions; it does
not identify a complex algebraic fibre with actual star-preserving points.
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
from pathlib import Path

import sympy as s


def need(ok,code):
    if not ok:raise RuntimeError(code)


def zero(expr,code):
    need(s.cancel(expr)==0,code)


def execute(manuscript):
    nu=s.Symbol('nu')
    metric=[[nu,*[-s.Symbol(f'A{t}_{a}')for a in range(1,4)]]for t in range(2)]
    diag={(t,i):s.Symbol(f'U{t}_{i}')for t in range(2)for i in range(4)}
    mix={(t,i,j):s.Symbol(f'V{t}_{i}{j}')for t in range(2)for i in range(4)for j in range(4)if i!=j}
    square={(t,i,j):s.Symbol(f'W{t}_{i}{j}')for t in range(2)for i in range(4)for j in range(4)if i!=j}
    symbols=[*diag.values(),*mix.values(),*square.values()]
    bars={v:s.Symbol('bar_'+str(v))for v in symbols}
    def C(t,i,p,q):
        if p==q:return diag[t,i]if p==i else square[t,i,p]
        if p==i:return mix[t,i,q]
        if q==i:return mix[t,i,p]
        return s.S.Zero
    def Sigma(t,i,j,p,q):
        value=s.S.One if(p,q)==(j,i)else s.S.Zero
        if (1<<i)^(1<<j)==(1<<p)^(1<<q):value-=C(t,i,p,q)
        return value
    def E(t,p,q,r):
        value=(metric[t^(p==0)][r]-metric[t][r])if q==r else s.S.Zero
        value+=metric[t][r]*C(t,r,p,q)
        for i,j in itertools.product(range(4),repeat=2):
            value+=metric[t][i]*C(t^(i==0),i,j,r)*Sigma(t,i,j,p,q)
        return s.expand(value)
    def Star(t,i,p,q):
        value=C(t,i,p,q)
        for j,k in itertools.product(range(4),repeat=2):
            value+=C(t^((j==0)^(k==0)),i,j,k).xreplace(bars)*Sigma(t,k,j,p,q)
        return s.expand(value)

    # Full torsion-free tensor inventory, and exact supported sigma blocks.
    need(len(symbols)==56,'coefficient_count')
    for t,i,p,q in itertools.product(range(2),range(4),range(4),range(4)):
        zero(C(t,i,p,q)-C(t,i,q,p),'torsion')
    metric_values={(t,p,q,r):E(t,p,q,r)for t,p,q,r in itertools.product(range(2),range(4),range(4),range(4))}
    star_values={(t,i,p,q):Star(t,i,p,q)for t,i,p,q in itertools.product(range(2),range(4),range(4),range(4))}
    reconstruction={}
    for t in range(2):
        for a in range(1,4):
            A=-metric[t][a];B=-metric[1-t][a]
            reconstruction[square[t,a,0]]=-nu*mix[1-t,0,a]/A
            reconstruction[square[t,0,a]]=(B*(1-mix[1-t,a,0])-A)/nu
        for a,b in itertools.permutations(range(1,4),2):reconstruction[square[t,a,b]]=metric[t][b]*mix[t,b,a]/metric[t][a]
    need(len(reconstruction)==24,'eliminated_square_count')
    linear_records=[]
    for t in range(2):
        for p,q in itertools.combinations(range(4),2):
            for r in (p,q):
                antisym=metric_values[t,p,q,r]-metric_values[t,q,p,r]
                linear=(metric[t^(p==0)][r]-metric[t][r]if q==r else 0)-(metric[t^(q==0)][r]-metric[t][r]if p==r else 0)
                linear+=metric[t][q]*C(t^(q==0),q,p,r)-metric[t][p]*C(t^(p==0),p,q,r)
                zero(antisym-linear,'antisymmetric_metric_linearization')
                zero(linear.xreplace(reconstruction),'linear_elimination')
                present=[w for w in square.values()if linear.has(w)]
                need(len(present)==1,'unique_linear_pivot')
                pivot=s.expand(linear).coeff(present[0])
                need(pivot in [nu,-nu,*sum(([h,-h]for row in metric for h in row[1:]),[])],'metric_unit_pivot')
                linear_records.append({'slice':t,'indices':[p,q,r],'eliminated':str(present[0]),'pivot':str(pivot),'equation':str(s.expand(linear))})
    need(len({r['eliminated']for r in linear_records})==24,'each_w_eliminated_once')

    metric_records=[];metric_counts={'block_core':0,'time_pair':0,'spatial_pair':0,'three_distinct_zero':0}
    H_relations=[]
    for t in range(2):
        x=s.Matrix([mix[t,0,a]for a in range(1,4)])
        tx=s.Matrix([mix[1-t,0,a]for a in range(1,4)])
        y=s.Matrix([mix[t,a,0]for a in range(1,4)])
        z=s.Matrix([1+metric[1-t][a]/metric[t][a]*(mix[1-t,a,0]-1)for a in range(1,4)])
        spatial=s.Matrix(3,3,lambda a,b:diag[t,a+1]-1 if a==b else mix[t,a+1,b+1])
        hat=s.Matrix.vstack(s.Matrix([[diag[t,0]-1,*tx]]),s.Matrix.hstack(z,spatial))
        sharp=s.Matrix.vstack(s.Matrix([[diag[1-t,0]-1,*tx]]),s.Matrix.hstack(y,spatial))
        product=hat*sharp-s.eye(4)
        W=s.Matrix(4,4,lambda i,j:C(t,i,j,j).xreplace(reconstruction))
        H=s.diag(*metric[t])
        for entry in s.eye(4)-W+H.inv()*hat.T*H:zero(entry,'Q_H_Lhat_identity')
        H_relations.append({'slice':t,'identity':'Q=-H^{-1} Lhat^T H','z_not_replaced_by_y':True})
        for p,q,r in itertools.product(range(4),repeat=3):
            actual=metric_values[t,p,q,r].xreplace(reconstruction)
            if p==q:
                expected=-nu*product[0,r]if p==0 else -metric[t][p]*product[p,r]
                kind='block_core';basis=f'core[{p},{r}]'
            elif r not in(p,q):expected=0;kind='three_distinct_zero';basis='0'
            elif 0 in(p,q):
                a=max(p,q);d=mix[t,0,a]+mix[t,a,0]-1
                F1=d*mix[1-t,0,a]-mix[t,0,a]
                F2=d*d-d*mix[t,0,a]+metric[1-t][a]/metric[t][a]*(mix[t,0,a]-1)
                expected=-nu*F1 if r==0 else -metric[t][a]*F2
                kind='time_pair';basis=f'F{1 if r==0 else 2}_{a}'
            else:
                other=q if r==p else p
                expected=-metric[t][r]*mix[t,r,other]*(mix[t,p,q]+mix[t,q,p]-2)
                kind='spatial_pair';basis=f'V{r}{other}*(V{p}{q}+V{q}{p}-2)'
            zero(actual-expected,'metric_component:'+str((t,p,q,r)))
            metric_counts[kind]+=1
            metric_records.append({'slice':t,'indices':[p,q,r],'class':kind,'reduced_equation':basis,
                                   'original_component':str(metric_values[t,p,q,r]),'after_w':str(s.cancel(actual))})
    need(metric_counts=={'block_core':32,'time_pair':24,'spatial_pair':24,'three_distinct_zero':48},'metric_partition')

    star_records=[];star_counts={'zero_grade':0,'mixed':0,'three_distinct_zero':0}
    det_identities=[]
    for t in range(2):
        W=s.Matrix(4,4,lambda i,j:C(t,i,j,j));Wbar=W.xreplace(bars)
        block=s.eye(4)-(s.eye(4)-Wbar)*(s.eye(4)-W)
        for i,p,q in itertools.product(range(4),repeat=3):
            if p==q:expected=block[i,p];kind='zero_grade'
            elif i in(p,q):
                other=q if i==p else p;d=mix[t,i,other]+mix[t,other,i]-1
                shifted=t^((i==0)^(other==0))
                expected=mix[t,i,other]-d*bars[mix[shifted,i,other]];kind='mixed'
            else:expected=0;kind='three_distinct_zero'
            zero(star_values[t,i,p,q]-expected,'star_component:'+str((t,i,p,q)))
            star_counts[kind]+=1
            star_records.append({'slice':t,'input':i,'output':[p,q],'class':kind,'component':str(star_values[t,i,p,q])})
        for i,j in itertools.combinations(range(4),2):
            shifted=t^((i==0)^(j==0));d=mix[t,i,j]+mix[t,j,i]-1
            dbar=bars[mix[shifted,i,j]]+bars[mix[shifted,j,i]]-1
            f=star_values[t,i,i,j]+star_values[t,j,j,i]
            zero(f-(1-d*dbar),'mixed_inverse_identity')
            det_identities.append({'slice':t,'edge':[i,j],'identity':'F_ij+F_ji=1-d_ij*R_iR_j(bar(d_ij))'})
    need(star_counts=={'zero_grade':32,'mixed':48,'three_distinct_zero':48},'star_partition')

    # A polynomial witness for z=y once the real local reciprocal relation holds.
    x,tx,y,ty,q=s.symbols('x tx y ty q');d=x+y-1;dt=tx+ty-1;z=1+q*(ty-1)
    f1=d*tx-x;f2=d*d-d*x+q*(x-1);f3=d*dt-1
    zero(d*(z-y)+f2-q*(f3-f1),'z_y_local_polynomial_identity')

    # Symbolic matrix witness for reality, rather than a point sample.
    P=s.Matrix(4,4,lambda i,j:s.Symbol(f'P{i}{j}'))
    Pb=s.Matrix(4,4,lambda i,j:s.Symbol(f'Pb{i}{j}'))
    for entry in Pb-P-(P*(P*Pb-s.eye(4))-(P*P-s.eye(4))*Pb):zero(entry,'reality_matrix_identity')

    return {'schema':'complete-qlc-geometry-components-v1','status':'PASS',
            'source_manuscript_sha256':hashlib.sha256(manuscript.read_bytes()).hexdigest(),
            'source_historical_code_imported':False,'spatial_homogeneity_enforced':True,
            'metric_scales':'nu,A0_1,A0_2,A0_3,A1_1,A1_2,A1_3 remain symbolic nonzero real parameters',
            'connection_complex_coefficient_values_before_star':56,'w_values_eliminated':24,
            'linear_elimination':linear_records,'w_reconstruction':{str(k):str(v)for k,v in reconstruction.items()},
            'metric_component_count':128,'metric_partition':metric_counts,'metric_catalog':metric_records,
            'star_component_count':128,'star_partition':star_counts,'star_catalog':star_records,
            'zero_grade_star_equation':'I-bar(Q)*Q=0','mixed_inverse_identities':det_identities,
            'Q_H_relations':H_relations,
            'local_z_y_witness':'d*(z-y)=-F2+q*(F3-F1), F1=d*tx-x, F2=d^2-d*x+q*(x-1), F3=d*dt-1',
            'matrix_reality_witness':'bar(P)-P=P*(P*bar(P)-I)-(P^2-I)*bar(P)',
            'verified_what':'Polynomial/rational identities for the declared component equations, over metric-unit localization.',
            'not_claimed':['equivalence of arbitrary complex points to star-preserving connections','proof of all earlier geometric conventions','full unrestricted448-coefficient classification','scheme-theoretic elimination of conjugate variables']}


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('manuscript',type=Path);parser.add_argument('output',type=Path)
    args=parser.parse_args();data=execute(args.manuscript);args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':'PASS','metric_components':128,'star_components':128,'w_eliminations':24}))
