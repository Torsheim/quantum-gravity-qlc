#!/usr/bin/env python3
"""Independent exact finiteness audit, no symbolic package or producer imports.
Usage: python independent_sylvester_certificate.py MODEL_DIRECTORY OUTPUT_JSON

Reads the expanded integer minors using a restrictive monomial parser, verifies
content/degree conditions, and computes the 61x61 Sylvester determinant over F101.
The source hash pins are to the accepted phase4.20 coefficient files. Distinct
from the primary AST parser / extended Euclidean Bezout implementation.
"""
from pathlib import Path
import hashlib
import json
import math
import re
import sys

P = 101
PINS = {
    '12': 'ef817f9d685c93d637b71b037122180f81f9a9b62c43979b59bcfaf2a9e631f0',
    '23': 'd7093e86c0ddbe0654dfd9446b7200c6bece7a16aea8080d2f4ee71b70f4105b',
}


def demand(condition, description):
    if not condition:
        raise ValueError(description)


def parse_expanded(source):
    expression = re.sub(r'\s+', '', source)
    # Splitting signed terms is safe because accepted factors have only natural exponents.
    demand(bool(expression), 'Empty input')
    terms = re.findall(r'[+-]?[^+-]+', expression)
    demand(''.join(terms) == expression, 'Invalid signed-term syntax')
    out = {}
    for term in terms:
        sign = -1 if term.startswith('-') else 1
        body = term[1:] if term[0] in '+-' else term
        factors = re.split(r'(?<!\*)\*(?!\*)', body)
        coefficient, powers, seen, integer_seen = sign, [0, 0], set(), False
        for factor in factors:
            if re.fullmatch(r'[0-9]+', factor):
                demand(not integer_seen, 'Duplicate integer factor')
                integer_seen = True
                coefficient *= int(factor)
                continue
            match = re.fullmatch(r'(u2|u3)(?:\*\*([0-9]+))?', factor)
            demand(match is not None, 'Invalid monomial factor: '+factor)
            variable, exponent = match.groups()
            demand(variable not in seen, 'Duplicate variable factor')
            seen.add(variable)
            powers[0 if variable == 'u2' else 1] = int(exponent or '1')
        demand(coefficient != 0, 'Zero term forbidden in expanded source')
        key = tuple(powers)
        demand(key not in out, 'Duplicate source monomial')
        out[key] = coefficient
    return out


def determinant_mod(matrix, prime):
    n = len(matrix)
    demand(n > 0 and all(len(row) == n for row in matrix), 'Matrix must be square')
    a = [[x % prime for x in row] for row in matrix]
    determinant, swaps, pivots = 1, 0, []
    for col in range(n):
        pivot_row = next((row for row in range(col, n) if a[row][col]), None)
        demand(pivot_row is not None, 'Singular Sylvester matrix')
        if pivot_row != col:
            a[col], a[pivot_row] = a[pivot_row], a[col]
            swaps += 1
            determinant = -determinant
        pivot = a[col][col]
        pivots.append(pivot)
        determinant = determinant * pivot % prime
        inverse = pow(pivot, prime - 2, prime)
        demand(pivot * inverse % prime == 1, 'Bad modular inverse')
        for row in range(col + 1, n):
            multiplier = a[row][col] * inverse % prime
            for k in range(col + 1, n):
                a[row][k] = (a[row][k] - multiplier*a[col][k]) % prime
            a[row][col] = 0
    demand(determinant != 0, 'Zero determinant')
    return determinant, swaps, pivots


def hull(points):
    pts = sorted(set(points))
    def cross(a, b, c):
        return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
    lower, upper = [], []
    for point in pts:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], point) <= 0:
            lower.pop()
        lower.append(point)
    for point in reversed(pts):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], point) <= 0:
            upper.pop()
        upper.append(point)
    return lower[:-1] + upper[:-1]


def twice_area(poly):
    return abs(sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(poly, poly[1:]+poly[:1])))


def main(model_directory, output):
    demand(P > 1 and all(P % n for n in range(2, math.isqrt(P)+1)), 'Modulus must be prime')
    polynomials, source_hashes = {}, {}
    for key in ('12', '23'):
        source = model_directory/('minor_'+key+'.txt')
        raw = source.read_bytes()
        sha = hashlib.sha256(raw).hexdigest()
        demand(sha == PINS[key], 'Source hash mismatch for minor'+key)
        source_hashes['minors/'+source.name] = sha
        polynomials[key] = parse_expanded(raw.decode('utf-8'))
    f, g = polynomials['12'], polynomials['23']
    demand(len(f) == 281 and len(g) == 833, 'Wrong term counts')
    f_y_zero = {j:c for (i,j),c in f.items() if i == 0}
    demand(f_y_zero == {16:-1}, 'Content witness f(0,z) is not -z^16')
    demand(f.get((24,0)) == -40960000, 'Nonvertical content witness failed')
    f_integer_content = math.gcd(*f.values())
    demand(f_integer_content == 1, 'f must be primitive over integers')
    degrees, specialized = {}, {}
    for key, poly in polynomials.items():
        degree_y = max(i for i,j in poly)
        degree_z = max(j for i,j in poly)
        coefficients = [sum(c for (i,j),c in poly.items() if i == k) for k in range(degree_y+1)]
        demand(coefficients[-1] != 0, 'Specialization z=1 loses y-degree')
        demand(coefficients[-1] % P != 0, 'Reduction mod101 loses y-degree')
        degrees[key] = [degree_y, degree_z]
        specialized[key] = coefficients
    demand(degrees == {'12':[24,16], '23':[37,25]}, 'Wrong bidegrees')
    a = [x % P for x in specialized['12']]
    b = [x % P for x in specialized['23']]
    m, n = len(a)-1, len(b)-1
    # The coefficient map (U,V) -> U*f + V*g, deg U < n, deg V < m.
    # Rows list its n+m shifted coefficient vectors (transpose convention).
    sylvester = []
    for shift in range(n):
        sylvester.append([0]*shift + a + [0]*(n-1-shift))
    for shift in range(m):
        sylvester.append([0]*shift + b + [0]*(m-1-shift))
    determinant, swaps, pivots = determinant_mod(sylvester, P)
    first_hull, second_hull = hull(f), hull(g)
    sum_hull = hull([(x[0]+y[0],x[1]+y[1]) for x in first_hull for y in second_hull])
    areas = list(map(twice_area, (first_hull, second_hull, sum_hull)))
    demand(areas == [512,1559,3911], 'Unexpected exact Newton polygon areas')
    demand((areas[2]-areas[1]-areas[0]) == 1840, 'Unexpected twice mixed area')
    result = {
        'status':'PASS',
        'claim':'Independent arithmetic certificate for QQ-coprimality of minors12 and23',
        'implementation':'Restrictive expanded-monomial parser and Gaussian elimination of full Sylvester matrix; no primary checker imports',
        'source_sha256':source_hashes,
        'term_counts':{'12':len(f),'23':len(g)},
        'bidegrees':degrees,
        'content_witness':{'f_y0':'-z^16','f_y24_z0':f[(24,0)],'integer_content_f':f_integer_content},
        'specialization':{'z':1,'prime':P,'integer_coefficients_ascending':specialized,'modular_coefficients_ascending':{'12':a,'23':b}},
        'sylvester':{'dimension':m+n,'determinant_mod101':determinant,'row_swaps':swaps,'diagonal_pivots':pivots,'convention':'Rows U*f, then V*g, each ascending powers; det transpose equals det'},
        'newton_geometry':{'hull_12':first_hull,'hull_23':second_hull,'hull_sum':sum_hull,'twice_areas':areas,'mixed_area':920,'status':'Exact support geometry only; BKK application is a separate theorem'},
        'logical_bridge':[
            'Any positive-y-degree common QQ[y,z] factor can be taken primitive in ZZ[y,z] with integral cofactors by Gauss lemma.',
            'Degree preservation of f under z=1 and mod101 forces that factor to keep positive y degree and forces its cofactor nonzero.',
            'It must divide both specialized polynomials over F101; the invertible Sylvester map rules this out.',
            'Any z-only common factor would divide all y-coefficients of f; it divides -z^16 but cannot divide the y^24 coefficient, whose constant is nonzero.',
            'Thus the source minors have no nonconstant QQ factor and no common complex curve. Their complex affine intersection is finite.'
        ],
        'not_claimed':['total real count','reducedness','q0 in W','full-fibre metric-neighborhood constancy']
    }
    output.write_text(json.dumps(result, indent=2, sort_keys=True)+'\n')
    print(json.dumps({'status':'PASS','sylvester_dimension':m+n,'determinant_mod101':determinant,'mixed_area':920}))


if __name__ == '__main__':
    demand(len(sys.argv) == 3, 'Usage: independent_sylvester_certificate.py MODEL_DIRECTORY OUTPUT_JSON')
    main(Path(sys.argv[1]), Path(sys.argv[2]))
