"""Independent standard-library replay of the actual eliminant factor selection.

Usage: python check_factor_selection.py ELIMINANT_CERT MODULAR_CERT H_JSON OUTPUT
This verifies the exact product and all modular selection identities. It does
not compute the source resultant; that is a separate required certificate.
"""
from pathlib import Path
import hashlib
import json
import math
import sys


def need(condition, message):
    if not condition:
        raise ValueError(message)


def convolution(a, b):
    out = [0] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            out[i + j] += x * y
    return out


def trim(a):
    while a and a[-1] == 0:
        a.pop()
    return a


def remainder(a, b, p):
    a = trim([x % p for x in a])
    b = trim([x % p for x in b])
    need(bool(b), "zero modular divisor")
    inverse = pow(b[-1], -1, p)
    while len(a) >= len(b):
        k = len(a) - len(b)
        c = a[-1] * inverse % p
        for j, x in enumerate(b):
            a[k + j] = (a[k + j] - c * x) % p
        trim(a)
    return a


def gcd(a, b, p):
    a, b = trim([x % p for x in a]), trim([x % p for x in b])
    while b:
        a, b = b, remainder(a, b, p)
    return [(x * pow(a[-1], -1, p)) % p for x in a] if a else []


def main():
    need(len(sys.argv) == 5, "usage ELIMINANT_CERT MODULAR_CERT H_JSON OUTPUT")
    rp, mp, hp, op = map(Path, sys.argv[1:])
    raw = {"eliminant": rp.read_bytes(), "modular": mp.read_bytes(),
           "minimal_polynomial": hp.read_bytes()}
    data, modular, candidate = (json.loads(raw[k]) for k in
                                ("eliminant", "modular", "minimal_polynomial"))
    r, h, e = (data[k + "_coefficients_ascending"] for k in
               ("resultant", "H", "E"))
    for name, a in (("R", r), ("H", h), ("E", e)):
        need(isinstance(a, list) and a and all(type(x) is int for x in a), name + " format")
        need(a[-1] != 0, name + " leading coefficient")
    c = data["integer_content"]
    need(type(c) is int and c != 0, "nonzero integer content")
    need(len(r) == 1193 and len(h) == 513 and len(e) == 681, "degrees")
    need(math.gcd(*h) == math.gcd(*e) == 1, "primitive factors")
    need(math.gcd(*r) == abs(c), "exact resultant content")
    need([c * x for x in convolution(h, e)] == r, "exact integer product")
    need(candidate["coefficients_ascending"] == h, "candidate coefficients")
    p = modular["prime"]
    need(p == 101 and h[-1] % p != 0, "good leading coefficient")
    product = [1]
    component_degrees = []
    for component in modular["components"]:
        hi = component["h"]
        need(hi[-1] == 1, "monic component")
        need(gcd(hi, [j * hi[j] for j in range(1, len(hi))], p) == [1], "squarefree component")
        need(gcd(product, hi, p) == [1], "disjoint component")
        need(gcd(e, hi, p) == [1], "cofactor not a unit")
        need(remainder(h, hi, p) == [], "H does not vanish on component")
        product = [x % p for x in convolution(product, hi)]
        component_degrees.append(len(hi) - 1)
    inv = pow(h[-1], -1, p)
    need([(x * inv) % p for x in h] == product, "full monic reduction")
    need(sum(component_degrees) == 512, "total modular degree")
    content_valuation, remaining_content = 0, abs(c)
    while remaining_content % p == 0:
        content_valuation += 1
        remaining_content //= p
    result = {
        "status": "PASS_EXACT_FACTOR_SELECTION_IDENTITIES",
        "implementation": "Independent Python standard-library integer convolution and Euclidean modular arithmetic",
        "input_sha256": {k: hashlib.sha256(v).hexdigest() for k, v in raw.items()},
        "degree_R": len(r) - 1, "degree_H": len(h) - 1, "degree_E": len(e) - 1,
        "exact_product": True, "primitive_integer_H_and_E": True,
        "content_valuation_at_101": content_valuation,
        "H_leading_coefficient_mod101": h[-1] % p,
        "cofactor_unit_on_every_modular_component": True,
        "H_monic_reduction_is_full_component_product": True,
        "component_degrees": component_degrees,
        "source_resultant_recomputed": False,
    }
    op.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(result["status"])


if __name__ == "__main__":
    main()
