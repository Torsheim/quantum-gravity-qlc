"""Complete negative-grid identity audit of two fixed source determinants.

Usage: MODEL_DIRECTORY RECONSTRUCTION_JSON OUTPUT_JSON [--samples-only]
The JSON contains raw_a_coefficients_ascending/raw_b_coefficients_ascending.
For a raw discovery file the unprefixed a/b coefficient names are accepted.
Full mode uses FLINT integer determinants at -1,...,-1152. Samples-only mode
uses standard-library integer Bareiss at -2,-1,1,2,101 and is corroborative.
The parser and matrix builder are separate from the positive-grid producer.
"""
import ast
import hashlib
import json
from pathlib import Path
import sys

sys.setrecursionlimit(10000)
if hasattr(sys, "set_int_max_str_digits"):
    sys.set_int_max_str_digits(0)

PINS = {
    "12": "ef817f9d685c93d637b71b037122180f81f9a9b62c43979b59bcfaf2a9e631f0",
    "23": "d7093e86c0ddbe0654dfd9446b7200c6bece7a16aea8080d2f4ee71b70f4105b",
}


def need(x, message):
    if not x:
        raise ValueError(message)


def add(a, b, sign=1):
    c = dict(a)
    for e, v in b.items():
        c[e] = c.get(e, 0) + sign * v
    return {e: v for e, v in c.items() if v}


def multiply(a, b):
    c = {}
    for (i, j), v in a.items():
        for (k, l), w in b.items():
            e = i + k, j + l
            c[e] = c.get(e, 0) + v * w
    return {e: v for e, v in c.items() if v}


def parse(node):
    if isinstance(node, ast.Constant) and type(node.value) is int:
        return {(0, 0): node.value}
    if isinstance(node, ast.Name) and node.id in ("u2", "u3"):
        return {(1, 0) if node.id == "u2" else (0, 1): 1}
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.USub, ast.UAdd)):
        sign = -1 if isinstance(node.op, ast.USub) else 1
        return {e: sign * v for e, v in parse(node.operand).items()}
    if isinstance(node, ast.BinOp):
        if isinstance(node.op, ast.Pow):
            need(isinstance(node.right, ast.Constant)
                 and type(node.right.value) is int and node.right.value >= 0, "power")
            result, base = {(0, 0): 1}, parse(node.left)
            for _ in range(node.right.value):
                result = multiply(result, base)
            return result
        a, b = parse(node.left), parse(node.right)
        if isinstance(node.op, ast.Add): return add(a, b)
        if isinstance(node.op, ast.Sub): return add(a, b, -1)
        if isinstance(node.op, ast.Mult): return multiply(a, b)
    raise ValueError("unsupported source syntax")


def bareiss(matrix):
    n = len(matrix)
    a, previous, parity = [row[:] for row in matrix], 1, 1
    for k in range(n - 1):
        pivot = next((i for i in range(k, n) if a[i][k]), None)
        if pivot is None: return 0
        if pivot != k:
            a[k], a[pivot] = a[pivot], a[k]
            parity = -parity
        value = a[k][k]
        for i in range(k + 1, n):
            for j in range(k + 1, n):
                q, r = divmod(a[i][j] * value - a[i][k] * a[k][j], previous)
                need(r == 0, "nonexact Bareiss division")
                a[i][j] = q
            a[i][k] = 0
        previous = value
    return parity * a[-1][-1]


def evaluate(a, x):
    value = 0
    for c in reversed(a):
        value = value * x + c
    return value


def main():
    need(len(sys.argv) in (4, 5), "usage MODEL RECONSTRUCTION OUTPUT [--samples-only]")
    samples_only = len(sys.argv) == 5
    need(not samples_only or sys.argv[4] == "--samples-only", "unknown mode")
    model, cp, op = map(Path, sys.argv[1:4])
    raw = cp.read_bytes()
    data = json.loads(raw)
    prefix = "raw_" if "raw_a_coefficients_ascending" in data else ""
    a, b = (data[prefix + label + "_coefficients_ascending"] for label in ("a", "b"))
    polys, bidegrees = [], []
    for label in ("12", "23"):
        source = (model / ("minor_" + label + ".txt")).read_bytes()
        need(hashlib.sha256(source).hexdigest() == PINS[label], "source pin")
        poly = parse(ast.parse(source.decode().strip(), mode="eval").body)
        polys.append(poly)
        bidegrees.append([max(e[i] for e in poly) for i in (0, 1)])
    (m, d), (n, e) = bidegrees
    need((m, n) == (24, 37), "source y degrees")
    bound = (n - 1) * d + (m - 1) * e
    need(bound == 1151 and data["degree_bound"] == bound, "derived degree bound")
    for poly in (a, b):
        need(isinstance(poly, list) and poly and poly[-1] != 0
             and len(poly) - 1 <= bound and all(type(c) is int for c in poly), "claimed polynomial")
    if samples_only:
        points = [-2, -1, 1, 2, 101]
        det = bareiss
    else:
        from flint import fmpz_mat
        points = list(range(-1, -bound - 2, -1))
        det = lambda matrix: int(fmpz_mat(matrix).det())
    records = hashlib.sha256()
    width = m + n - 1
    for z in points:
        rows = []
        for poly, count, ydegree in ((polys[0], n - 1, m), (polys[1], m - 1, n)):
            coefficients = [0] * (ydegree + 1)
            for (i, j), coefficient in poly.items():
                coefficients[i] += coefficient * z ** j
            for shift in range(count):
                row = [0] * width
                row[shift:shift + ydegree + 1] = coefficients
                rows.append(row)
        need(len(rows) == width - 1, "matrix dimensions")
        actual_a = det([row[1:] for row in rows])
        actual_b = det([[row[0]] + row[2:] for row in rows])
        need(actual_a == evaluate(a, z), "a determinant mismatch at " + str(z))
        need(actual_b == evaluate(b, z), "b determinant mismatch at " + str(z))
        records.update((str(z) + ":" + str(actual_a) + ":" + str(actual_b) + "\n").encode())
    output = {
        "status": "PASS_SUPPLEMENTAL_BAREISS_SAMPLES" if samples_only else "PASS_EXACT_DETERMINANT_IDENTITIES",
        "reconstruction_input_sha256": hashlib.sha256(raw).hexdigest(),
        "source_sha256": PINS, "source_bidegrees": bidegrees,
        "matrix_rows": width - 1, "matrix_columns": width,
        "a_columns": list(range(1, width)), "b_columns": [0] + list(range(2, width)),
        "degree_bound": bound, "degree_a": len(a) - 1, "degree_b": len(b) - 1,
        "sample_count": len(points), "determinants_checked": 2 * len(points),
        "first_sample": points[0], "last_sample": points[-1],
        "samples_sha256": records.hexdigest(),
        "complete_identity_proof": not samples_only,
        "requires_degree_preservation_at_sample": False,
        "arithmetic": "Independent AST parser/matrix builder; " + (
            "standard-library integer Bareiss elimination" if samples_only else
            "exact FLINT integer determinants, backend shared with producer"),
    }
    op.write_text(json.dumps(output, sort_keys=True, indent=2) + "\n")
    print(output["status"], len(points), "points")


if __name__ == "__main__":
    main()
