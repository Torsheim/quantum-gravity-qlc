#!/usr/bin/env python3
"""Independent standard-library verification of a Descartes partition.

No FLINT, symbolic algebra, producer imports, or floating-point arithmetic.
Taylor shifts are recomputed by a triangular sequence of integer additions.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import sys

if hasattr(sys, "set_int_max_str_digits"):
    sys.set_int_max_str_digits(0)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def taylor_one(coefficients):
    b = list(coefficients)
    n = len(b) - 1
    for start in range(n - 1, -1, -1):
        for j in range(start, n):
            b[j] += b[j + 1]
    return b


def sign_changes(sequence):
    previous, changes = 0, 0
    for value in sequence:
        if value:
            current = 1 if value > 0 else -1
            changes += int(previous != 0 and previous != current)
            previous = current
    return changes


def normalize(a):
    divisor = math.gcd(*a)
    if divisor > 1:
        return [x // divisor for x in a]
    return a


def mod_remainder(a, b, p):
    a = list(a)
    while a and a[-1] == 0:
        a.pop()
    inverse = pow(b[-1], -1, p)
    while len(a) >= len(b):
        factor, shift = a[-1] * inverse % p, len(a) - len(b)
        for j, value in enumerate(b):
            a[shift + j] = (a[shift + j] - factor * value) % p
        while a and a[-1] == 0:
            a.pop()
    return a


def squarefree_prime(a):
    # Nonvanishing leading coefficient and gcd 1 modulo one prime prove gcd 1
    # over Q. This is independent of the producer's characteristic-zero gcd.
    for p in (101, 103, 107, 109, 113, 127, 131, 137, 139, 149, 151, 157):
        if a[-1] % p == 0:
            continue
        f = [x % p for x in a]
        g = [(i * a[i]) % p for i in range(1, len(a))]
        while g and g[-1] == 0:
            g.pop()
        while g:
            f, g = g, mod_remainder(f, g, p)
        if len(f) == 1:
            return p
    raise ValueError("no squarefree modular witness at the declared primes")


def verify_tree(a, exponent, sign, certificate):
    require(certificate["sign"] == sign, "tree sign mismatch")
    leaves = {}
    internals = set()
    for entry in certificate["leaves"]:
        path, claimed = entry["path"], entry["variation"]
        require(type(path) is str and all(c in "01" for c in path), "invalid path")
        require(type(claimed) is int and claimed in (0, 1), "invalid variation")
        require(path not in leaves, "duplicate leaf")
        leaves[path] = claimed
        for k in range(len(path)):
            internals.add(path[:k])
    require(bool(leaves), "empty partition")
    require(not set(leaves).intersection(internals), "non-prefix-free leaves")
    require(all(path + bit in leaves or path + bit in internals
                for path in internals for bit in "01"), "incomplete partition")
    require("" in leaves or "" in internals, "missing root interval")
    expected_midpoints = certificate["exact_midpoint_paths"]
    require(len(expected_midpoints) == len(set(expected_midpoints)), "duplicate midpoint")
    require(set(expected_midpoints).issubset(internals), "midpoint outside split nodes")
    n = len(a) - 1
    initial = normalize([c * ((-1) ** i if sign < 0 else 1) * (2 ** (exponent * i))
                         for i, c in enumerate(a)])
    stack = [("", initial)]
    midpoint_paths, root_count, nodes, max_depth = [], 0, 0, 0
    while stack:
        path, q = stack.pop()
        nodes += 1
        max_depth = max(max_depth, len(path))
        if path in leaves:
            actual = sign_changes(taylor_one(q[::-1]))
            require(actual == leaves[path], "leaf Descartes variation mismatch: " + path)
            root_count += actual
        else:
            require(path in internals, "unlisted node")
            # 2**n * q(t/2) and its shift at t=1 have integer coefficients.
            left = normalize([c * (2 ** (n - i)) for i, c in enumerate(q)])
            if sum(left) == 0:
                midpoint_paths.append(path)
            right = normalize(taylor_one(left))
            stack.append((path + "1", right))
            stack.append((path + "0", left))
    require(midpoint_paths == expected_midpoints, "midpoint root list mismatch")
    require(root_count == certificate["leaf_roots"], "leaf root sum mismatch")
    require(len(midpoint_paths) == certificate["exact_midpoint_roots"], "midpoint sum mismatch")
    require(root_count + len(midpoint_paths) == certificate["count"], "tree count mismatch")
    require(nodes == certificate["nodes"] and max_depth == certificate["maximum_depth"],
            "tree size mismatch")
    return {"count": root_count + len(midpoint_paths), "verified_leaves": len(leaves),
            "verified_midpoint_roots": len(midpoint_paths), "nodes": nodes,
            "maximum_depth": max_depth}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("polynomial")
    parser.add_argument("certificate")
    parser.add_argument("output")
    args = parser.parse_args()
    raw = Path(args.polynomial).read_bytes()
    cert_raw = Path(args.certificate).read_bytes()
    a = json.loads(raw)["coefficients_ascending"]
    c = json.loads(cert_raw)
    require(isinstance(a, list) and len(a) >= 2 and all(type(x) is int for x in a),
            "invalid polynomial")
    require(a[-1] != 0, "zero leading coefficient")
    require(c["schema"] == "point4_23_exact_descartes_partition_v1", "unknown schema")
    require(c["status"] == "PASS", "producer not PASS")
    require(c["polynomial_sha256"] == hashlib.sha256(raw).hexdigest(), "polynomial hash mismatch")
    require(c["degree"] == len(a) - 1, "degree mismatch")
    require(c["coefficient_height_bits"] == max(abs(x).bit_length() for x in a),
            "height mismatch")
    require(c["squarefree_over_Q"] is True, "squarefree claim missing")
    prime = squarefree_prime(a)
    k = c["root_bound_power_of_two"]
    require(type(k) is int and k >= 0, "invalid exponent")
    require(sum(abs(v) * (2 ** (k * i)) for i, v in enumerate(a[:-1]))
            < abs(a[-1]) * (2 ** (k * (len(a) - 1))), "strict root bound false")
    require(c["strict_root_bound_verified"] is True, "root bound claim missing")
    neg = verify_tree(a, k, -1, c["negative"])
    pos = verify_tree(a, k, 1, c["positive"])
    zero = int(a[0] == 0)
    total = neg["count"] + pos["count"] + zero
    require(c["zero_root"] == zero and c["real_root_count"] == total, "total mismatch")
    result = {"status": "PASS", "method": "Independent integer-addition Descartes replay",
              "polynomial_sha256": hashlib.sha256(raw).hexdigest(),
              "partition_sha256": hashlib.sha256(cert_raw).hexdigest(),
              "degree": len(a) - 1, "squarefree_witness_prime": prime,
              "root_bound_power_of_two": k, "negative": neg, "positive": pos,
              "zero_root": zero, "real_root_count": total}
    Path(args.output).write_text(json.dumps(result, sort_keys=True, indent=2) + "\n")


if __name__ == "__main__":
    main()
