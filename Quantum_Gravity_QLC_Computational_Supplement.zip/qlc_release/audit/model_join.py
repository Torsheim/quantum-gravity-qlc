"""Bind the geometry and degree computations to exactly the same polynomials.

Each subsystem reconstructs its own identities. This extra join prevents the
subsystems from silently using different coefficient files for the family.
"""
from pathlib import Path
import hashlib

def check(root):
    geometry=root/'certificates/geometry/model'
    generic=root/'certificates/generic'
    names=['EA','EB','E12','E13','E23','Hp','Lp','T','Htriangle']
    pairs=[(geometry/(name+'.txt'),generic/'generated'/(name+'.txt')) for name in names]
    factors=sorted(p.name for p in geometry.glob('factor_*.txt'))
    other=sorted(p.name for p in (generic/'generated').glob('factor_*.txt'))
    if len(factors)!=23 or factors!=other:
        raise ValueError('the two proof blocks must retain the same 23 factors')
    pairs += [(geometry/name,generic/'generated'/name) for name in factors]
    pairs += [(geometry/'invariant_H0.txt',generic/'reference/invariant_constant.txt'),
              (geometry/'invariant_H1.txt',generic/'reference/invariant_linear.txt')]
    rows=[]
    for first,second in pairs:
        a,b=first.read_bytes(),second.read_bytes()
        if a!=b:
            raise ValueError('different model coefficient files: '+first.name)
        rows.append({'geometry':first.relative_to(root).as_posix(),
                     'generic':second.relative_to(root).as_posix(),
                     'sha256':hashlib.sha256(a).hexdigest()})
    return {'status':'PASS','global_graph_equations':9,'localization_factors':23,
            'triangle_invariants':2,'all_pairs':rows,
            'meaning':'Same literal integer polynomials; their mathematical identities are separately checked.'}
