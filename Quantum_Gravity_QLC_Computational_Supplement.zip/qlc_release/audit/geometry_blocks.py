"""Fresh exact reconstruction of the localized block-involution bridge.

No historical audit module is imported or executed. The frozen global
polynomials are data, parsed using a restricted arithmetic AST.
"""
from pathlib import Path
import ast
import hashlib
import itertools
import json
import sys
import sympy as s


class AuditError(Exception):
    pass


def need(test, name):
    if not test:
        raise AuditError(name)


def polynomial_file(path, symbols):
    names = {str(x): i for i,x in enumerate(symbols)}
    tree=ast.parse(path.read_text(), mode='eval')
    terms={};stack=[(tree.body,1)]
    while stack:
        n,sign=stack.pop()
        if isinstance(n,ast.BinOp) and isinstance(n.op,(ast.Add,ast.Sub)):
            stack.append((n.left,sign));stack.append((n.right,-sign if isinstance(n.op,ast.Sub) else sign));continue
        if isinstance(n,ast.UnaryOp) and isinstance(n.op,(ast.USub,ast.UAdd)):
            stack.append((n.operand,-sign if isinstance(n.op,ast.USub) else sign));continue
        coefficient=sign;exponents=[0]*len(symbols);factors=[n]
        while factors:
            f=factors.pop()
            if isinstance(f,ast.Constant) and type(f.value)is int:coefficient*=f.value
            elif isinstance(f,ast.Name) and f.id in names:exponents[names[f.id]]+=1
            elif isinstance(f,ast.BinOp) and isinstance(f.op,ast.Mult):factors.extend([f.left,f.right])
            elif isinstance(f,ast.BinOp) and isinstance(f.op,ast.Pow) and isinstance(f.left,ast.Name) and f.left.id in names and isinstance(f.right,ast.Constant) and type(f.right.value)is int and 0<=f.right.value<=32:
                exponents[names[f.left.id]]+=f.right.value
            elif isinstance(f,ast.UnaryOp) and isinstance(f.op,(ast.USub,ast.UAdd)):
                if isinstance(f.op,ast.USub):coefficient*=-1
                factors.append(f.operand)
            else:raise AuditError('UNSUPPORTED_EXPANDED_POLYNOMIAL_SYNTAX:'+path.name)
        key=tuple(exponents);terms[key]=terms.get(key,0)+coefficient
    return s.Poly.from_dict(terms,symbols,domain=s.QQ).as_expr()


def calculate(root):
    checks = []
    def zero(name, expr):
        need(s.cancel(expr) == 0, name)
        checks.append(name)
    def same_matrix(name, a, b):
        need(a.shape == b.shape, name + ':SHAPE')
        for i in range(a.rows):
            for j in range(a.cols): zero(f'{name}:{i},{j}', a[i,j] - b[i,j])

    # The two temporal charts, before imposing any involution equations.
    q, d, u = s.symbols('q d u')
    uf = d*(q-1)/(q-d)
    df = q*u/(q+u-1)
    alpha, beta = q-(u-1)**2, q+u-1
    x, y = (q-d*d)/(q-d), uf
    zero('chart:u_after_d', uf.subs(d, df)-u)
    zero('chart:d_after_u', df.subs(u, uf)-d)
    for name, lhs, rhs in [
        ('u',u, d*(q-1)/(q-d)),
        ('beta',beta,q*(q-1)/(q-d)),
        ('alpha',alpha,q*(q-1)*(q-d*d)/(q-d)**2),
    ]: zero('chart:pullback:'+name,lhs.subs(u,uf)-rhs)
    zero('chart:q_minus_d',q-df-q*(q-1)/beta)
    zero('chart:q_minus_d_squared',q-df**2-q*(q-1)*alpha/beta**2)
    zero('local:d_definition',x+y-1-d)
    zero('local:conic',d*d-d*x+q*(x-1))
    zero('local:opposite_d',x/d+y/d-1-1/d)
    zero('local:opposite_conic',1/d**2-(1/d)*(x/d)+(1/q)*(x/d-1))
    zero('chart:X0', (x/d).subs(d,df)-alpha/(q*u))
    zero('chart:Y0', y.subs(d,df)-u)
    zero('chart:X1', x.subs(d,df)-alpha/beta)
    zero('chart:Y1', (y/d).subs(d,df)-beta/q)

    X = s.Matrix(s.symbols('X1 X2 X3'))
    Y = s.Matrix(s.symbols('Y1 Y2 Y3'))
    m = s.Symbol('m')
    X1,X2,X3 = X; Y1,Y2,Y3 = Y
    z = [X[i]*Y[i] for i in range(3)]
    S = sum(z)
    A = X1*Y2+X2*Y1; B = X2*Y3+X3*Y2
    C = A*(z[1]+z[2])+B*(z[0]+z[1])
    F = m*m+S-1; L = A*B*m+C; Hp = A*B+4*z[1]
    p = 2*X2*Y1/A; v = 2*X3*Y2/B
    Mp = s.Matrix([[-m-2*z[1]/A,p,0],
                   [2-p,-m-2*z[0]/A-2*z[2]/B,v],
                   [0,2-v,-m-2*z[1]/B]])
    same_matrix('path:right_eigenvector',Mp*Y,-m*Y)
    same_matrix('path:left_eigenvector',X.T*Mp,-m*X.T)
    F1 = s.trace(Mp)+m
    F2 = s.trace(Mp*Mp)-m*m-2
    zero('path:trace',F1+2*L/(A*B))
    zero('path:syzygy',A*B*(F2-2*F)+2*C*F1+2*S*Hp)
    # Explicit inverse generator transformations; all divisors are declared units.
    zero('path:F2_from_F_L_H',F2-(2*F+4*C*L/(A*B)**2-2*S*Hp/(A*B)))
    zero('path:H_from_F_F1_F2',Hp+(A*B*(F2-2*F)+2*C*F1)/(2*S))
    a,b,c,pp,ss = s.symbols('a b c p s')
    Mraw=s.Matrix([[a,pp,0],[2-pp,b,ss],[0,2-ss,c]])
    rv=Mraw*Y+m*Y; lv=X.T*Mraw+m*X.T
    zero('path:uniqueness_p',X1*rv[0]-Y1*lv[0]-(A*pp-2*X2*Y1))
    zero('path:uniqueness_s',X3*rv[2]-Y3*lv[2]+(B*ss-2*X3*Y2))

    # A universal 2x2 trace-zero calculation, valid over arbitrary rings.
    aa,bb,cc=s.symbols('aa bb cc')
    N=s.Matrix([[aa,bb],[cc,-aa]])
    same_matrix('rank_two:Cayley_Hamilton',N*N,(aa*aa+bb*cc)*s.eye(2))
    zero('rank_two:trace_square',s.trace(N*N)-2*(aa*aa+bb*cc))
    Pi=Y*X.T/S
    same_matrix('projector:idempotent',Pi*Pi,Pi)
    zero('projector:rank_one_trace',s.trace(Pi)-1)
    # Explicit basis on our chart (X3 and S are units), also checking the
    # basis-free residual formula with three independent complement entries.
    V=s.Matrix.hstack(Y,s.Matrix([1,0,-X1/X3]),s.Matrix([0,1,-X2/X3]))
    zero('projector:basis_determinant',V.det()-S/X3)
    M=s.simplify(V*s.diag(-m,N)*V.inv())
    G=2*(aa*aa+bb*cc-1)
    same_matrix('projector:lower_residual',M*M+Y*X.T-s.eye(3),G/2*(s.eye(3)-Pi)+F*Pi)

    # Reconstruct every triangle completion entry from the six linear equations.
    T=s.Matrix([[Y1,0,0,Y2,Y3,0],[0,Y2,0,-Y1,0,Y3],
                [0,0,Y3,0,-Y1,-Y2],[X1,0,0,-X2,-X3,0],
                [0,X2,0,X1,0,-X3],[1,1,1,0,0,0]])
    rhs=s.Matrix([-m*Y1,-2*Y1-m*Y2,-2*Y1-2*Y2-m*Y3,
                  -m*X1-2*X2-2*X3,-m*X2-2*X3,-m])
    E=X1**2*Y2**2-X1**2*Y3**2-X2**2*Y1**2+X2**2*Y3**2+X3**2*Y1**2-X3**2*Y2**2
    zero('triangle:determinant',T.det(method='domain-ge')-Y3*E)
    sol=T.inv(method='DM')*rhs
    theta=[s.cancel(E*t) for t in sol]
    for i,t in enumerate(theta):
        s.Poly(t,*X,*Y,m,domain=s.QQ);checks.append('triangle:Cramer_polynomial:'+str(i))
    na,nb,nc,np,nr,ns=theta
    NM=s.Matrix([[na,np,nr],[2*E-np,nb,ns],[2*E-nr,2*E-ns,nc]])
    same_matrix('triangle:all_right_equations',NM*Y,-m*E*Y)
    same_matrix('triangle:all_left_equations',X.T*NM,-m*E*X.T)
    zero('triangle:trace',s.trace(NM)+m*E)
    Gnum=s.expand(s.trace(NM*NM)-(m*m+2)*E**2)
    quo,rem=s.div(s.Poly(Gnum,m),s.Poly(F,m))
    Qtri=s.expand(quo.as_expr())
    H=s.cancel(-rem.as_expr()/(2*S))
    s.Poly(H,*X,*Y,m,domain=s.QQ)
    zz=s.symbols('z1 z2 z3'); ee=s.symbols('a12 a13 a23')
    H0=polynomial_file(root/'model/invariant_H0.txt',(*zz,*ee))
    H1=polynomial_file(root/'model/invariant_H1.txt',(*zz,*ee))
    def orbit(expr):
        edge_index={(0,1):0,(0,2):1,(1,2):2}
        images=set()
        for perm in itertools.permutations(range(3)):
            mapping={zz[i]:zz[perm[i]] for i in range(3)}
            mapping.update({ee[k]:ee[edge_index[tuple(sorted((perm[i],perm[j])))]]
                            for (i,j),k in edge_index.items()})
            images.add(expr.xreplace(mapping))
        return sum(images)
    z1,z2,z3=zz;a12,a13,a23=ee
    explicit1=16*orbit(z1*z2*a12)+8*orbit(z1*a12*a23)-4*orbit(a12**3)+4*orbit(a12**2*a13)
    explicit0=(16*orbit(z1**2*z2)+16*orbit(z1**2*a23)+32*z1*z2*z3
               -4*orbit(z1*z2*a12**2)+16*orbit(z1*z2*a13)-4*orbit(z1*a12*a13*a23)
               +8*orbit(z1*a12*a23)+orbit(a12**4)+4*orbit(a12**3)
               -2*orbit(a12**2*a13**2)-4*orbit(a12**2*a13)+16*a12*a13*a23)
    zero('triangle:displayed_orbit_formula_H0',H0-explicit0)
    zero('triangle:displayed_orbit_formula_H1',H1-explicit1)
    pull=dict(zip(zz,z));pull.update(dict(zip(ee,[A,X1*Y3+X3*Y1,B])))
    zero('triangle:invariant_matches_reconstruction',H-(H0+m*H1).subs(pull,simultaneous=True))
    zero('triangle:syzygy',Gnum-Qtri*F+2*S*H)
    zero('triangle:quotient_m_independent',s.diff(Qtri,m))

    # Bind the exact nine generators and 23 localization factors to the source model.
    qs=s.symbols('q1 q2 q3'); us=s.symbols('u1 u2 u3')
    xi,eta,c12,c13,c23=s.symbols('xi eta c12 c13 c23')
    al=[qs[i]-(us[i]-1)**2 for i in range(3)]
    be=[qs[i]+us[i]-1 for i in range(3)]
    Q=s.prod(qs)
    X0=[al[i]/(qs[i]*us[i]) for i in range(3)];Y0=list(us)
    Xone=[al[i]/be[i] for i in range(3)];Yone=[be[i]/qs[i] for i in range(3)]
    zs=[al[i]/qs[i] for i in range(3)]
    abar=qs[1]*al[0]*us[1]**2+qs[0]*al[1]*us[0]**2
    bbar=qs[2]*al[1]*us[2]**2+qs[1]*al[2]*us[1]**2
    expected={'EA':qs[0]*qs[1]*us[0]*us[1]*xi-abar,
              'EB':qs[1]*qs[2]*us[1]*us[2]*eta-bbar,
              'Hp':qs[1]*(xi*eta+4*zs[1]),
              'Lp':Q*(xi*eta*m+xi*(zs[1]+zs[2])+eta*(zs[0]+zs[1])),
              'T':Q*(m*m+sum(zs)-1)}
    for i,j,cv,name in [(0,1,c12,'E12'),(0,2,c13,'E13'),(1,2,c23,'E23')]:
        expected[name]=qs[i]*qs[j]*be[i]*be[j]*(cv-Xone[i]*Yone[j]-Xone[j]*Yone[i])
    hpull=dict(zip(zz,zs));hpull.update(dict(zip(ee,[c12,c13,c23])))
    expected['Htriangle']=-Q**4*(H0+m*H1).subs(hpull,simultaneous=True)
    variables=(*us,m,xi,eta,c12,c13,c23,*qs)
    for name,expr in expected.items():
        zero('model:generator:'+name,expr-polynomial_file(root/'model'/f'{name}.txt',variables))
    factors={**{f'u{i+1}':us[i] for i in range(3)},
             **{f'alpha{i+1}':al[i] for i in range(3)},
             **{f'beta{i+1}':be[i] for i in range(3)},
             'Sbar':Q*sum(zs),'Abar':abar,'Bbar':bbar,
             'path_p':qs[0]*al[1]*us[0]**2,
             'path_2mp':qs[1]*al[0]*us[1]**2,
             'path_s':qs[1]*al[2]*us[1]**2,
             'path_2ms':qs[2]*al[1]*us[2]**2}
    profiles={}
    for name,poly,scalar in [('Etri',E,1),('tri_p',np,s.Rational(1,2)),
        ('tri_2mp',2*E-np,s.Rational(1,2)),('tri_r',nr,-s.Rational(1,2)),
        ('tri_2mr',2*E-nr,s.Rational(1,2)),('tri_s',ns,s.Rational(1,2)),
        ('tri_2ms',2*E-ns,-s.Rational(1,2))]:
        terms=s.Poly(poly,*X,*Y,m).terms()
        bi=[max(mon[i]-mon[i+3] for mon,coef in terms) for i in range(3)]
        ci=[max(mon[i+3] for mon,coef in terms) for i in range(3)]
        out=0
        for mon,coef in terms:
            term=coef*m**mon[6]
            for i in range(3):
                term*=al[i]**mon[i]*be[i]**(bi[i]+mon[i+3]-mon[i])*qs[i]**(ci[i]-mon[i+3])
            out+=term
        factors[name]=scalar*s.expand(out)
        profiles[name]={'beta':bi,'q':ci,'frozen_over_cleared':str(scalar)}
    for name,expr in factors.items():
        zero('model:localizer:'+name,expr-polynomial_file(root/'model'/f'factor_{name}.txt',variables))
    need(len(factors)==23,'MODEL_FACTOR_INVENTORY')
    # Exact nonzero check: S cannot be removed from the block lemma.
    Xbad=s.Matrix([1,1,1]);Ybad=s.Matrix([1,1,-2])
    Mbad=s.Matrix([[0,-1,0],[-1,0,0],[0,0,-1]])
    need((Xbad.T*Ybad)[0]==0,'S_ZERO_CONTROL')
    need(Mbad*Ybad==-Ybad and Xbad.T*Mbad==-Xbad.T and s.trace(Mbad)==-1,'S_ZERO_LINEAR')
    need(s.trace(Mbad*Mbad)-3==0 and Mbad*Mbad+Ybad*Xbad.T-s.eye(3)!=s.zeros(3),'S_ZERO_COUNTEREXAMPLE')
    return {'schema':'complete-qlc-geometry-block-bridge-v1','status':'PASS',
            'sympy_version':s.__version__,'checks':checks,'check_count':len(checks),
            'global_generators_bound':len(expected),'global_localizers_bound':len(factors),
            'triangle_H_terms':len(s.Poly(H,*X,*Y,m).terms()),
            'triangle_Cramer_numerators':[str(s.expand(t)) for t in theta],
            'triangle_E':str(s.expand(E)),'triangle_Q':str(Qtri),
            'triangle_clearing_profiles':profiles,
            'S_zero_counterexample':{'X':[1,1,1],'Y':[1,1,-2],'m':1,'M':[[0,-1,0],[-1,0,0],[0,0,-1]],
                                     'linear_trace_and_scalar_tests_pass':True,'full_involution_fails':True},
            'original_QLC_coefficient_reduction_proved':False,
            'physical_unmarked_or_real_solution_count_claimed':False}


if __name__=='__main__':
    try:
        need(len(sys.argv)==3,'USAGE: bridge.py ROOT OUTPUT_JSON')
        root=Path(sys.argv[1]).resolve();out=Path(sys.argv[2])
        result=calculate(root)
        out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
        print(json.dumps({'status':result['status'],'checks':result['check_count']}))
    except (AuditError,ValueError,OSError) as error:
        print(str(error),file=sys.stderr);raise SystemExit(1)
