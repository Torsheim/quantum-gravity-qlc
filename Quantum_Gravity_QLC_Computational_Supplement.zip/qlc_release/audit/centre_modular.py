"""Independent standard-library finite-field point and Jacobian audit.
Usage: checker.py SOURCE_420 CERTIFICATE OUTPUT_JSON
"""
from pathlib import Path
import json, re, sys, hashlib, itertools

def need(b,m):
    if not b: raise ValueError(m)
def trim(a):
    a=list(a)
    while a and not a[-1]:a.pop()
    return a
def sub(a,b,p):
    c=list(a)+[0]*max(0,len(b)-len(a))
    for i,x in enumerate(b):c[i]=(c[i]-x)%p
    return trim(c)
def conv(a,b,p):
    if not a or not b:return []
    bits=(min(len(a),len(b))*(p-1)**2).bit_length()+1
    x=sum(int(v)<<(bits*i)for i,v in enumerate(a))
    y=sum(int(v)<<(bits*i)for i,v in enumerate(b));v=x*y;mask=(1<<bits)-1
    return trim([((v>>(bits*i))&mask)%p for i in range(len(a)+len(b)-1)])
def divmodp(a,b,p):
    a=trim(a);b=trim(b);need(bool(b),'division by zero')
    q=[0]*max(0,len(a)-len(b)+1);ib=pow(b[-1],-1,p)
    while a and len(a)>=len(b):
        k=len(a)-len(b);c=a[-1]*ib%p;q[k]=c
        for j,bj in enumerate(b):a[k+j]=(a[k+j]-c*bj)%p
        a=trim(a)
    return trim(q),a
def gcdp(a,b,p):
    while b:a,b=b,divmodp(a,b,p)[1]
    return [v*pow(a[-1],-1,p)%p for v in a]if a else []
def invp(a,h,p):
    a=trim(a);r0,r1=h,a;t0,t1=[],[1]
    while r1:
        q,r=divmodp(r0,r1,p);r0,r1=r1,r;t0,t1=t1,sub(t0,conv(q,t1,p),p)
    need(len(r0)==1,'nonunit inverse')
    return divmodp([v*pow(r0[0],-1,p)%p for v in t0],h,p)[1]

class Ring:
    def __init__(self,p,h):
        self.p=p;self.h=trim(h);self.d=len(self.h)-1
        need(self.d>0 and self.h[-1]==1,'monic nonconstant h')
        a=self.h[::-1];b=[1]
        for k in range(1,self.d):b.append(-sum(a[i]*b[k-i]for i in range(1,k+1))%p)
        self.recip=b
    def red(self,a):
        a=trim([v%self.p for v in a])
        if len(a)<=self.d:return a
        if len(a)>2*self.d-1:return divmodp(a,self.h,self.p)[1]
        k=len(a)-self.d
        qrev=conv(a[::-1][:k],self.recip[:k],self.p)
        qrev=(qrev+[0]*k)[:k]
        return sub(a,conv(qrev[::-1],self.h,self.p),self.p)
    def __call__(self,a):
        if isinstance(a,E):need(a.r is self,'ring mismatch');return a
        if isinstance(a,int):a=[a]
        return E(self,self.red(a))

class E:
    def __init__(self,r,a):self.r=r;self.a=tuple(a)
    def __add__(self,b):
        b=self.r(b);return self.r(sub(self.a,[-v%self.r.p for v in b.a],self.r.p))
    __radd__=__add__
    def __neg__(self):return self.r([-v for v in self.a])
    def __sub__(self,b):return self+-self.r(b)
    def __rsub__(self,b):return self.r(b)+-self
    def __mul__(self,b):
        b=self.r(b);return self.r(conv(self.a,b.a,self.r.p))
    __rmul__=__mul__
    def __truediv__(self,b):
        b=self.r(b);return self*self.r(invp(list(b.a),self.r.h,self.r.p))
    def __rtruediv__(self,b):return self.r(b)/self
    def __pow__(self,n):
        need(isinstance(n,int)and n>=0,'power');x=self;y=self.r(1)
        while n:
            if n&1:y=y*x
            x=x*x;n>>=1
        return y
    def __bool__(self):return bool(self.a)
    def __eq__(self,b):return self.a==self.r(b).a
    def unit(self):return gcdp(list(self.a),self.r.h,self.r.p)==[1]

def parse(text):
    # Distinct from source AST parsers: expanded monomial grammar only.
    s=text.replace(' ','').replace('\n','');out={}
    need(s and not re.search(r'[^0-9u*+\-]',s),'bad polynomial alphabet')
    parts=re.findall(r'[+-]?[^+-]+',s)
    need(''.join(parts)==s,'monomial split')
    for term in parts:
        sign=-1 if term.startswith('-')else 1;term=term.lstrip('+-');coef=sign;ex=[0]*3
        tokens=re.split(r'(?<!\*)\*(?!\*)',term)
        for token in tokens:
            if token.isdigit():coef*=int(token)
            else:
                m=re.fullmatch(r'u([123])(?:\*\*(\d+))?',token);need(m is not None,'monomial token')
                ex[int(m[1])-1]+=int(m[2]or 1)
        ex=tuple(ex);out[ex]=out.get(ex,0)+coef
    return {k:v for k,v in out.items()if v}
def derivative(f,j):
    out={}
    for e,c in f.items():
        if e[j]:a=list(e);a[j]-=1;out[tuple(a)]=c*e[j]
    return out
def evaluate(f,u):
    r=u[0].r
    def rec(items,j):
        if not items:return r(0)
        if j==3:return r(sum(c for e,c in items))
        d=max(e[j]for e,c in items);groups={}
        for e,c in items:groups.setdefault(e[j],[]).append((e,c))
        v=r(0)
        for k in range(d,-1,-1):v=v*u[j]+rec(groups.get(k,[]),j+1)
        return v
    return rec(list(f.items()),0)
def det3(a):
    return (a[0][0]*(a[1][1]*a[2][2]-a[1][2]*a[2][1])
            -a[0][1]*(a[1][0]*a[2][2]-a[1][2]*a[2][0])
            +a[0][2]*(a[1][0]*a[2][1]-a[1][1]*a[2][0]))
def solve(a,b):
    a=[list(row)+[rhs]for row,rhs in zip(a,b)];n=len(a)
    for j in range(n):
        piv=next((i for i in range(j,n)if a[i][j].unit()),None)
        need(piv is not None,'no unit pivot for reconstruction')
        a[j],a[piv]=a[piv],a[j];d=a[j][j];a[j]=[v/d for v in a[j]]
        for i in range(n):
            if i!=j:
                d=a[i][j];a[i]=[x-d*y for x,y in zip(a[i],a[j])]
    return [row[-1]for row in a]

def localization_checks(u):
    r=u[0].r;q=[r(4)/3,r(12)/11,r(3)/4]
    alpha=[q[i]-(u[i]-1)**2 for i in range(3)]
    beta=[q[i]+u[i]-1 for i in range(3)]
    for i,x in enumerate(u+beta):need(x.unit(),'chart unit '+str(i))
    zi=[alpha[i]/q[i]for i in range(3)];S=sum(zi)
    A=zi[0]*u[1]/u[0]+zi[1]*u[0]/u[1]
    B=zi[1]*u[2]/u[1]+zi[2]*u[1]/u[2]
    need(zi[1].unit(),'z2 denominator')
    m=(A*(zi[1]+zi[2])+B*(zi[0]+zi[1]))/(4*zi[1])
    X=[alpha[i]/beta[i]for i in range(3)];Y=[beta[i]/q[i]for i in range(3)]
    E1=X[0]**2*(Y[1]**2-Y[2]**2)+X[1]**2*(Y[2]**2-Y[0]**2)+X[2]**2*(Y[0]**2-Y[1]**2)
    for n,x in [('A',A),('B',B),('E1',E1)]:need(x.unit(),'completion unit '+n)
    # Unknown order a,b,c,p,r1,t1. Three right, two left, one trace row.
    o=r(0);one=r(1)
    matrix=[[Y[0],o,o,Y[1],Y[2],o],
            [o,Y[1],o,-Y[0],o,Y[2]],
            [o,o,Y[2],o,-Y[0],-Y[1]],
            [X[0],o,o,-X[1],-X[2],o],
            [o,X[1],o,X[0],o,-X[2]],
            [one,one,one,o,o,o]]
    rhs=[-m*Y[0],-m*Y[1]-2*Y[0],-m*Y[2]-2*Y[0]-2*Y[1],
         -m*X[0]-2*X[1]-2*X[2],-m*X[1]-2*X[2],-m]
    a,b,c,p,r1,t1=solve(matrix,rhs)
    M=[[a,p,r1],[2-p,b,t1],[2-r1,2-t1,c]]
    for i in range(3):
        need(sum(M[i][j]*Y[j]for j in range(3))+m*Y[i]==0,'right kernel')
        need(sum(X[j]*M[j][i]for j in range(3))+m*X[i]==0,'left kernel')
    need(a+b+c+m==0,'trace')
    p0=2*(zi[1]/u[1])*u[0]/A;t0=2*(zi[2]/u[2])*u[1]/B
    d=[q[i]*u[i]/beta[i]for i in range(3)]
    units={}
    for i in range(3):
        units['d'+str(i+1)]=d[i];units['q-d'+str(i+1)]=q[i]-d[i];units['q-d2_'+str(i+1)]=q[i]-d[i]**2
    units.update({'S':S,'A':A,'B':B,'E1':E1,'p0':p0,'2-p0':2-p0,'t0':t0,'2-t0':2-t0,
                  'p':p,'2-p':2-p,'r1':r1,'2-r1':2-r1,'t1':t1,'2-t1':2-t1})
    need(len(units)==23,'unit inventory')
    for n,x in units.items():need(x.unit(),'original localization '+n)
    need(m*m+S-1==0 and A*B+4*zi[1]==0,'path equations')
    return sorted(units)

PINS={'Hp':'2d48d1e4adcb3953cb6c8346e967e26aee6643a8903fa1c655e0b5b7967d6555',
'F':'233a6b3b1e2463c1196ff8fea0042630fa1e14ff5af04d9e9e9976817f9e3adf',
'Htriangle':'f74b6763c65fe4c5de88528f2c3767e78e2813151874e7da8e21bf7bea018807'}
def main():
    need(len(sys.argv)==4,'usage SOURCE_420 CERTIFICATE OUTPUT_JSON')
    source,cp,op=map(Path,sys.argv[1:]);certificate_bytes=cp.read_bytes();cert=json.loads(certificate_bytes);p=cert['prime']
    need(p>3 and all(p%d for d in range(2,int(p**.5)+1))and p not in (11,),'good prime')
    fs=[]
    for n,h in PINS.items():
        path=source/(n+'.txt');source_bytes=path.read_bytes();need(hashlib.sha256(source_bytes).hexdigest()==h,'source pin '+n);fs.append(parse(source_bytes.decode()))
    dfs=[[derivative(f,j)for j in range(3)]for f in fs]
    linear=source/'F_linear.txt';linear_bytes=linear.read_bytes()
    need(hashlib.sha256(linear_bytes).hexdigest()=='d7ea0c89384af78ab1bf679abbaa04cc45bc4d292e31591b407f34077cf4b45c','linear source pin')
    slope=derivative(parse(linear_bytes.decode().replace('v','u1')),0)
    need(all(e[0]==0 for e in slope),'linear degree')
    hs=[];rows=[];total=0
    for k,c in enumerate(cert['components']):
        h=c['h'];need(all(isinstance(v,int)and 0<=v<p for v in h),'canonical h');r=Ring(p,h)
        need(gcdp(h,[(j*h[j])%p for j in range(1,len(h))],p)==[1],'squarefree h')
        for old in hs:need(gcdp(h,old,p)==[1],'components overlap')
        hs.append(h);u=[]
        for n in ('u1','u2','u3'):
            a=c['coordinates'][n];need(len(a)<=r.d and all(isinstance(v,int)and 0<=v<p for v in a),'canonical coordinate');u.append(r(a))
        need(u[2]==r([0,1]),'primitive coordinate u3')
        for i,f in enumerate(fs):need(evaluate(f,u)==0,'source residual '+str(i))
        jac=det3([[evaluate(f,u)for f in row]for row in dfs]);need(jac.unit(),'source Jacobian')
        need(evaluate(slope,u).unit(),'reconstruction slope r')
        units=localization_checks(u);total+=r.d
        rows.append({'index':k,'degree':r.d,'squarefree':True,'residuals_zero':3,'source_jacobian_unit':True,'reconstruction_r_unit':True,'original_unit_count':len(units),'unit_names':units})
    result={'status':'PASS','prime':p,'distinct_geometric_simple_points':total,'components':rows,'source_sha256':PINS,'certificate_sha256':hashlib.sha256(certificate_bytes).hexdigest(),'implementation':'Independent expanded-monomial parser, Python integer convolution and polynomial quotient arithmetic; no third-party imports; Gaussian reconstruction'}
    op.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print('PASS',total)
if __name__=='__main__':main()
