"""Exact characteristic-zero identity of all ten source equations."""
import json
from pathlib import Path
import sys
from flint import fmpz_mpoly_ctx

def need(ok,msg):
    if not ok: raise ValueError(msg)

def check(root):
    source=json.loads((root/'certificates/centre/source_equations.json').read_text())
    order=['u1','u2','u3','m','a','b','c','p','r','t','q1','q2','q3']
    need(source['variable_order']==order,'actual ten-source variable order')
    ring=fmpz_mpoly_ctx.get(tuple(order));v=ring.gens()
    u,q=v[:3],v[10:]; mm=v[3]; a,b,c,p,r,t=v[4:10]
    Q=q[0]*q[1]*q[2]; alpha=[q[i]-(u[i]-1)**2 for i in range(3)]; beta=[q[i]+u[i]-1 for i in range(3)]
    A=q[1]*alpha[0]*u[1]**2+q[0]*alpha[1]*u[0]**2
    B=q[2]*alpha[1]*u[2]**2+q[1]*alpha[2]*u[1]**2
    K=A*(q[2]*alpha[1]+q[1]*alpha[2])*u[2]+B*(q[1]*alpha[0]+q[0]*alpha[1])*u[0]
    M=[[a,p,r],[2-p,b,t],[2-r,2-t,c]]
    e={
      'trace_scalar':Q*(mm**2-1)+sum(q[(i+1)%3]*q[(i+2)%3]*alpha[i] for i in range(3)),
      'path_H':A*B+4*Q*alpha[1]*u[0]*u[1]**2*u[2],
      'path_L':mm*A*B+u[1]*K,
      'triangle_trace':a+b+c+mm,
      'triangle_trace_square':a*a+b*b+c*c+2*(p*(2-p)+r*(2-r)+t*(2-t))-mm*mm-2}
    for i in range(3):
        e['triangle_right_'+str(i+1)]=sum((M[i][j]+(mm if i==j else 0))*beta[j]*q[(j+1)%3]*q[(j+2)%3] for j in range(3))
    for i in range(2):
        e['triangle_left_'+str(i+1)]=sum((M[j][i]+(mm if i==j else 0))*alpha[j]*beta[(j+1)%3]*beta[(j+2)%3] for j in range(3))
    need(set(e)=={x['name'] for x in source['equations']},'complete source inventory')
    for eq in source['equations']:
        actual=ring.from_dict({tuple(x['exponents']):int(x['coefficient']) for x in eq['terms']})
        need(actual==e[eq['name']],'exact integer identity '+eq['name'])
    return {'schema':'complete-qlc-ten-source-binding-v1','status':'PASS',
            'equations':[eq['name'] for eq in source['equations']],
            'all_literal_coefficients_match':True,'no_modular_equality_substituted':True}

if __name__=='__main__':
    if len(sys.argv)!=3: raise SystemExit('usage: geometry_source_binding.py COMPLETE_PROOF OUTPUT_JSON')
    result=check(Path(sys.argv[1]).resolve())
    Path(sys.argv[2]).write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
