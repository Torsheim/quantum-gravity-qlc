#!/usr/bin/env python3
"""No-CAS checker: binds all eight Bezout witnesses to the actual equations.

All arithmetic is polynomial arithmetic in GF(65537)[v]. Explicit guards remain
active under python -O. This checker does not prove support completeness.
"""
import argparse
import json
import re
from pathlib import Path
P=65537

def need(ok,code):
    if not ok:raise ValueError('LINE_WITNESS_FAILURE:'+code)

def trim(a):
    a=[int(x)%P for x in a]
    while len(a)>1 and a[-1]==0:a.pop()
    return a or [0]

def add(*args):
    out=[0]*max(map(len,args))
    for a in args:
        for i,x in enumerate(a):out[i]=(out[i]+x)%P
    return trim(out)

def scale(a,k):return trim([x*k for x in a])
def sub(a,b):return add(a,scale(b,-1))
def mul(a,b):
    out=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):out[i+j]=(out[i+j]+x*y)%P
    return trim(out)
def power(a,n):
    out=[1]
    while n:
        if n&1:out=mul(out,a)
        a=mul(a,a);n//=2
    return out

def sparse(path):
    names=('u1','u2','u3','m');out={}
    for raw in path.read_text().strip().replace(' - ',' + -').split(' + '):
        coefficient=1;exponent=[0]*4
        for part in re.split(r'(?<!\*)\*(?!\*)',raw.strip()):
            mo=re.fullmatch(r'(u1|u2|u3|m)(?:\*\*(\d+))?',part.strip())
            if mo:exponent[names.index(mo[1])]+=int(mo[2] or 1)
            else:coefficient*=int(part)
        key=tuple(exponent);out[key]=(out.get(key,0)+coefficient)%P
    return {e:k for e,k in out.items() if k}

def verify(source,certificate):
    doc=json.loads(certificate.read_text())
    rows=doc['line_screens']
    expected={('alpha1_alpha2',(i,j)) for i in (-1,3) for j in (-2,4)}
    expected|={('alpha2_alpha3',(j,k)) for j in (-2,4) for k in (-6,8)}
    actual=set();tri=sparse(source/'reference/PTH4.txt')
    need(len(rows)==8,'eight rows')
    for row in rows:
        kind=row['class'];fixed=row['fixed'];free=row['free_variable']
        if kind=='alpha1_alpha2':
            need(set(fixed)=={'u1','u2'} and free=='u3','first line coordinates')
            key=(kind,(fixed['u1'],fixed['u2']))
        elif kind=='alpha2_alpha3':
            need(set(fixed)=={'u2','u3'} and free=='u1','second line coordinates')
            key=(kind,(fixed['u2'],fixed['u3']))
        else:raise ValueError('LINE_WITNESS_FAILURE:unknown line class')
        need(key not in actual,'duplicate line');actual.add(key)
        us=[[0,1] if name==free else [fixed[name]%P] for name in ('u1','u2','u3')]
        al=[sub([q],power(sub(v,[1]),2)) for q,v in zip((4,9,49),us)]
        A=add(scale(mul(al[0],power(us[1],2)),9),scale(mul(al[1],power(us[0],2)),4))
        B=add(scale(mul(al[1],power(us[2],2)),49),scale(mul(al[2],power(us[1],2)),9))
        DA=scale(mul(us[0],us[1]),36);DB=scale(mul(us[1],us[2]),441)
        mn=trim(row['m_numerator']);md=trim(row['m_denominator'])
        for label in ('m_denominator','T_denominator','triangle_denominator'):
            need(sum(x%P!=0 for x in row[label])==1,'cleared denominator is h-unit')
        c0=scale(mul(us[1],add(us[0],us[2])),4)
        c1=scale(power(us[1],2),4)
        cnum=add(mul(mul(DA,DB),add(mul(c1,mn),mul(c0,md))),
                 mul(mul(mul(A,DB),sub(power(us[2],2),power(us[1],2))),md),
                 mul(mul(mul(B,DA),sub(power(us[0],2),power(us[1],2))),md))
        need(cnum==[0],'m section solves exact C')
        t0=add(scale(al[0],441),scale(al[1],196),scale(al[2],36),[-1764])
        derived_t=add(scale(power(mn,2),1764),mul(t0,power(md,2)))
        tn=trim(row['T_numerator']);td=trim(row['T_denominator'])
        need(mul(tn,power(md,2))==mul(derived_t,td),'T numerator bound to equation')
        H0=[0];H1=[0]
        for e,k in tri.items():
            need(e[3] in (0,1),'triangle linear in m')
            term=[k]
            for v,n in zip(us,e[:3]):term=mul(term,power(v,n))
            if e[3]:H1=add(H1,term)
            else:H0=add(H0,term)
        derived_h=add(mul(H0,md),mul(H1,mn))
        hn=trim(row['triangle_numerator']);hd=trim(row['triangle_denominator'])
        need(mul(hn,md)==mul(derived_h,hd),'triangle numerator bound to equation')
        need(add(mul(row['bezout_T'],tn),mul(row['bezout_triangle'],hn))==[1],'Bezout equals one')
        need(row['degrees']==[len(tn)-1,len(hn)-1] and row['gcd']==[1],'degree metadata')
    need(actual==expected,'complete eight line inventory')
    return {'status':'PASS','equation_bound_line_witnesses':8,'implementation':'pure Python modular polynomials; no CAS',
            'support_completeness_proved_by_this_checker':False}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('source',type=Path);ap.add_argument('certificate',type=Path);ap.add_argument('output',type=Path)
    args=ap.parse_args();out=verify(args.source,args.certificate)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    print(json.dumps(out,sort_keys=True))
if __name__=='__main__':main()
