"""Characteristic-zero source/centre identities with exact unit quotients.

All integer polynomial files are parsed as data. FLINT computes exact rational
multivariate polynomials; no finite-field comparison is used for these identities.
"""
from pathlib import Path
import json
import sys
import sympy as s
from flint import fmpq_mpoly_ctx, fmpq
from geometry_blocks import polynomial_file


def need(ok,msg):
    if not ok:raise ValueError(msg)


def run(root):
    names=('u1','u2','u3');syms=s.symbols(' '.join(names))
    ring=fmpq_mpoly_ctx.get(names);u=ring.gens()
    q=[fmpq(4,3),fmpq(12,11),fmpq(3,4)];Q=q[0]*q[1]*q[2]
    alpha=[q[i]-(u[i]-1)**2 for i in range(3)]
    beta=[q[i]+u[i]-1 for i in range(3)]
    z=[alpha[i]/q[i] for i in range(3)]
    A=q[1]*alpha[0]*u[1]**2+q[0]*alpha[1]*u[0]**2
    B=q[2]*alpha[1]*u[2]**2+q[1]*alpha[2]*u[1]**2
    K=A*(q[2]*alpha[1]+q[1]*alpha[2])*u[2]+B*(q[1]*alpha[0]+q[0]*alpha[1])*u[0]
    Dpath=q[0]*q[1]**2*q[2]*u[0]*u[1]**2*u[2]
    # Use m*=C/(4 z2); this equals -C/(AB) only modulo Hp.
    # Since Dpath*C=u2*K and z2=alpha2/q2, the following is exact.
    Nm=q[1]*u[1]*K;Dm=4*alpha[1]*Dpath
    base=root/'certificates/geometry/model';centre=root/'certificates/centre'
    def poly(path):
        expr=polynomial_file(path,syms)
        return ring.from_dict({e:fmpq(int(c.p),int(c.q)) for e,c in s.Poly(expr,*syms,domain=s.QQ).terms()})
    # Common denominator covers every invariant monomial before m-substitution.
    zz=s.symbols('z1 z2 z3');ee=s.symbols('a12 a13 a23')
    pair=[(0,1),(0,2),(1,2)]
    edges=[(alpha[i]*q[i]*beta[j]**2+alpha[j]*q[j]*beta[i]**2,
            q[i]*q[j]*beta[i]*beta[j]) for i,j in pair]
    variables=[(z[i],ring.constant(1)) for i in range(3)]+edges
    Dtri=Q**4*beta[0]**4*beta[1]**4*beta[2]**4
    invnums=[]
    for k in (0,1):
        expr=polynomial_file(base/f'invariant_H{k}.txt',(*zz,*ee))
        value=ring.constant(0)
        for exp,c in s.Poly(expr,*zz,*ee,domain=s.QQ).terms():
            numerator=ring.constant(fmpq(int(c.p),int(c.q)));denominator=ring.constant(1)
            for (a,b),degree in zip(variables,exp):
                numerator*=a**degree;denominator*=b**degree
            quotient,remainder=divmod(Dtri,denominator)
            need(not remainder,'common triangle denominator identity')
            value+=numerator*quotient
        invnums.append(value)
    sources={
      'Hp':(A*B+4*Q*alpha[1]*u[0]*u[1]**2*u[2],Dpath),
      'F':(Nm**2+Dm**2*(sum(z)-1),Dm**2),
      'Htriangle':(invnums[0]*Dm+invnums[1]*Nm,Dtri*Dm)}
    unitfactors=set()
    def monic(p):return str(p/p.leading_coefficient())
    for v in [*u,*alpha,*beta,A,B]:
        scalar,factors=v.factor()
        need(bool(scalar),'nonzero declared unit')
        unitfactors.update(monic(f) for f,e in factors)
    records=[]
    for name,(num,den) in sources.items():
        actual=poly(centre/(name+'.txt'))
        quotient,remainder=divmod(num,actual)
        need(not remainder,'exact characteristic-zero numerator identity '+name)
        # Verify the rational quotient is a unit by complete factorization of
        # its numerator and denominator in QQ[u1,u2,u3]. No zero-set claim.
        nf=quotient.factor();df=den.factor()
        for scalar,factors in (nf,df):
            need(bool(scalar),'nonzero rational multiplier '+name)
            for f,e in factors:need(monic(f) in unitfactors,'undeclared factor '+name+':'+str(f))
        row={'name':name,'multiplier_numerator':str(quotient),'multiplier_denominator':str(den),
             'multiplier_numerator_factored':str(nf),'multiplier_denominator_factored':str(df),
             'all_multiplier_factors_are_declared_units':True,
             'degree_u1':int(actual.degrees()[0]),'terms':len(list(actual.terms()))}
        print(name, 'ratio numerator factors', nf,'denominator factors',df,flush=True)
        records.append(row)
    return {'schema':'complete-qlc-centre-source-binding-v1','status':'PASS',
            'centre':['4/3','12/11','3/4'],'m0_numerator':str(Nm),'m0_denominator':str(Dm),
            'bindings':records,'characteristic_zero_exact_identities':True,
            'nonconstant_removed_factors_are_temporal_or_path_units':True}

if __name__=='__main__':
    if len(sys.argv)!=3:raise SystemExit('usage: geometry_centre_binding.py COMPLETE_PROOF OUTPUT_JSON')
    result=run(Path(sys.argv[1]).resolve())
    Path(sys.argv[2]).write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
