"""Resolve the displayed compact-top normalization, without changing baseline."""
import json
from pathlib import Path
import sys
import sympy as s

if len(sys.argv)!=3: raise SystemExit('usage: compact_top_sign.py PACKAGE OUTPUT_JSON')
root=Path(sys.argv[1]).resolve()
output=Path(sys.argv[2])
p=root/'certificates/generic'
x,y,z,m=s.symbols('u1 u2 u3 m')
L=s.sympify((p/'reference/PL4.txt').read_text())
Tnormalized=s.sympify((p/'reference/FT4.txt').read_text())
P0=s.sympify((p/'compact/P0.txt').read_text())
a=s.Poly(L,m).nth(1)
b=s.Poly(L,m).nth(0)
Traw=1764*(m*m-1)+441*(4-(x-1)**2)+196*(9-(y-1)**2)+36*(49-(z-1)**2)
def need(condition,label):
    if not condition:raise RuntimeError(label)
def eliminant(T):
    q=s.Poly(T,m)
    return s.Poly(s.expand(q.nth(2)*b*b+q.nth(0)*a*a),x,y,z)
need(s.expand(Tnormalized+Traw)==0,'FT4 != -Traw')
need(eliminant(Traw)==s.Poly(4*P0,x,y,z),'Traw top eliminant != +4P0')
need(eliminant(Tnormalized)==s.Poly(-4*P0,x,y,z),'FT4 top eliminant != -4P0')
result={'status':'PASS','domain':'Q[u1,u2,u3,m]',
        'FT4_equals_minus_actual_T':True,
        'actual_T_eliminant_over_compact_P0':4,
        'FT4_eliminant_over_compact_P0':-4,
        'historical_source_prose_sign_mismatch':True,
        'included_theory_copy_corrected':True,
        'minimal_prose_fix':'Keep +4P0 and declare T0=P_T|qstar; or keep T0=-P_T|qstar and replace +4P0 by -4P0.',
        'arithmetic_driver_patch_required':False}
output.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print('PASS exact compact-top sign identity')
