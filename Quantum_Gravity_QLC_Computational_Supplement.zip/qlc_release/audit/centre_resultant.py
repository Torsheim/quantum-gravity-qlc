"""Independently certify a bivariate resultant by exact negative specializations.
Usage: MODEL_DIRECTORY RESULTANT_JSON OUTPUT_JSON
No floating arithmetic. Requires python-flint0.9 for integer univariate resultants.
"""
from pathlib import Path
import hashlib,json,re,sys
from flint import fmpz_poly
if hasattr(sys,"set_int_max_str_digits"):sys.set_int_max_str_digits(0)

def need(b,m):
 if not b:raise ValueError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def parse(s):
 s=''.join(s.split());need(s and not re.search(r'[^0-9u*+\-]',s),'source alphabet')
 terms=re.findall(r'[+-]?[^+-]+',s);need(''.join(terms)==s,'source split');out={}
 for term in terms:
  c=-1 if term.startswith('-')else 1;term=term.lstrip('+-');e=[0,0]
  for tok in re.split(r'(?<!\*)\*(?!\*)',term):
   if tok.isdigit():c*=int(tok)
   else:
    m=re.fullmatch(r'u([23])(?:\*\*(\d+))?',tok);need(m is not None,'source monomial')
    e[int(m[1])-2]+=int(m[2]or 1)
  e=tuple(e);out[e]=out.get(e,0)+c
 return {e:c for e,c in out.items()if c}
def specialize(f,t,m):
 a=[0]*(m+1);powers=[1]
 for j in range(max(e[1]for e in f)):powers.append(powers[-1]*t)
 for (i,j),c in f.items():a[i]+=c*powers[j]
 return a
PINS={'12':'ef817f9d685c93d637b71b037122180f81f9a9b62c43979b59bcfaf2a9e631f0','23':'d7093e86c0ddbe0654dfd9446b7200c6bece7a16aea8080d2f4ee71b70f4105b'}
def main():
 need(len(sys.argv)==4,'usage MODEL_DIRECTORY RESULTANT_JSON OUTPUT_JSON')
 model,inp,out=map(Path,sys.argv[1:]);data=inp.read_bytes();j=json.loads(data)
 need(j['status']=='PASS_EXACT_INTEGER_RESULTANT_FACTOR_CERTIFICATE','certificate schema')
 need(j['source_sha256']=={'minors/minor_'+k+'.txt':v for k,v in PINS.items()},'certificate source pair pins');polys=[];degrees=[]
 for n in ['12','23']:
  raw=(model/('minor_'+n+'.txt')).read_bytes();need(sha(raw)==PINS[n],'source pin '+n)
  f=parse(raw.decode());polys.append(f);degrees.append([max(e[i]for e in f)for i in range(2)])
 (m,a),(n,b)=degrees;bound=m*b+n*a
 need(bound==1192,'independently derived degree bound')
 cs=j.get('resultant_coefficients_ascending',j.get('coefficients_ascending'));need(len(cs)-1<=bound and cs[-1]!=0 and all(type(x)is int for x in cs),'claimed polynomial')
 R=fmpz_poly(cs);records=hashlib.sha256();accepted=[];skipped=[];t=-1
 while len(accepted)<bound+1:
  fa=specialize(polys[0],t,m);ga=specialize(polys[1],t,n)
  if fa[-1]==0 or ga[-1]==0:skipped.append(t);t-=1;continue
  actual=int(fmpz_poly(fa).resultant(fmpz_poly(ga)));claimed=int(R(t))
  need(actual==claimed,'exact resultant mismatch at '+str(t))
  records.update((str(t)+':'+str(actual)+'\n').encode());accepted.append(t);t-=1
 result={'status':'PASS','source_pair':['12','23'],'source_sha256':PINS,'source_bidegrees':degrees,'resultant_degree_bound':bound,'claimed_degree':len(cs)-1,'exact_specializations':len(accepted),'first_integer':accepted[0],'last_integer':accepted[-1],'skipped_degree_drop_integers':skipped,'all_source_y_degrees_preserved':True,'resultant_input_sha256':sha(data),'specialization_records_sha256':records.hexdigest(),'proof':'Both polynomial resultants have degree at most1192; equality at1193 distinct integers implies equality overZ. The evaluated source degrees are preserved so the Sylvester resultant specializes correctly.','arithmetic':'Independent restricted monomial parser and exact integer univariate FLINT resultants; negative sample grid disjoint from producer positive interpolation grid.'}
 out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print('PASS',len(accepted),'exact specialization identities')
if __name__=='__main__':main()
