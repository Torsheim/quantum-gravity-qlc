#!/usr/bin/env python3
"""Exact global saturation consequence and all eight exceptional-line exclusions.

The elementary graph model, source normalizations and division-free
eliminants are freshly reconstructed from the supplied flat polynomial data."""
import argparse
import hashlib
import json
from pathlib import Path
import sympy as s

P = 65537
u = s.symbols('u1:4')
q = s.symbols('q1:4')
m, xi, eta = s.symbols('m xi eta')
c = s.symbols('c12 c13 c23')
GV = (*u,m,xi,eta,*c,*q)
UV = (*u,m)
edges = ((0,1),(0,2),(1,2))
checks = []

def require(ok, label):
    if not ok:
        raise RuntimeError('CORE_REPAIR_FAILURE: '+label)
    checks.append(label)

def poly(expr, variables, mod=None):
    return s.Poly(s.expand(expr),*variables,**({'modulus':mod} if mod else {'domain':s.QQ}))

def zero(expr, variables, label):
    require(poly(expr,variables).is_zero,label)

def read(path):
    return s.sympify(path.read_text())

def proportional(a,b,variables,label):
    aa,bb=poly(a,variables),poly(b,variables)
    require(not aa.is_zero and not bb.is_zero,label+': nonzero')
    ratio=s.cancel(aa.LC()/bb.LC())
    zero(aa.as_expr()-ratio*bb.as_expr(),variables,label+': coefficient equality')
    require(int(s.numer(ratio))%P!=0 and int(s.denom(ratio))%P!=0,label+': scalar is p-unit')
    return str(ratio)

def low(f):
    if f.is_zero:return [0]
    return [int(f.nth(i))%P for i in range(f.degree()+1)]

def rational_polys(expr,v,label):
    num,den=s.fraction(s.cancel(expr))
    a,b=s.Poly(num,v,domain=s.ZZ),s.Poly(den,v,domain=s.ZZ)
    # Every cleared denominator must be a unit on the already declared h-open.
    terms=b.terms()
    require(len(terms)==1 and int(terms[0][1])%P!=0,label+': denominator scalar times free coordinate power')
    return s.Poly(a,v,modulus=P),s.Poly(b,v,modulus=P)

def derive(b1):
    a=[q[i]-(u[i]-1)**2 for i in range(3)]
    b=[q[i]+u[i]-1 for i in range(3)]
    Q=s.prod(q)
    A=q[1]*a[0]*u[1]**2+q[0]*a[1]*u[0]**2
    B=q[2]*a[1]*u[2]**2+q[1]*a[2]*u[1]**2
    DA=q[0]*q[1]*u[0]*u[1];DB=q[1]*q[2]*u[1]*u[2]
    R12=q[2]*(q[1]*a[0]+q[0]*a[1]);R23=q[0]*(q[2]*a[1]+q[1]*a[2])
    model={'EA':DA*xi-A,'EB':DB*eta-B,'Hp':q[1]*xi*eta+4*a[1],
           'Lp':Q*xi*eta*m+xi*R23+eta*R12,
           'T':Q*(m*m-1)+sum(Q/q[i]*a[i] for i in range(3))}
    N=[];D=[]
    for k,(i,j) in enumerate(edges):
        N.append(q[i]*a[i]*b[j]**2+q[j]*a[j]*b[i]**2)
        D.append(q[i]*q[j]*b[i]*b[j])
        model['E'+str(i+1)+str(j+1)]=D[-1]*c[k]-N[-1]
    scales={}
    for name,value in model.items():
        scales[name]=proportional(value,read(b1/'reference'/f'{name}.txt'),GV,'same graph '+name)
    H=read(b1/'reference/Htriangle.txt')
    core=4*u[1]**2*m+4*u[1]*(u[0]+u[2])+xi*(u[2]**2-u[1]**2)+eta*(u[0]**2-u[1]**2)
    rhs=4*q[2]*eta*model['EA']+4*q[0]*xi*model['EB']+q[0]*q[2]*(eta*(u[0]**2-u[1]**2)+xi*(u[2]**2-u[1]**2))*model['Hp']
    zero(Q*xi*eta*core-4*u[1]**2*model['Lp']-rhs,GV,'global identity before specialization')
    sec=DB*eta*model['EA']+A*model['EB']
    zero(sec-DA*DB*xi*eta+A*B,GV,'section product identity')
    zero(Q*A*B*core-DA*DB*(4*u[1]**2*model['Lp']+rhs)+Q*core*sec,GV,'explicit Q*A*B*C ideal membership')
    return dict(a=a,b=b,Q=Q,A=A,B=B,DA=DA,DB=DB,N=N,D=D,H=H,core=core,model=model,scales=scales)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('source',type=Path);ap.add_argument('b1',type=Path);ap.add_argument('output',type=Path)
    ar=ap.parse_args();r=ar.source;g=derive(ar.b1)
    spec=dict(zip(q,(4,9,49)))
    spc=lambda x:s.expand(x.subs(spec))
    a=list(map(spc,g['a']));b=list(map(spc,g['b']))
    A,B,DA,DB=map(spc,(g['A'],g['B'],g['DA'],g['DB']))
    PH=s.expand(A*B+4*1764*a[1]*u[0]*u[1]**2*u[2])
    PL=s.cancel(g['model']['Lp'].subs(spec).subs({xi:A/DA,eta:B/DB})*DA*DB/1764)
    T=spc(g['model']['T'])
    # Clear precisely Q^4 beta1^4 beta2^4 beta3^4 in the frozen graph triangle.
    # The global graph generator already carries its own integer normalization.
    Hc=s.Poly(spc(g['H']),*c)
    Ns=list(map(spc,g['N']))
    Hnum=0
    for mon,coef in Hc.terms():
        incident=(mon[0]+mon[1],mon[0]+mon[2],mon[1]+mon[2])
        require(max(incident)<=4,'triangle denominator exponent bounded')
        term=coef*s.prod(Ns[i]**mon[i] for i in range(3))
        term*=s.prod((int(spec[q[i]])*b[i])**(4-incident[i]) for i in range(3))
        Hnum+=term
    Hnum=s.expand(Hnum)
    frozen={k:read(r/'reference'/f'{k}.txt') for k in ('PH4','PL4','FT4','PTH4')}
    bridge={}
    for key,val in zip(('PH4','PL4','FT4','PTH4'),(PH,PL,T,Hnum)):
        bridge[key]=proportional(val,frozen[key],UV,'graph to four '+key)
    triangle=frozen['PTH4']
    require(len(poly(triangle,UV).terms())==1198,'triangle has 1198 terms over Q')
    am=s.Poly(PL,m).nth(1);bm=s.Poly(PL,m).nth(0)
    tm=s.Poly(T,m);hm=s.Poly(triangle,m)
    elim={'PH':PH,'P0':s.expand(am**2*tm.nth(0)+tm.nth(2)*bm**2),
          'PT':s.expand(am*hm.nth(0)-bm*hm.nth(1))}
    require(tm.degree()==2 and tm.nth(1)==0 and hm.degree()==1,'elimination trace degrees')
    zero(am*triangle-hm.nth(1)*PL-elim['PT'],UV,'triangle division-free eliminant')
    zero(am**2*T-tm.nth(2)*(am*m-bm)*PL-elim['P0'],UV,'top division-free eliminant')
    for key,val in elim.items():
        bridge[key+'_over_compact']=proportional(val,read(r/'compact'/f'{key}.txt'),u,'compact coefficient equality '+key)

    # Counterexample to the ORIGINAL unqualified compact degree-642 cover.
    counter=dict(zip(u,(3,4,1)))
    vals={k:int(v.subs(counter))%P for k,v in elim.items()}
    t=s.Symbol('t')
    e=read(r/'compact/E512_mod65537.txt')
    h130=read(r/'compact/excluded_projection_H130.txt')
    ev=int((e*h130).subs(t,1))%P
    require(all(v==0 for v in vals.values()) and ev!=0,'counterexample to unrestricted 642 projection')

    # Exceptional set on D(h): PH=0 and alpha2*B=0 implies alpha2=0,
    # then alpha1*alpha3=0. No additional localization factors are inverted.
    zero(PH-A*B-4*1764*a[1]*u[0]*u[1]**2*u[2],u,'exceptional support identity')
    xs=A/DA;ys=B/DB
    C=s.cancel(spc(g['core']).subs({xi:xs,eta:ys}))
    lines=[]
    cases=[('alpha1_alpha2',{u[0]:i,u[1]:j},u[2]) for i in (-1,3) for j in (-2,4)]
    cases += [('alpha2_alpha3',{u[1]:j,u[2]:k},u[0]) for j in (-2,4) for k in (-6,8)]
    for kind,fixed,v in cases:
        label=kind+':'+','.join(f'{x}={z}' for x,z in fixed.items())
        M=s.cancel(-C.subs(fixed).subs(m,0)/(4*fixed[u[1]]**2))
        mn,md=rational_polys(M,v,label+' m')
        zero(C.subs(fixed).subs(m,M),(v,),label+' C section')
        # PH, PL, and both compact eliminants vanish along each WHOLE line.
        for name,expr in {**elim,'PL':PL}.items():
            zero(expr.subs(fixed), (v,m),label+' compact line '+name)
        tp,td=rational_polys(T.subs(fixed).subs(m,M),v,label+' T')
        hp,hd=rational_polys(triangle.subs(fixed).subs(m,M),v,label+' triangle')
        bt,bh,gcd=s.gcdex(tp,hp)
        require(gcd==s.Poly(1,v,modulus=P),label+' gcd one')
        require(bt*tp+bh*hp==s.Poly(1,v,modulus=P),label+' Bezout identity')
        lines.append({'label':label,'class':kind,'fixed':{str(k):int(vv) for k,vv in fixed.items()},
                      'free_variable':str(v),'m_numerator':low(mn),'m_denominator':low(md),
                      'T_numerator':low(tp),'T_denominator':low(td),
                      'triangle_numerator':low(hp),'triangle_denominator':low(hd),
                      'bezout_T':low(bt),'bezout_triangle':low(bh),
                      'degrees':[tp.degree(),hp.degree()],'gcd':[1]})
    require(len(lines)==8 and len({r['label'] for r in lines})==8,'all eight distinct lines')
    out={'schema':'generic-exceptional-lines-v1','status':'PASS','control':{'q':[4,9,49],'p':P},
         'counterexample_to_original_642_cover':{'u':[3,4,1],'compact_residuals':vals,'E512_H130_at_u3':ev},
         'graph_scales':g['scales'],'bridge_scales':bridge,'line_screens':lines,
         'scope':'global C identity and graph bridge; all eight double-alpha lines on D(h)',
         'check_count':len(checks),'checks':checks}
    ar.output.parent.mkdir(parents=True,exist_ok=True)
    ar.output.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':'PASS','line_count':len(lines),'output':str(ar.output)},sort_keys=True))

if __name__=='__main__':main()
