#!/usr/bin/env python3
"""Exact finite-chart boundary computations over the declared global family.

Adapted from the existing exact symbolic implementation. No historical
module or archive is imported; every polynomial identity is recomputed."""
import argparse
import hashlib
import itertools
import json
from pathlib import Path

import sympy as s

P = 65537
Q0 = (4, 9, 49)
u = s.symbols('u1:4')
q = s.symbols('q1:4')
m, xi, eta = s.symbols('m xi eta')
c = s.symbols('c12 c13 c23')
edges = ((0, 1), (0, 2), (1, 2))
global_vars = (*u, m, xi, eta, *c, *q)
symbols = {str(v): v for v in global_vars}
checks = []


def require(condition, label):
    if not condition:
        raise RuntimeError('EXACT_REVIEW_FAILURE: ' + label)
    checks.append(label)


def fp(expr, *variables):
    return s.Poly(s.expand(expr), *variables, modulus=P)


def eq(a, b, variables, label, modulus=None):
    require(s.Poly(s.expand(a-b), *variables, **({'modulus': modulus} if modulus else {'domain': s.QQ})).is_zero, label)


def record(expr, variables, modulus=P):
    poly = s.Poly(expr, *variables, **({'modulus': modulus} if modulus else {'domain': s.QQ}))
    return {'polynomial': str(poly.as_expr()), 'variables': [str(v) for v in variables],
            'coefficient_rows': [[list(mon), str(coef) if modulus is None else int(coef) % modulus] for mon, coef in poly.terms()]}


def rational_mod(expr, *variables):
    numerator, denominator = s.fraction(s.cancel(expr))
    np = s.Poly(numerator, *variables, domain=s.QQ)
    dp = s.Poly(denominator, *variables, domain=s.QQ)
    scale = s.ilcm(*[s.denom(z) for z in (*np.coeffs(), *dp.coeffs(), s.Integer(1), s.Integer(1))])
    ni, di = s.Poly(np.as_expr()*scale, *variables, domain=s.ZZ), s.Poly(dp.as_expr()*scale, *variables, domain=s.ZZ)
    require(int(scale) % P != 0, 'rational coefficient denominators are p-units')
    return fp(ni.as_expr(), *variables), fp(di.as_expr(), *variables), ni, di


def derive():
    a = [q[i]-(u[i]-1)**2 for i in range(3)]
    b = [q[i]+u[i]-1 for i in range(3)]
    Q = s.prod(q)
    A = q[1]*a[0]*u[1]**2 + q[0]*a[1]*u[0]**2
    B = q[2]*a[1]*u[2]**2 + q[1]*a[2]*u[1]**2
    DA, DB = q[0]*q[1]*u[0]*u[1], q[1]*q[2]*u[1]*u[2]
    R12, R23 = q[2]*(q[1]*a[0]+q[0]*a[1]), q[0]*(q[2]*a[1]+q[1]*a[2])
    T = Q*(m*m-1) + sum(Q/q[i]*a[i] for i in range(3))
    M = {'EA': DA*xi-A, 'EB': DB*eta-B, 'Hp': q[1]*xi*eta+4*a[1],
         'Lp': Q*xi*eta*m+xi*R23+eta*R12, 'T': T}
    N, D = [], []
    for n, (i,j) in enumerate(edges):
        N.append(q[i]*a[i]*b[j]**2 + q[j]*a[j]*b[i]**2)
        D.append(q[i]*q[j]*b[i]*b[j])
        M['E'+str(i+1)+str(j+1)] = D[-1]*c[n]-N[-1]

    # Each listed seed is (coefficient, z1,z2,z3,a12,a13,a23 exponents).
    # Permute exponent positions, retaining each distinct monomial once.
    h1_seeds = [(16,(1,1,0,1,0,0)),(8,(1,0,0,1,0,1)),
                (-4,(0,0,0,3,0,0)),(4,(0,0,0,2,1,0))]
    h0_seeds = [(16,(2,1,0,0,0,0)),(16,(2,0,0,0,0,1)),
                (-4,(1,1,0,2,0,0)),(16,(1,1,0,0,1,0)),
                (-4,(1,0,0,1,1,1)),(8,(1,0,0,1,0,1)),
                (1,(0,0,0,4,0,0)),(4,(0,0,0,3,0,0)),
                (-2,(0,0,0,2,2,0)),(-4,(0,0,0,2,1,0))]
    coordinates = tuple(a[i]/q[i] for i in range(3)) + c
    def orbit_seed(exponents):
        images = set()
        for perm in itertools.permutations(range(3)):
            dest = list(perm) + [3+edges.index(tuple(sorted((perm[i],perm[j])))) for i,j in edges]
            out = [0]*6
            for source, target in enumerate(dest): out[target] = exponents[source]
            images.add(tuple(out))
        return sum(s.prod(z**e for z,e in zip(coordinates, exp)) for exp in sorted(images))
    H1 = sum(coef*orbit_seed(exp) for coef,exp in h1_seeds)
    H0 = sum(coef*orbit_seed(exp) for coef,exp in h0_seeds) + 32*s.prod(coordinates[:3])+16*s.prod(c)
    raw = s.Poly(s.expand(Q**4*(H0+m*H1)), *global_vars, domain=s.ZZ)
    content, primitive = raw.primitive()
    if primitive.LC() < 0: primitive = -primitive
    M['Htriangle'] = primitive.as_expr()
    return {'M': {key:s.expand(value) for key,value in M.items()}, 'a':a, 'b':b,
            'A':A,'B':B,'DA':DA,'DB':DB,'R12':R12,'R23':R23,'Q':Q,'N':N,'D':D,
            'orbit_raw_content':int(content)}


def matrix_inverse_and_det(matrix):
    """Gauss-Jordan over GF(P); no SymPy Matrix.inv_mod/det call."""
    n = len(matrix)
    work = [[int(matrix[i][j]) % P for j in range(n)] + [int(i==j) for j in range(n)] for i in range(n)]
    det = 1
    for col in range(n):
        pivot = next((row for row in range(col,n) if work[row][col]), None)
        if pivot is None: raise ValueError('singular multiplication map')
        if pivot != col: work[pivot], work[col] = work[col], work[pivot]; det = -det
        entry = work[col][col]
        det = det*entry % P
        inv = pow(entry,-1,P)
        work[col] = [value*inv % P for value in work[col]]
        for row in range(n):
            if row == col: continue
            factor = work[row][col]
            work[row] = [(a-factor*b) % P for a,b in zip(work[row],work[col])]
    return [row[n:] for row in work], det % P


class Quotient:
    def __init__(self, generators, variables):
        self.vars = variables
        self.g = s.groebner(generators,*variables,order='lex',modulus=P,method='buchberger')
        require(self.g.is_zero_dimensional, 'endpoint quotient zero-dimensional')
        leading = [poly.monoms()[0] for poly in self.g.polys]
        bounds = []
        for i in range(len(variables)):
            pure = [mon[i] for mon in leading if mon[i] and all(mon[j]==0 for j in range(len(variables)) if j!=i)]
            require(bool(pure), 'pure power in leading ideal')
            bounds.append(min(pure))
        self.mons = sorted(mon for mon in itertools.product(*(range(v) for v in bounds)) if not any(all(mon[i]>=lead[i] for i in range(len(mon))) for lead in leading))
        self.basis = [s.prod(v**e for v,e in zip(variables,mon)) for mon in self.mons]
        self.n = len(self.mons)
        self.one = self.vector(s.Integer(1))
        self.table = [[self.vector(a*b) for b in self.basis] for a in self.basis]

    def vector(self, expr):
        rem = fp(self.g.reduce(s.expand(expr))[1],*self.vars)
        d = rem.as_dict()
        require(all(mon in self.mons for mon in d), 'standard monomial span')
        return [int(d.get(mon,0)) % P for mon in self.mons]

    def expr(self, v): return fp(sum(z*t for z,t in zip(v,self.basis)),*self.vars).as_expr()
    def add(self,a,b): return [(x+y)%P for x,y in zip(a,b)]
    def scale(self,a,n): return [int(n)*x%P for x in a]
    def mul(self,a,b):
        out=[0]*self.n
        for i,x in enumerate(a):
            if not x: continue
            for j,y in enumerate(b):
                if y:
                    for k,z in enumerate(self.table[i][j]): out[k]=(out[k]+x*y*z)%P
        return out
    def power(self,a,n):
        out=self.one
        while n:
            if n%2: out=self.mul(out,a)
            n//=2
            if n: a=self.mul(a,a)
        return out
    def inverse(self,a):
        cols=[self.mul(a,self.vector(z)) for z in self.basis]
        inv, det=matrix_inverse_and_det([[cols[j][i] for j in range(self.n)] for i in range(self.n)])
        answer=[sum(inv[i][j]*self.one[j] for j in range(self.n))%P for i in range(self.n)]
        require(self.mul(a,answer)==self.one,'quotient inverse product equals one')
        return answer,det


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('b1',type=Path); parser.add_argument('b',type=Path); parser.add_argument('output',type=Path)
    args=parser.parse_args()
    Z=derive(); M=Z['M']; spec=dict(zip(q,Q0))
    S={key:s.expand(value.subs(spec)) for key,value in M.items()}
    W={key:s.expand(Z[key].subs(spec)) for key in ('A','B','DA','DB','R12','R23','Q')}
    a=[v.subs(spec) for v in Z['a']]; b=[v.subs(spec) for v in Z['b']]
    evidence={'schema':'generic-finite-chart-boundary-v1','same_CAS':'SymPy '+s.__version__,
              'legacy_audit_imported':False,'global_generators':{},'charts':{},'mixed':{},'multiple_beta':{},'single_beta':{},'beta_open':{}}
    for name,derived in M.items():
        frozen=s.sympify((args.b1/'reference'/f'{name}.txt').read_text(),locals=symbols)
        eq(derived,frozen,global_vars,'global generator '+name)
        evidence['global_generators'][name]={'terms':len(s.Poly(derived,*global_vars).terms()),'coefficientwise_equal':True}
    evidence['orbit_raw_content']=Z['orbit_raw_content']
    chartdata=json.loads((args.b1/'generated/global_path_charts.json').read_text())
    x1,e1,x2,y2,d3,y3=s.symbols('x1 e1 x2 y2 d3 y3')
    chart_specs=[('U1_endpoint',{xi:x1/u[0],eta:u[0]*e1},[1,1,1,u[0],1]),
                 ('U2_double_pole',{xi:x2/u[1],eta:y2/u[1]},[1,1,u[1]**2,u[1]**2,1]),
                 ('U3_endpoint',{xi:u[2]*d3,eta:y3/u[2]},[1,1,1,u[2],1])]
    for name,sub,multipliers in chart_specs:
        eqs=[s.cancel(M[key].subs(sub)*fac) for key,fac in zip(('EA','EB','Hp','Lp','T'),multipliers)]
        allvars=tuple(sorted(set().union(*(e.free_symbols for e in eqs)),key=str))
        for n,(e,text) in enumerate(zip(eqs,chartdata[name]['equations'])):
            require(s.denom(e)==1,'global necessary chart is polynomial '+name+str(n))
            eq(e,s.sympify(text),allvars,'global chart '+name+str(n))
        evidence['charts'][name]=[str(e) for e in eqs]
    words=[''.join(t) for t in itertools.product('BNU',repeat=3) if 'B' in t and 'U' in t]
    require(len(words)==12,'mixed inventory cardinality')
    all_boundary=[''.join(t) for t in itertools.product('BNU',repeat=3) if ''.join(t)!='NNN']
    classes={'beta_open_U':[t for t in all_boundary if 'U' in t and 'B' not in t],
             'single_B':[t for t in all_boundary if t.count('B')==1 and 'U' not in t],
             'multiple_B':[t for t in all_boundary if t.count('B')>=2 and 'U' not in t], 'mixed':words}
    require([len(v) for v in classes.values()]==[7,3,4,12],'all 26 disjoint classes')
    evidence['support_partition']=classes
    evidence['same_index_units']=[{'unit':v-1,'inverse':pow(v-1,-1,P)} for v in Q0]
    for i in range(3): eq(Z['b'][i]-u[i],q[i]-1,global_vars,'same-index unit identity')
    endpoint_spec={'UBN':(W['B'],W['R23'],u[2]),'UNB':(W['B'],W['R23'],u[1]),
                   'BNU':(W['A'],W['R12'],u[1]),'NBU':(W['A'],W['R12'],u[0])}
    for word in words:
        sub={u[i]:0 if t=='U' else 1-Q0[i] for i,t in enumerate(word) if t!='N'}
        out={'support':word,'substitution':{str(k):v for k,v in sub.items()}}
        if word in endpoint_spec:
            F,G,v=endpoint_spec[word]; F,G=fp(F.subs(sub),v),fp(G.subs(sub),v)
            X,Y,g=s.gcdex(F,G)
            require(g.as_expr()==1,'endpoint gcd '+word)
            eq(X.as_expr()*F.as_expr()+Y.as_expr()*G.as_expr(),1,(v,),'Bezout '+word,P)
            out.update({'kind':'Bezout','F':record(F.as_expr(),(v,)),'G':record(G.as_expr(),(v,)),
                        's':str(X.as_expr()),'t':str(Y.as_expr()),'resultant_mod_p':int(s.resultant(F.as_expr(),G.as_expr(),v))%P})
        else:
            aval,bval=s.expand(W['A'].subs(sub)),s.expand(W['B'].subs(sub))
            out.update({'A':str(aval),'B':str(bval),'alpha2':str(a[1].subs(sub)),
                        'R12':str(W['R12'].subs(sub)),'R23':str(W['R23'].subs(sub))})
            if word in ('BUN','NUB','BUB'):
                for expr in (aval,bval):
                    poly=s.Poly(expr,*u)
                    require(len(poly.terms())==1 and int(poly.LC())%P!=0,'middle unit monomial '+word)
                out['kind']='middle double pole'
            elif word in ('UUB','BUU'):
                key='R12' if word=='UUB' else 'R23'
                require(int(W[key].subs(sub))%P!=0,'corner unit '+word)
                out['kind']='adjacent unique pole'
            elif word=='UBU':
                require(int(aval)%P!=0 and int(bval)%P!=0,'separated endpoint numerators units')
                out['kind']='separated double pole'
            else:
                require(int(aval)%P!=0 and int(bval)%P!=0,'two beta mixed numerator units '+word)
                key='DB' if word=='UBB' else 'DA'
                numerator=bval if word=='UBB' else aval
                out['finite_path_section_mod_p']=int(numerator)*pow(int(W[key].subs(sub)),-1,P)%P
                out['kind']='one pole times one finite unit'
        evidence['mixed'][word]=out
    w=s.Symbol('w')
    for pair in itertools.combinations(range(3),2):
        k=next(i for i in range(3) if i not in pair)
        sub={u[i]:1-Q0[i] for i in pair}
        polynomials=[s.expand(S[key].subs(sub)) for key in ('EA','EB','Hp','Lp','T')]
        raw=s.groebner(polynomials,u[k],m,xi,eta,order='grevlex',modulus=P,method='buchberger')
        loc=s.groebner(polynomials+[w*u[k]-1],w,u[k],m,xi,eta,order='lex',modulus=P,method='buchberger')
        name='beta'+str(pair[0]+1)+'_beta'+str(pair[1]+1)
        require([v.as_expr() for v in raw.polys]==[1] and [v.as_expr() for v in loc.polys]==[1],'multiple-beta unit '+name)
        evidence['multiple_beta'][name]={'variables':[str(u[k]),'m','xi','eta'], 'five_path_polynomials':[str(v) for v in polynomials], 'raw_groebner':['1'],'localized_groebner':['1']}
    for i in range(3):
        adjacent=[c[n] for n,e in enumerate(edges) if i in e]
        hpoly=fp(S['Htriangle'],*c,*u,m)
        idx=[(*c,*u,m).index(v) for v in adjacent]
        deg=max(sum(mon[j] for j in idx) for mon,coef in hpoly.terms())
        leading=sum(coef*s.prod(v**n for v,n in zip((*c,*u,m),mon)) for mon,coef in hpoly.terms() if sum(mon[j] for j in idx)==deg)
        require(deg==4,'pair-leading degree beta'+str(i+1))
        eq(leading,314*(adjacent[0]**2-adjacent[1]**2)**2,(*c,*u,m),'pair leading form '+str(i+1),P)
        require(int(a[i].subs(u[i],1-Q0[i]))%P!=0,'single-beta alpha unit '+str(i+1))
        j,k=[v for v in range(3) if v!=i]
        for sign in (1,-1):
            relation=sign*s.Rational(Q0[k],Q0[j])*b[j]-(Q0[k]-1)
            sub={u[i]:1-Q0[i],u[k]:relation}
            X=s.cancel((W['A']/W['DA']).subs(sub)); Y=s.cancel((W['B']/W['DB']).subs(sub))
            HP=s.cancel((Q0[1]*X*Y+4*a[1].subs(sub)))
            LP=s.cancel(int(W['Q'])*X*Y*m+X*W['R23'].subs(sub)+Y*W['R12'].subs(sub))
            TP=s.expand(S['T'].subs(sub))
            hp,hd,hi,hdi=rational_mod(HP,u[j])
            lp,ld,li,ldi=rational_mod(LP,u[j],m)
            tp,td,ti,tdi=rational_mod(TP,u[j],m)
            require(lp.degree(m)==1 and tp.degree(m)==2,'single-beta trace degrees')
            av=s.Poly(lp.as_expr(),m).coeff_monomial(m); bv=s.Poly(lp.as_expr(),m).coeff_monomial(1)
            Qv=s.Poly(tp.as_expr(),m).coeff_monomial(m*m); tv=s.Poly(tp.as_expr(),m).coeff_monomial(1)
            res=fp(Qv*bv*bv+av*av*tv,u[j])
            eq(av*av*tp.as_expr()-Qv*(av*m-bv)*lp.as_expr(),res.as_expr(),(u[j],m),'division-free trace identity',P)
            require(s.gcd(hp,res).degree()==0,'single beta resultant unit')
            hb,rb,gg=s.gcdex(hp,res)
            eq(hb.as_expr()*hp.as_expr()+rb.as_expr()*res.as_expr(),1,(u[j],),'single-beta Bezout',P)
            hq=s.Poly(hi.as_expr(),u[j],domain=s.QQ)
            rq=s.Poly(s.resultant(li.as_expr(),ti.as_expr(),m),u[j],domain=s.QQ)
            require(hq.degree()==hp.degree() and rq.degree()==res.degree(),'single-beta no degree drop')
            denominators=fp(hd.as_expr()*ld.as_expr()*td.as_expr(),u[j],m)
            require(denominators.degree(m)==0,'trace denominators independent of m')
            dpoly=fp(denominators.as_expr(),u[j]); apoly=fp(av,u[j])
            name='beta'+str(i+1)+'_sign_'+str(sign)
            evidence['single_beta'][name]={'relation':str(relation),'variable':str(u[j]),'Hp':record(hp.as_expr(),(u[j],)),
              'linear_trace':record(lp.as_expr(),(u[j],m)),'quadratic_trace':record(tp.as_expr(),(u[j],m)),
              'division_free_resultant':record(res.as_expr(),(u[j],)), 'bezout_Hp':str(hb.as_expr()),'bezout_resultant':str(rb.as_expr()),
              'degrees':[hp.degree(),res.degree()],'characteristic_zero_degrees':[hq.degree(),rq.degree()],
              'leading_coefficients_mod_p':[int(hp.LC())%P,int(res.LC())%P],
              'combined_denominator':str(dpoly.as_expr()),'gcd_Hp_denominator':str(s.gcd(hp,dpoly).as_expr()),
              'gcd_Hp_m_leading_coefficient':str(s.gcd(hp,apoly).as_expr()),'gcd_Hp_resultant':'1',
              'full_Hp_denominator_locus':str(s.gcd(s.gcd(hp,res),dpoly).as_expr()),
              'full_Hp_m_degree_drop_locus':str(s.gcd(s.gcd(hp,res),apoly).as_expr())}
    for side,index,spatial,keys in [('left',0,(u[1],u[2]),('B','R23')),('right',2,(u[0],u[1]),('A','R12'))]:
        zero={u[index]:0}
        generators=[W[key].subs(zero) for key in keys]
        A=Quotient(generators,spatial)
        require(A.n==8,'endpoint quotient dimension '+side)
        # Evaluate rational triangle sections entirely in the quotient.
        sections=[]; denprod=A.one
        for numerator,denominator in zip(Z['N'],Z['D']):
            nv=A.vector(numerator.subs(spec).subs(zero)); dv=A.vector(denominator.subs(spec).subs(zero))
            inv,_=A.inverse(dv)
            sections.append(A.mul(nv,inv)); denprod=A.mul(denprod,dv)
        hcoeff=[ [0]*A.n, [0]*A.n ]
        h=fp(S['Htriangle'].subs(zero),*c,m,*spatial)
        basevecs=[A.vector(v) for v in spatial]
        for mon,coefficient in h.terms():
            require(mon[3]<=1,'triangle linear in trace')
            value=A.scale(A.one,int(coefficient))
            for power,vector in zip(mon[:3],sections): value=A.mul(value,A.power(vector,power))
            for power,vector in zip(mon[4:],basevecs): value=A.mul(value,A.power(vector,power))
            hcoeff[mon[3]]=A.add(hcoeff[mon[3]],value)
        clear=A.power(denprod,4)
        hc=[A.mul(v,clear) for v in hcoeff]
        top=S['T'].subs(zero)
        top0=A.vector(top.subs(m,0)); Qv=int(W['Q'])
        resultant=A.add(A.scale(A.mul(hc[0],hc[0]),Qv),A.mul(A.mul(hc[1],hc[1]),top0))
        inverse,det=A.inverse(resultant)
        require([v.as_expr() for v in s.groebner([*generators,A.expr(resultant)],*spatial,modulus=P).polys]==[1],'endpoint direct unit ideal '+side)
        evidence['beta_open'][side]={'method':'rational section evaluation within quotient; denominator units checked; custom finite-field Gauss-Jordan',
           'base_generators':[str(fp(v,*spatial).as_expr()) for v in generators],'groebner':[str(v.as_expr()) for v in A.g.polys],
           'standard_monomials':[str(v) for v in A.basis], 'dimension':A.n,'reduced_cleared_H':str(A.expr(hc[0])+m*A.expr(hc[1])),
           'obstruction':str(A.expr(resultant)),'inverse':str(A.expr(inverse)),'multiplication_determinant_mod_p':det,'unit_ideal':['1']}
    origin={v:0 for v in u}
    sections=[s.cancel((nv/dv).subs(spec).subs(origin)) for nv,dv in zip(Z['N'],Z['D'])]
    Horigin,_,_,_=rational_mod(S['Htriangle'].subs(origin).subs(dict(zip(c,sections))),m)
    Torigin=fp(S['T'].subs(origin),m)
    root=(-int(Horigin.nth(0))*pow(int(Horigin.nth(1)),-1,P))%P
    residual=int(Torigin.eval(root))%P
    require(residual!=0,'triple origin incompatible trace equations')
    require(root==1070 and residual==18263,'triple origin numerical data')
    evidence['beta_open']['triple_origin']={'triangle_sections':[str(v) for v in sections],'H':str(Horigin.as_expr()),'T':str(Torigin.as_expr()),'forced_m':root,'T_residual':residual}
    evidence['beta_open']['valuation_cases']={'UNN':'left quotient unit','NUN':'middle double pole','NNU':'right quotient unit','UUN':'R12(0,0,u3)=2891 unique pole','UNU':'two endpoint poles contradict Hp','NUU':'R23(u1,0,0)=3296 unique pole','UUU':'triple-origin trace incompatibility'}
    evidence['status']='PASS'
    evidence['scope']='Finite (u,m) control fibre of global graph closure on V(u1*u2*u3*beta1*beta2*beta3); no proper-boundary, flatness, degree or C/D closure claim.'
    evidence['check_labels']=checks; evidence['check_count']=len(checks)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(evidence,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':'PASS','check_count':len(checks),'mixed':len(words),'single_beta':len(evidence['single_beta']), 'endpoint_determinants':[evidence['beta_open'][side]['multiplication_determinant_mod_p'] for side in ('left','right')],'output_sha256':hashlib.sha256(args.output.read_bytes()).hexdigest()},sort_keys=True))


if __name__=='__main__': main()
