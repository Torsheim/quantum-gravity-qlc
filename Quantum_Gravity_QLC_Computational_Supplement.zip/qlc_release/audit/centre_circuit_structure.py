"""Independent literal binding of the rational circuit to the published formulas.
Usage: centre_circuit_structure.py FLAT_CENTRE_DIRECTORY OUTPUT_JSON
Only AST/list equality is required; no residue computation or previous verdict.
"""
from pathlib import Path
import hashlib,json,sys

def need(b,m):
    if not b:raise ValueError(m)
def op(o,*a):return [o,*a]
def neg(x):return op('neg',x)
def add(*x):return op('add',*x)
def mul(*x):return op('mul',*x)
def div(x,y):return op('div',x,y)
def power(x,k):return op('pow',x,k)
def main(data,output):
    raw=(data/'rational_circuit.json').read_bytes();c=json.loads(raw);rows=[]
    def node(n,e):rows.append([n,e])
    node('u3',op('parameter'))
    node('projection_numerator',op('univariate','numerator_coefficients_ascending','u3'))
    node('projection_denominator',op('univariate','denominator_coefficients_ascending','u3'))
    node('u2',div('projection_numerator','projection_denominator'))
    node('r_slope',op('bivariate','r_terms','u2','u3'))
    node('s_constant',op('bivariate','s_terms','u2','u3'))
    node('u1',div(neg('r_slope'),'s_constant'))
    for j,(num,den) in enumerate([(4,3),(12,11),(3,4)],1):
        q,u,alpha,beta,zeta,X,Y,d=[f'{n}{j}' for n in ['q','u','alpha','beta','zeta','X','Y','d']]
        node(q,div(num,den));node(alpha,add(q,neg(power(add(u,-1),2))));node(beta,add(q,u,-1))
        node(zeta,div(alpha,q));node(X,div(alpha,beta));node(Y,div(beta,q));node(d,div(mul(q,u),beta))
    node('S',add('zeta1','zeta2','zeta3'))
    node('A',add(div(mul('zeta1','u2'),'u1'),div(mul('zeta2','u1'),'u2')))
    node('B',add(div(mul('zeta2','u3'),'u2'),div(mul('zeta3','u2'),'u3')))
    node('m',div(add(mul('A',add('zeta2','zeta3')),mul('B',add('zeta1','zeta2'))),mul(4,'zeta2')))
    node('E1',add(*(mul(power(f'X{j}',2),add(power(f'Y{k}',2),neg(power(f'Y{l}',2)))) for j,k,l in [(1,2,3),(2,3,1),(3,1,2)])))
    M=[['Y1',0,0,'Y2','Y3',0],[0,'Y2',0,neg('Y1'),0,'Y3'],[0,0,'Y3',0,neg('Y1'),neg('Y2')],['X1',0,0,neg('X2'),neg('X3'),0],[0,'X2',0,'X1',0,neg('X3')],[1,1,1,0,0,0]]
    w=[neg(mul('m','Y1')),add(neg(mul('m','Y2')),neg(mul(2,'Y1'))),add(neg(mul('m','Y3')),neg(mul(2,'Y1')),neg(mul(2,'Y2'))),add(neg(mul('m','X1')),neg(mul(2,'X2')),neg(mul(2,'X3'))),add(neg(mul('m','X2')),neg(mul(2,'X3'))),neg('m')]
    node('triangle_determinant',op('det',M))
    for k,n in enumerate(['a','b','c','p','r1','t1']):
        mk=[[w[i] if j==k else M[i][j] for j in range(6)] for i in range(6)]
        node(n,div(op('det',mk),'triangle_determinant'))
    node('p0',div(mul(2,'zeta2','u1'),mul('u2','A')));node('t0',div(mul(2,'zeta3','u2'),mul('u3','B')))
    for n in ['p0','t0','p','r1','t1']:node('2-'+n,add(2,neg(n)))
    for j in range(1,4):
        node(f'q_minus_d{j}',add(f'q{j}',neg(f'd{j}')))
        node(f'q_minus_d2_{j}',add(f'q{j}',neg(power(f'd{j}',2))))
    need(c['nodes_in_evaluation_order']==rows,'literal53-node circuit differs from displayed reconstruction formulas')
    units=['S','A','B','E1','p0','t0','p','r1','t1','2-p0','2-t0','2-p','2-r1','2-t1']
    for j in range(1,4):units += [f'd{j}',f'q_minus_d{j}',f'q_minus_d2_{j}']
    need(c['original_23_units']==units,'literal original23-unit inventory')
    def count(e):return (int(e[0]=='div')+sum(count(a) for a in e[1:])) if isinstance(e,list) and e and isinstance(e[0],str) else sum(count(a) for a in e) if isinstance(e,list) else 0
    divisions=sum(count(e) for n,e in rows)
    need(len(rows)==53 and divisions==30 and len(units)==23,'counts')
    result={'status':'PASS_LITERAL_FORMULA_BINDING','circuit_sha256':hashlib.sha256(raw).hexdigest(),'nodes':53,'divisions':30,'original_units':23,'method':'Exact list/AST equality with independently assembled displayed source and Cramer reconstruction formulas; no modular substitutions','scope':'Binds serialization to formulas; exact determinant/source identities and unit descent remain separate necessary premises'}
    output.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(result['status'])
if __name__=='__main__':
    need(len(sys.argv)==3,'usage FLAT_CENTRE_DIRECTORY OUTPUT_JSON');main(*map(Path,sys.argv[1:]))
