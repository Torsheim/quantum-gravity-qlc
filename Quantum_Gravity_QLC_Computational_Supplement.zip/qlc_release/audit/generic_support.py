#!/usr/bin/env python3
"""Exact finite projection, excluded residue branches and RUR reconstruction.

The compact support statement is restricted to its declared open.
All resultants, residue-field branches and coordinate residues are recomputed."""
from __future__ import annotations
import argparse
import hashlib
import itertools
import json
from pathlib import Path
import sympy as sp
from flint import nmod_poly, nmod_mpoly_ctx

P = 65537
X,Y,Z,T,M = sp.symbols('u1 u2 u3 t m')
ZERO = nmod_poly([], P)
ONE = nmod_poly([1], P)
PARAM = nmod_poly([0,1], P)

class AuditFailure(RuntimeError):
    pass

def require(name, condition):
    if not condition:
        raise AuditFailure(name)

def coefficients(poly):
    return [int(c) for c in poly.coeffs()]

def dump(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

class Quotient:
    """Fp[t]/modulus. Each inverse is checked, even for reducible modulus."""
    def __init__(self, modulus):
        self.modulus = modulus
    def mult(self, a, b):
        return (a*b) % self.modulus
    def inv(self, a):
        g, s, _ = a.xgcd(self.modulus)
        require('nonunit_coefficient_pivot', g.degree() == 0)
        return (s * pow(int(g[0]), -1, P)) % self.modulus
    def trim(self, a):
        while a and not a[-1]:
            a.pop()
        return a
    def monic(self, a):
        a = self.trim(a)
        if not a:
            return []
        c = self.inv(a[-1])
        return [self.mult(v,c) for v in a]
    def divmod(self, a, b):
        require('division_by_zero_polynomial', bool(b))
        r=a.copy(); q=[ZERO]*max(0, len(a)-len(b)+1)
        bi=self.inv(b[-1])
        while len(r)>=len(b):
            delta=len(r)-len(b); c=self.mult(r[-1],bi); q[delta]=c
            for j,bj in enumerate(b):
                r[delta+j]=(r[delta+j]-self.mult(c,bj)) % self.modulus
            self.trim(r)
        return self.trim(q),r
    def div(self,a,b):
        q,r=self.divmod(a,b)
        require('nonexact_polynomial_division', not r)
        return q
    def gcd(self,a,b):
        a=self.monic(a); b=self.monic(b)
        while b:
            _,r=self.divmod(a,b)
            a,b=b,self.monic(r)
        return a
    def derivative(self,a):
        return self.trim([a[i]*i for i in range(1,len(a))])
    def radical(self,a):
        return self.div(a,self.gcd(a,self.derivative(a))) if a else []
    def bivar(self,terms):
        ay=max(e[0] for e,c in terms); az=max(e[1] for e,c in terms)
        rows=[[0]*(az+1) for _ in range(ay+1)]
        for (i,j),c in terms:
            rows[i][j]=c
        return self.trim([nmod_poly(r,P)%self.modulus for r in rows])
    def evaluate(self,poly,args):
        if poly.is_zero:
            return ZERO
        cache=[]
        for v,d in zip(args,poly.degree_list()):
            a=[ONE]
            for _ in range(d):
                a.append(self.mult(a[-1],v))
            cache.append(a)
        out=ZERO
        for ex,c in poly.terms():
            a=nmod_poly([int(c)%P],P)
            for arr,n in zip(cache,ex):
                a=self.mult(a,arr[n])
            out=(out+a)%self.modulus
        return out
    def u1poly(self,poly,u2,u3):
        if poly.is_zero:
            return []
        rows=[]
        for j in range(poly.degree(X)+1):
            ps=sp.Poly.from_dict({(e[1],e[2]):int(c)%P for e,c in poly.terms() if e[0]==j},(Y,Z),modulus=P)
            rows.append(self.evaluate(ps,[u2,u3]))
        return self.trim(rows)

class Inputs:
    def __init__(self, compact, four):
        self.compact=compact; self.four=four
        self.polys={n:sp.Poly(sp.sympify((compact/(n+'.txt')).read_text()),X,Y,Z,modulus=P) for n in ['PH','P0','PT']}
        self.factors={p.stem[7:]:sp.Poly(sp.sympify(p.read_text()),X,Y,Z,modulus=P) for p in sorted(compact.glob('factor_*.txt'))}
        require('factor_name_inventory', set(self.factors)=={'u1','u2','u3','alpha1','alpha2','alpha3','beta1','beta2','beta3','Abar','Bbar','Sbar','Etri','path_p','path_2mp','path_s','path_2ms','tri_p','tri_2mp','tri_r','tri_2mr','tri_s','tri_2ms'})
        self.terms={}
        for n in ['F','C','l1']:
            data=json.loads((compact/(n+'_u2u3.json')).read_text())
            require('bivariate_schema_'+n,data['prime']==P and data['variables']==['u2','u3'])
            require('duplicate_bivariate_terms_'+n,len(data['terms'])==len({tuple(e) for e,c in data['terms']}))
            self.terms[n]=[(tuple(e),int(c)%P) for e,c in data['terms']]
        self.E=self.read_univariate('E512_mod65537.txt')
        self.H=self.read_univariate('excluded_projection_H130.txt')
        self.four_polys={n:sp.Poly(sp.sympify((four/(n+'.txt')).read_text()),X,Y,Z,M,modulus=P) for n in ['PH4','PL4','FT4','PTH4']}
    def read_univariate(self,name):
        p=sp.Poly(sp.sympify((self.compact/name).read_text()),T,modulus=P)
        return nmod_poly([int(p.nth(i))%P for i in range(p.degree()+1)],P)
    def source_hashes(self):
        names=['PH.txt','P0.txt','PT.txt','F_u2u3.json','C_u2u3.json','l1_u2u3.json','E512_mod65537.txt','excluded_projection_H130.txt']+[f'factor_{n}.txt' for n in sorted(self.factors)]
        out={'compact/'+n:hashlib.sha256((self.compact/n).read_bytes()).hexdigest() for n in names}
        out.update({'four/'+n+'.txt':hashlib.sha256((self.four/(n+'.txt')).read_bytes()).hexdigest() for n in self.four_polys})
        return out

def projection_identities(data):
    ctx=nmod_mpoly_ctx.get(('y','z'),P,'lex')
    def c2(p):
        return ctx.from_dict({e:int(c)%P for e,c in p.terms()})
    domain=sp.GF(P).poly_ring(Y,Z)
    ph=sp.Poly(data.polys['PH'].as_expr(),X,domain=domain)
    p0=sp.Poly(data.polys['P0'].as_expr(),X,domain=domain)
    subs=sp.subresultants(ph,p0)
    require('subresultant_degree_sequence',[int(q.degree()) for q in subs]==[6,2,1,0])
    linear=subs[-2]
    l0=sp.Poly(linear.nth(0),Y,Z,modulus=P)
    l1=sp.Poly(linear.nth(1),Y,Z,modulus=P)
    stored_l1=sp.Poly.from_dict(dict(data.terms['l1']),(Y,Z),modulus=P)
    require('stored_l1_exact',l1==stored_l1)
    # Universal pseudo-division identity certifies L belongs to (PH,P0),
    # including when leading coefficients vanish after specialization.
    prem=sp.prem(p0,ph)
    require('linear_subresultant_prem_identity',prem==-linear)
    resultant=sp.Poly(subs[-1].as_expr(),Y,Z,modulus=P)
    alpha=sp.Poly(9-(Y-1)**2,Y,Z,modulus=P)
    B=sp.Poly(data.factors['Bbar'].as_expr(),Y,Z,modulus=P)
    F=sp.Poly.from_dict(dict(data.terms['F']),(Y,Z),modulus=P)
    expected=sp.Poly(Y**8,Y,Z,modulus=P)*alpha**4*B**2*F
    require('path_resultant_factor_identity',resultant==expected.mul_ground(13108))
    a,b=c2(l0),c2(l1); triangle=data.polys['PT']; composed=ctx.constant(0)
    for i in range(11):
        coefficient=ctx.from_dict({(e[1],e[2]):int(c)%P for e,c in triangle.terms() if e[0]==i})
        composed+=coefficient*(-a)**i*b**(10-i)
    stored=ctx.from_dict(dict(data.terms['C']))
    require('triangle_projection_division_free_identity',composed==stored)
    f=ctx.from_dict(dict(data.terms['F']))
    projection=f.resultant(stored,0)
    require('projection_is_univariate',projection.degrees()[0]==0)
    pd=projection.to_dict(); degree=int(projection.degrees()[1])
    univ=nmod_poly([pd.get((0,i),0) for i in range(degree+1)],P)
    require('projection_resultant_degree',univ.degree()==8568)
    scalar,factors=univ.factor_squarefree(); squarefree=ONE
    for f,e in factors:
        squarefree*=f
    squarefree*=pow(int(squarefree.leading_coefficient()),-1,P)
    require('squarefree_projection_EH_identity',squarefree==data.E*data.H)
    require('squarefree_projection_degree',squarefree.degree()==642)
    require('E_H_coprime',data.E.gcd(data.H).degree()==0)
    # Explicit counterexample to the old global compact-support statement:
    # all three compact polynomials vanish on alpha1=alpha2=0 lines.
    excluded=[]
    for u1,u2 in itertools.product([-1,3],[-2,4]):
        vanishes=all(sp.Poly(q.as_expr().subs({X:u1,Y:u2}),Z,modulus=P).is_zero for q in data.polys.values())
        require('omitted_line_regression',vanishes)
        excluded.append({'u1':u1,'u2':u2,'all_compact_polynomials_identically_zero':True})
    return {'status':'PASS','path_resultant_scalar':13108,'path_resultant_removed_factors':{'u2':8,'alpha2':4,'Bbar':2},'linear_subresultant_is_negative_pseudoremainder':True,'projection_formula':'Cproj=l1^10 PT(-l0/l1,u2,u3)','projection_resultant_degree':degree,'squarefree_projection_degree':642,'squarefree_projection_equals_E512_times_H130':True,'domain':'D(u2*alpha2*Bbar), together with compact equations','global_compact_support_exhaustive':False,'omitted_lines_regression':excluded,'projection_resultant_coefficients':coefficients(univ),'squarefree_multiplicity_profile':sorted([{'degree':f.degree(),'multiplicity':e} for f,e in factors],key=lambda r:(r['degree'],r['multiplicity']))}

def branch_reconstruction(data):
    hf=sorted(data.H.factor()[1],key=lambda row:(row[0].degree(),coefficients(row[0])))
    reports=[];inventory=[]
    for fi,(f,exponent) in enumerate(hf):
        require('H_irreducible_multiplicity',exponent==1)
        q=Quotient(f)
        F,C,L1=[q.bivar(data.terms[n]) for n in ['F','C','l1']]
        G=q.radical(q.gcd(F,C)); D=q.gcd(G,L1); L=q.div(G,D)
        inventory.append({'h_degree':f.degree(),'h_coefficients':coefficients(f),'G_degree':len(G)-1,'D_degree':len(D)-1,'L_degree':len(L)-1})
        for chart,g in [('degenerate',D),('linear',L)]:
            if len(g)<=1:
                continue
            branches=[]
            if f.degree()==1:
                gfp=nmod_poly([int(a[0]) for a in g],P)
                u3=nmod_poly([-int(f[0])*pow(int(f[1]),-1,P)%P],P)
                for gf,ge in sorted(gfp.factor()[1], key=lambda row:(row[0].degree(),coefficients(row[0]))):
                    require('projected_branch_squarefree',ge==1)
                    branches.append((gf,PARAM%gf,u3))
            else:
                require('extension_projection_linear',len(g)==2)
                branches.append((f,q.mult(-g[0],q.inv(g[1])),PARAM%f))
            for modulus,u2,u3 in branches:
                r=Quotient(modulus)
                pv={n:r.u1poly(po,u2,u3) for n,po in data.polys.items()}
                root=r.radical(r.gcd(r.gcd(pv['PH'],pv['P0']),pv['PT']))
                factor_values={n:r.u1poly(po,u2,u3) for n,po in data.factors.items()}
                zero_factors=[n for n,po in factor_values.items() if not po]
                row={'h_index':fi,'chart':chart,'field_degree':modulus.degree(),'modulus':coefficients(modulus),'u2':coefficients(u2),'u3':coefficients(u3),'common_u1_degree':len(root)-1,'projected_zero_factors':zero_factors,'excluded_by':[]}
                # For the repaired complement it is enough that alpha2!=0
                # and h!=0; record a direct check independently of saturation
                # by the other 17 factors.
                if not root:
                    require('positive_dimensional_branch_outside_complement',any(n in zero_factors for n in ['u2','u3','alpha2','beta2','beta3']))
                    row['complement_survivors']=0
                else:
                    remaining=root.copy()
                    for n in ['u1','u2','u3','alpha2','beta1','beta2','beta3']:
                        cut=r.gcd(remaining,factor_values[n])
                        if len(cut)>1:
                            remaining=r.div(remaining,cut)
                    require('discarded_projection_empty_on_complement',len(remaining)==1)
                    row['complement_survivors']=0
                    for n,po in factor_values.items():
                        cut=r.gcd(root,po)
                        if len(cut)>1:
                            row['excluded_by'].append({'factor':n,'degree':len(cut)-1})
                            root=r.div(root,cut)
                    require('discarded_regular_survivor',len(root)==1)
                reports.append(row)
    pd=sum(r['h_degree']*r['D_degree'] for r in inventory)
    pl=sum(r['h_degree']*r['L_degree'] for r in inventory)
    require('H_factor_count',len(hf)==37)
    require('H_degree',sum(f.degree() for f,e in hf)==130)
    require('degenerate_projection_degree',pd==129)
    require('linear_projection_degree',pl==4)
    require('degenerate_residue_branch_count',sum(r['chart']=='degenerate' for r in reports)==37)
    return {'status':'PASS','factor_count':len(hf),'support_degree':130,'projection_degree_degenerate':pd,'projection_degree_linear':pl,'complement':'D(h*alpha2)','complement_survivors':0,'regular_survivors':0,'inventory':inventory,'reports':reports}

def determinant(q,matrix):
    out=ZERO
    for perm in itertools.permutations(range(len(matrix))):
        v=ONE
        for i,j in enumerate(perm):
            v=q.mult(v,matrix[i][j])
        sign=(-1)**sum(perm[i]>perm[j] for i in range(len(perm)) for j in range(i+1,len(perm)))
        out=(out+v*sign)%q.modulus
    return out

def rur_reconstruction(data):
    q=Quotient(data.E); checks=[]
    def check(name,cond,**details):
        require(name,cond); checks.append({'name':name,'passed':True,**details})
    check('E_degree',data.E.degree()==512)
    check('E_squarefree',data.E.gcd(data.E.derivative()).degree()==0)
    g=q.gcd(q.bivar(data.terms['F']),q.bivar(data.terms['C']))
    check('RUR_u2_gcd_linear',len(g)==2)
    u2=(-g[0])%data.E
    g1=q.gcd(q.u1poly(data.polys['PH'],u2,PARAM),q.u1poly(data.polys['P0'],u2,PARAM))
    check('RUR_u1_gcd_linear',len(g1)==2)
    u1=(-g1[0])%data.E
    args=[u1,u2,PARAM]
    for n,po in data.polys.items():
        check(n+'_zero',not q.evaluate(po,args))
    for n,po in data.factors.items():
        d=q.evaluate(po,args).gcd(data.E).degree()
        check(n+'_unit',d==0,gcd_degree=d)
    jac=[[q.evaluate(po.diff(v),args) for v in [X,Y,Z]] for po in data.polys.values()]
    check('compact_jacobian_unit',determinant(q,jac).gcd(data.E).degree()==0)
    pl=data.four_polys['PL4']
    am=sp.Poly.from_dict({e[:3]:int(c)%P for e,c in pl.terms() if e[3]==1},(X,Y,Z),modulus=P)
    bm=sp.Poly.from_dict({e[:3]:int(c)%P for e,c in pl.terms() if e[3]==0},(X,Y,Z),modulus=P)
    a=q.evaluate(am,args); b=q.evaluate(bm,args)
    check('PL_m_coefficient_unit',a.gcd(data.E).degree()==0)
    m=q.mult(-b,q.inv(a)); args4=args+[m]
    for n,po in data.four_polys.items():
        check(n+'_zero',not q.evaluate(po,args4))
    jac4=[[q.evaluate(po.diff(v),args4) for v in [X,Y,Z,M]] for po in data.four_polys.values()]
    check('four_equation_jacobian_unit',determinant(q,jac4).gcd(data.E).degree()==0)
    return {'status':'PASS','degree':512,'checks':checks,'method':'Unit-pivot Euclidean gcd in Fp[t]/E512 reconstructs u2 from F/C then u1 from PH/P0. Original four-equation residues and Jacobian are freshly evaluated.','RUR':{'u1':coefficients(u1),'u2':coefficients(u2),'u3':[0,1],'m':coefficients(m)}}

def run(compact,four,out):
    out.mkdir(parents=True,exist_ok=True)
    data=Inputs(compact,four)
    result={'schema':'generic-finite-projection-reconstruction-v1','prime':P,'status':'PASS','source_engine':'SymPy1.14.0 + python-flint0.9.0; direct FLINT exact arithmetic','legacy_code_imported':False,'certificate_booleans_used':False,'source_hashes':data.source_hashes()}
    for name,fn in [('finite_projection',projection_identities),('projection_exclusion',branch_reconstruction),('finite_rur',rur_reconstruction)]:
        print('Reconstructing '+name,flush=True)
        value=fn(data); dump(out/(name+'.json'),value)
        result[name+'_status']=value['status']
    result['scope']='Complement D(h*alpha2) complete; eight exceptional double-alpha lines require separate global-core screening.'
    dump(out/'support_reconstruction.json',result)
    print(json.dumps({'status':'PASS','projection_support_degree':642,'regular_geometric_degree':512,'global_compact_support_exhaustive':False}),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--compact',type=Path,required=True)
    parser.add_argument('--four',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    run(args.compact,args.four,args.output)
