"""Local exact arithmetic checkers for the QLC supplement."""
