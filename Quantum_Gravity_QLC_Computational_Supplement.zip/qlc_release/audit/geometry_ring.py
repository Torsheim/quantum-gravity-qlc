#!/usr/bin/env python3
"""Fresh exact certificates for the localized real-coordinate bridge.

No upstream audit is imported. These checks support, but do not replace,
the universal-ring proof in the accompanying manuscript.
"""
import argparse
import hashlib
import json
from pathlib import Path
import sympy as s

def require(ok, message):
    if not ok:
        raise RuntimeError(message)

def main(source, output):
    records = []
    def check(name, expression):
        require(s.cancel(expression) == 0, name)
        records.append(name)
    def matrix(name, expression):
        for i in range(expression.rows):
            for j in range(expression.cols):
                check(f'{name}[{i},{j}]', expression[i,j])

    x,y,tx,ty,q = s.symbols('x y tx ty q')
    d=x+y-1; dt=tx+ty-1
    F=d*tx-x; Ft=dt*x-tx; H=d*d-d*x+q*(x-1); K=d*dt-1
    check('conic_solves_x', (q-d)*x-(q-d*d)-H)
    check('q_minus_d_redundant_unit', (q-d)*(x-q-d)+q*(q-1)-H)
    check('metric_reciprocal_certificate', d*Ft+F-x*K)
    z=1+q*(ty-1)
    check('correct_z_y_certificate', d*(z-y)+H-q*(K-F))
    bx,btx,bd=s.symbols('bar_x bar_tx bar_d')
    G=x-d*btx; Gt=tx-dt*bx
    check('star_forces_tx_real', G+F-d*(tx-btx))
    check('star_forces_x_real', Gt+Ft-dt*(x-bx))
    Fb=bd*btx-bx
    check('d_reality_ideal_certificate', (d-bd)*btx-((x-bx)-d*(tx-btx)+F-Fb))
    dd=s.Symbol('d')
    xx=(q-dd**2)/(q-dd); yy=dd*(q-1)/(q-dd)
    txx=xx/dd; tyy=yy/dd
    check('inverse_d_definition', xx+yy-1-dd)
    check('inverse_dt_definition', txx+tyy-1-1/dd)
    check('inverse_metric_F0', dd*txx-xx)
    check('inverse_metric_F1', txx-xx/dd)
    check('inverse_conic0', dd**2-dd*xx+q*(xx-1))
    check('inverse_conic1', dd**-2-txx/dd+(txx-1)/q)
    check('inverse_star_x0', xx-dd*txx)
    check('inverse_star_y0', yy-dd*tyy)
    check('inverse_star_x1', txx-xx/dd)
    check('inverse_star_y1', tyy-yy/dd)
    check('inverse_z0', 1+q*(tyy-1)-yy)
    check('inverse_z1', 1+(yy-1)/q-tyy)
    check('inverse_S_equal_each_entry', txx*yy-xx*tyy)
    # Unit products express all four local coefficients on the declared open.
    check('x_unit_formula', xx*(q-dd)-(q-dd**2))
    check('y_unit_formula', yy*(q-dd)-dd*(q-1))
    check('tx_unit_formula', txx*dd-xx)
    check('ty_unit_formula', tyy*dd-yy)

    a,b,c,e=s.symbols('a b c e', real=True)
    I=s.I
    norm=lambda w:s.expand(w*s.conjugate(w))
    check('norm_polynomial', norm(a+I*b)-(a*a+b*b))
    check('norm_multiplicative', norm((a+I*b)*(c+I*e))-norm(a+I*b)*norm(c+I*e))
    check('norm_inverse', (a+I*b)*(a-I*b)-(a*a+b*b))
    check('real_norm_is_square', norm(a)-a*a)
    # The real and imaginary coordinates of a star difference have no
    # residual imaginary nilpotents: 2 is a unit in the real base.
    check('imaginary_coefficient', ((a+I*b)-(a-I*b))/(2*I)-b)

    m,mt=s.symbols('m mt')
    X=s.Matrix(s.symbols('X1:4')); Y=s.Matrix(s.symbols('Y1:4'))
    M=s.Matrix(3,3,lambda i,j:s.Symbol(f'M{i}{j}'))
    L=s.Matrix.vstack(s.Matrix([[m,*X]]),s.Matrix.hstack(Y,M))
    Ls=L.copy(); Ls[0,0]=mt
    comm=L*Ls-Ls*L
    matrix('commutator_top_right', comm[:1,1:]-(m-mt)*X.T)
    matrix('commutator_lower_left', comm[1:,:1]+(m-mt)*Y)
    P=s.Matrix(4,4,lambda i,j:s.Symbol(f'P{i}{j}'))
    Pb=s.Matrix(4,4,lambda i,j:s.Symbol(f'Pb{i}{j}'))
    matrix('matrix_reality', Pb-P-(P*(P*Pb-s.eye(4))-(P*P-s.eye(4))*Pb))
    h=s.symbols('h0:4'); D=s.diag(*h)
    Q=-D.inv()*P.T*D; Qb=-D.inv()*Pb.T*D
    matrix('zero_grade_star_to_P', Qb*Q-D.inv()*(P*Pb).T*D)
    # Active spatial equations: a unit first orientation forces sum=2.
    v,w=s.symbols('v w'); edge=v+w-2
    check('active_pair_pivot', v*edge/v-edge)
    check('active_star_reduction', v-(v+w-1)*s.Symbol('bar_v')-(v-s.Symbol('bar_v'))+edge*s.Symbol('bar_v'))
    # Negative control: the historical metric-only counterexample has z!=y.
    bad={x:0,y:3,tx:0,ty:s.Rational(1,2),q:4}
    require(F.subs(bad)==H.subs(bad)==Ft.subs(bad)==0, 'counterexample local metric')
    require(K.subs(bad)!=0 and (z-y).subs(bad)==-4, 'counterexample must reject premature z=y')
    data={'schema':'complete-qlc-geometry-ring-identities-v1','status':'PASS','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'exact_scalar_checks':len(records),'checks':records,
          'negative_controls':['metric-only x=0 example violates reciprocal and z=y'],
          'historical_programs_imported':False,'uses_assert':False,
          'scope':'Universal algebra certificates; exhaustive geometric components are checked separately.'}
    output.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':'PASS','exact_scalar_checks':len(records)}))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('source',type=Path);p.add_argument('output',type=Path)
    a=p.parse_args();main(a.source,a.output)
