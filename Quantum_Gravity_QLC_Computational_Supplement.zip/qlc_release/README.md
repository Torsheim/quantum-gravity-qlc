# QLC article and exact computational supplement

30 October 2026. Article revision 0.13; supplement 2.3; literature comparison 1.2.

Read manuscript.pdf for the article and supplement.pdf for the complete
standalone counting proof. All editable sources are included. The full
counting exposition, geometric consequences and the new Aschieri-Weber
comparison appendix are byte-identical between the two documents, including
intervening prose. The mathematical sector and 512/204 theorem are unchanged.

## Complete reproduction

Use a Python 3.10+ virtual environment and install requirements.txt:

```sh
python -m pip install -r requirements.txt
python -B reproduce.py --output ../qlc-results
```

The output directory must be new and outside this package. --workers 4
allows four independent generic jobs; the default is one worker. The
complete command checks current source consistency, runs all 20 counting
jobs in normal and optimized Python modes, compares all 28 mathematical
result pairs byte for byte, and freshly replays the worked connection.
No network is needed after installing the pinned dependencies. Prior
receipts and historical review reports are never arithmetic inputs.

The current-release execution is documented in REPRODUCTION_RESULTS.md
and evidence/replay/RESULT.json. counting/RESULT.json inside that replay
records all counting inputs, jobs and comparisons; worked_example/ records
the fresh interval example. evidence/release_source_check.json records
the current source check and exact change scope. The old release's receipts
are history in the full author archive and are not presented as this run.

## Proof and data map

| Calculation | Exact coverage |
| --- | --- |
| Generic degree 512 | 26 boundary supports, eight exceptional lines, all 37 excluded projection factors, moving-base poles and original Jacobians |
| Finite-fibre cap | Written square-family argument, applied after separate finiteness |
| Exact source and rational fibre | Full source binding, pseudo-division, all minors, coprimality and 512 smooth lifts |
| Coordinate algebra | 1193 exact resultant tests under degree bound 1192; degree-512 factor and full degree-680 complement |
| Reconstruction | Both full determinants at 1152 arguments each; all 23 original units and all 30 circuit divisions |
| Real-root count | 46 negative + 158 positive = 204; 318 leaves, 634 nodes and 319 nonroot endpoints |

The generic control is p=65537, q=(4,9,49). The separate lifting witness
at q=(4/3,12/11,3/4), with all scales one, uses p=101. P_top denotes the
generic top polynomial; P_T is the centre triangle numerator. The compact
scalar is -4 for T0=-P_top and +4 for the raw top polynomial.

inputs.json binds 175 counting inputs: 142 coefficient files, 28 arithmetic
implementation files, two retained source-binding sections, the runner,
requirements and complete supplement source. sections/ is retained literal
source-binding input, not a set of verbatim extracts of the current printed
sections. manuscript.tex and supplement.tex are the canonical exposition.
synchronization.json additionally binds the complete shared text, article,
wrapper, comparison sources and portable example. SHA256SUMS.txt identifies
the exported bytes; hashes do not replace mathematical arguments.

## Worked connection

The root is in (-400542/1000000,-400541/1000000). Its 53-node circuit,
all displayed rounding, every division and the original-unit bound >0.1036
are checked by outward interval enclosures. A separate replay is available:

```sh
QLC_WORKED_OUTPUT_DIR=../qlc-example-results python -B examples/worked_connection/replay_worked_example.py
```

The output directory must again be new and outside the package.

## Literature and the delivered AW comparison

Appendix A of both complete documents now supplies the Aschieri-Weber
rational tensor/Hopf shift cancellation, actual Phi map, inverse and
same-metric compatibility residual. Its bounded standard-library check is
delivered at literature/comparison_checks/aw_comparison_check.py:

```sh
python -B literature/comparison_checks/aw_comparison_check.py
```

Its optional --source-pdf argument identifies the inspected arXiv v2 bytes;
no external PDF is needed for its arithmetic. The written derivation
justifies the general comparison; this separate check does not replace the
complete counting replay. The current fresh AW output is
evidence/aw_comparison.json. literature/literature_comparison.pdf/.tex
report 1.2 identifies article 0.13 and supplement 2.3 and preserves the
source-version limits. Earlier source-target hashes remain historical.

The earlier documented book Example 8.20/dependency reading, square arXiv
v1 comparison and accepted-manuscript text-extraction comparison are
distinguished in that report. The final 23-page square Version of Record
remains uninspected. No universal-priority or full version-equivalence
claim is made. Retrieval remains paused; no copyrighted source book or
primary paper PDF is redistributed here.

## Scope and exports

The result concerns the declared marked, spatially homogeneous, trace-zero
localized path-triangle sector on the coordinate-flip Grassmann calculus
of (Z/2)^4: 512 reduced complexified points and 204 actual real
star-preserving connections at the stated metric. No symmetry quotient,
full moduli classification, curvature calculation or cosmological claim
is inferred. The explanatory changes in this release are listed in
RELEASE_CHANGES.md.

The scientific computational supplement contains the complete current
sources, coefficients, checks, literature comparison, AW checker and
current execution evidence. The full author archive additionally keeps
submission preparation and historical records under history/ and other
clearly identified internal dossiers. These records are not mathematical
proof inputs or scientific supplementary data.

Author details and declarations are those previously confirmed. The
author authorized the present documentation revisions; no new personal
reading of the revised wording is asserted. AI assistance and the actual
scope of author oversight remain explicit. Internal AI review and exact
replay are not external human journal review or proof-assistant formalization.
