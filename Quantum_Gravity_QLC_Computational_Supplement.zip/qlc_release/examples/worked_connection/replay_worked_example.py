"""Exact one-root definition and outward-rounded circuit illustration.

Reads the published coefficient inputs and validates source_binding.json.
QLC_WORKED_OUTPUT_DIR must select a new directory outside this package.
Run with the stated dependencies and Python -B.
"""
from pathlib import Path
from fractions import Fraction
import hashlib
import json
import math
import os
import sys
import mpmath as mp
from flint import arb, ctx, fmpq, fmpz_poly
from pilot import DATA, H, C, PART, circuit, blocks, horner

if hasattr(sys, 'set_int_max_str_digits'):
    sys.set_int_max_str_digits(0)
PACKAGE = Path(__file__).resolve().parents[2]
EXAMPLE = Path(__file__).resolve().parent
OUT = None
BINDING_SCHEMA = 'qlc-worked-example-source-binding-1'
REQUIRED_BINDING_FILES = (
    'supplement.tex',
    'certificates/centre/minimal_polynomial.json',
    'certificates/centre/descartes_partition.json',
    'certificates/centre/rational_circuit.json',
    'certificates/centre/u2_reconstruction.json',
    'certificates/centre/source_equations.json',
    'examples/worked_connection/pilot.py',
    'examples/worked_connection/replay_worked_example.py',
)
HP = fmpz_poly(H)
SOURCE = json.loads((DATA/'source_equations.json').read_text())
SELECTED_PATH = '000000000000000000001'

def require(test, message):
    if not test:
        raise ValueError(message)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def validate_source_binding():
    manifest = EXAMPLE/'source_binding.json'
    require(manifest.is_file() and not manifest.is_symlink(),
            'source_binding.json must be a regular file')
    binding = json.loads(manifest.read_text())
    require(isinstance(binding, dict) and set(binding) == {'schema', 'files'},
            'source binding must contain exactly schema and files')
    require(binding['schema'] == BINDING_SCHEMA, 'unsupported source-binding schema')
    files = binding['files']
    require(isinstance(files, dict) and set(files) == set(REQUIRED_BINDING_FILES),
            'source-binding file inventory differs from the eight required inputs')
    require(DATA.resolve() == (PACKAGE/'certificates/centre').resolve(),
            'coefficient inputs must belong to this source package')
    for relative in REQUIRED_BINDING_FILES:
        expected = files[relative]
        require(isinstance(expected, str) and len(expected) == 64 and
                all(c in '0123456789abcdef' for c in expected),
                'invalid SHA256 value for '+relative)
        path = PACKAGE/relative
        require(path.is_file() and not path.is_symlink() and
                path.resolve().is_relative_to(PACKAGE),
                'source binding requires a regular internal file: '+relative)
        require(sha(path) == expected, 'source-binding SHA256 mismatch: '+relative)
    return {'manifest': 'examples/worked_connection/source_binding.json',
            'manifest_sha256': sha(manifest), **binding}

def prepare_output():
    raw = os.environ.get('QLC_WORKED_OUTPUT_DIR')
    require(isinstance(raw, str) and bool(raw.strip()),
            'QLC_WORKED_OUTPUT_DIR must explicitly select a new external directory')
    output = Path(raw).resolve()
    require(not output.is_relative_to(PACKAGE),
            'worked-example output must be outside the source package')
    require(not output.exists() and not output.is_symlink(),
            'worked-example output directory must be new; existing output is forbidden')
    output.mkdir(parents=True, exist_ok=False)
    return output

def sgn(value):
    return int(value > 0)-int(value < 0)

def exact_sign(x):
    value = HP(fmpq(x.numerator, x.denominator))
    return sgn(value)

def frac_record(x):
    return {'numerator':str(x.numerator), 'denominator':str(x.denominator)}

def rational_interval(left, right):
    return {'lower':frac_record(left),'upper':frac_record(right),
            'H_signs':[exact_sign(left),exact_sign(right)]}

def variation(cs):
    signs=[sgn(x) for x in cs if x]
    return sum(x!=y for x,y in zip(signs,signs[1:]))

def taylor_one(cs):
    cs = list(cs)
    n = len(cs)-1
    for start in range(n-1,-1,-1):
        for j in range(start,n):
            cs[j] += cs[j+1]
    return cs

def selected_descartes_check():
    entry = next(x for x in PART['negative']['leaves'] if x['path']==SELECTED_PATH)
    require(entry['variation']==1, 'selected leaf must be a one-root leaf')
    require(len(H)==513, 'full degree-512 polynomial required')
    require(PART['polynomial_sha256']==sha(DATA/'minimal_polynomial.json'),
            'partition is bound to a different polynomial')
    k,n=int(SELECTED_PATH,2),len(SELECTED_PATH)
    root_bound=1<<PART['root_bound_power_of_two']
    require((-Fraction((k+1)*root_bound,1<<n),-Fraction(k*root_bound,1<<n))
            ==(Fraction(-1,2),Fraction(-1,4)), 'selected path interval differs from stated interval')
    # x=(-2+t)/4 maps 0<t<1 to (-1/2,-1/4).
    # Q=4^512 H((-2+t)/4), formed coefficientwise over Z.
    affine=fmpz_poly([-2,1])
    q=fmpz_poly([H[-1]])
    for i in range(len(H)-2,-1,-1):
        q=q*affine+H[i]*4**(512-i)
    transformed=taylor_one(list(q)[::-1])
    count=variation(transformed)
    require(count==1, 'independent selected-leaf Descartes variation')
    require(exact_sign(Fraction(-1,2))*exact_sign(Fraction(-1,4))==-1,
            'selected endpoints must have opposite nonzero signs')
    return {'negative_leaf_path':SELECTED_PATH,
            'leaf_interval':rational_interval(Fraction(-1,2),Fraction(-1,4)),
            'independently_recomputed_descartes_variation':count,
            'transform':'Q(t)=4^512 H((-2+t)/4); apply (1+s)^512 Q(1/(1+s))',
            'argument':'Descartes variation 1 and nonzero opposite endpoint signs prove exactly one real root in this open leaf.'}

def numerical_root(dps):
    with mp.workdps(dps):
        f=lambda x:horner(H,x,mp.mpf(0))
        root=mp.findroot(f,(mp.mpf('-0.400541680485523632'),mp.mpf('-0.400541680485523631')),
                         tol=mp.mpf(10)**(-dps+60),maxsteps=80,verify=False)
        require(-mp.mpf('0.5')<root<-mp.mpf('0.25'),'numerical root left selected leaf')
        return +root

def source_residuals(e, scalar):
    require(SOURCE['variable_order']==['u1','u2','u3','m','a','b','c','p','r','t','q1','q2','q3'],
            'literal source order changed')
    vals=[e[n] for n in ['u1','u2','u3','m','a','b','c','p','r1','t1','q1','q2','q3']]
    ans=[]
    for row in SOURCE['equations']:
        total=scalar(0)
        for term in row['terms']:
            value=scalar(int(term['coefficient']))
            for x,n in zip(vals,term['exponents']):
                if n:value *= x**n
            total += value
        ans.append(total)
    return ans

def residuals(e, scalar):
    M0,M1,Ps=blocks(e,scalar)
    involutions=[]
    traces=[]
    for P in Ps:
        involutions += [sum((P[i][k]*P[k][j] for k in range(4)),scalar(0))-int(i==j)
                        for i in range(4) for j in range(4)]
        traces.append(sum((P[i][i] for i in range(4)),scalar(0)))
    return {'source_10':source_residuals(e,scalar),'block_involution_32':involutions,
            'block_trace_2':traces,
            'triangle_determinant_identity':[e['triangle_determinant']-e['Y3']*e['E1']]}

def exact_binary(x):
    man,exp=x.man_exp()
    man,exp=int(man),int(exp)
    return Fraction(man*(1<<exp),1) if exp>=0 else Fraction(man,1<<(-exp))

def fixed_integer(n, digits):
    sign='-' if n<0 else ''
    n=abs(n)
    return sign+str(n//10**digits)+'.'+str(n%10**digits).rjust(digits,'0')

def rounded_integer(x, digits):
    y=x*10**digits+Fraction(1,2)
    return y.numerator//y.denominator

def arb_record(x, require_rounding=True):
    require(x.is_finite(),'nonfinite interval evaluation')
    lo,hi=exact_binary(x.lower()),exact_binary(x.upper())
    D=10**80
    lower=(lo.numerator*D)//lo.denominator
    upper=-((-hi.numerator*D)//hi.denominator)
    rounded={}
    for d in [6,10]:
        r0,r1=rounded_integer(lo,d),rounded_integer(hi,d)
        if require_rounding:
            require(r0==r1,'interval does not certify requested decimal rounding')
        if r0==r1:
            rounded[str(d)]=fixed_integer(r0,d)
    return {'outward_decimal_enclosure':{'lower':fixed_integer(lower,80),
                                         'upper':fixed_integer(upper,80)},
            'certified_rounded_values':rounded,
            'internal_absolute_radius_upper':x.rad().abs_upper().str(12,more=True),
            'relative_accuracy_bits':x.rel_accuracy_bits()}

def matrix_record(M):
    return [[arb_record(x) for x in row] for row in M]

def main():
    global OUT
    source_binding = validate_source_binding()
    OUT = prepare_output()
    leaf=selected_descartes_check()
    print('Selected one-root leaf verified independently',flush=True)
    simple_left,simple_right=Fraction(-400542,10**6),Fraction(-400541,10**6)
    simple=rational_interval(simple_left,simple_right)
    require(simple['H_signs'][0]*simple['H_signs'][1]==-1,'simple interval does not bracket root')
    require(Fraction(-1,2)<simple_left<simple_right<Fraction(-1,4),'simple interval not inside leaf')
    print('Simple rational interval signs',simple['H_signs'],flush=True)
    roots={}
    numerics={}
    numerical_envs={}
    for dps in [600,900]:
        with mp.workdps(dps):
            root=numerical_root(dps)
            roots[dps]=root
            env=circuit(root,mp.mpf)
            numerical_envs[dps]=env
            rs=residuals(env,mp.mpf)
            numerics[str(dps)]={'root':mp.nstr(root,80),
                'coordinates':{n:mp.nstr(env[n],80) for n in ['u1','u2','u3','m']},
                'max_abs_residuals':{n:mp.nstr(max(abs(x) for x in v),12) for n,v in rs.items()}}
            print('Numerical circuit evaluated at',dps,'digits',numerics[str(dps)]['max_abs_residuals'],flush=True)
    with mp.workdps(930):
        # Approximation proposes a dyadic bracket; exact signs certify it.
        depth=1200
        denominator=1<<depth
        lower=int(mp.floor(roots[900]*denominator))
        a,b=Fraction(lower,denominator),Fraction(lower+1,denominator)
        deep=rational_interval(a,b)
        require(deep['H_signs'][0]*deep['H_signs'][1]==-1,'deep interval failed exact sign test')
        require(simple_left<a<b<simple_right,'deep interval not nested')
        comparison={n:mp.nstr(abs(numerical_envs[600][n]-numerical_envs[900][n]),12)
                    for n in ['u1','u2','u3','m','a','b','c','p','r1','t1','p0','t0']}
    deep['common_dyadic_denominator_power']=depth
    deep['common_dyadic_numerators']=[str(lower),str(lower+1)]
    print('Deep dyadic bracket exact signs',deep['H_signs'],flush=True)
    ctx.prec=4096
    middle=(a+b)/2
    radius=(b-a)/2
    root_ball=arb(fmpq(middle.numerator,middle.denominator),fmpq(radius.numerator,radius.denominator))
    require(root_ball.contains(arb(fmpq(a.numerator,a.denominator))) and
            root_ball.contains(arb(fmpq(b.numerator,b.denominator))), 'input ball does not contain bracket')
    divisions=[]
    env=circuit(root_ball,arb,divisions)
    require(len(divisions)==30,'literal circuit division inventory changed')
    for x in divisions:require(not x.contains(0),'circuit division denominator enclosure contains zero')
    for n in C['original_23_units']:
        require(not env[n].contains(0),'original unit enclosure contains zero: '+n)
        require(env[n].abs_lower()>arb('0.1036'),'simple uniform original-unit bound failed: '+n)
    M0,M1,Ps=blocks(env,arb)
    temporal={'slice_0':[env['X'+str(i)] for i in range(1,4)],
              'slice_1':[env['zeta'+str(i)]/env['u'+str(i)] for i in range(1,4)]}
    rs=residuals(env,arb)
    ball_residuals={}
    for n,vs in rs.items():
        require(all(x.contains(0) for x in vs),'consistency residual interval excludes zero: '+n)
        largest=max(vs,key=lambda x:exact_binary(x.abs_upper()))
        bound=largest.abs_upper()
        require(bound<arb('5e-313'),'residual consistency enclosure too wide: '+n)
        ball_residuals[n]={'all_enclosures_contain_zero':True,
                           'absolute_upper_bound':bound.str(14,more=True)}
    result={
      'purpose':'Auxiliary worked real connection; exact root definition and rigorous circuit enclosures, not a new classification proof',
      'input_sha256':{n:sha(DATA/n) for n in ['minimal_polynomial.json','descartes_partition.json',
                    'rational_circuit.json','u2_reconstruction.json','source_equations.json']},
      'source_binding':source_binding,
      'metric':{'ratios':['4/3','12/11','3/4'],'nu':'1','lambda':['1','1','1']},
      'root_definition':{'polynomial':'The existing primitive degree-512 H in minimal_polynomial.json',
                         'selected_leaf':leaf,'reader_facing_interval':simple,
                         'deep_nested_refinement':deep,
                         'refinement_note':'Numerical secant suggests the dyadic cell; exact rational polynomial signs independently validate both endpoints. Uniqueness follows from the independently checked containing Descartes leaf.'},
      'rigorous_evaluation':{'arithmetic':'python-flint Arb outward-rounded real balls','working_precision_bits':4096,
           'coordinate_enclosures':{n:arb_record(env[n]) for n in ['u1','u2','u3','m']},
           'M0':matrix_record(M0),'M1':matrix_record(M1),
           'temporal_v0a':{n:[arb_record(x) for x in vs] for n,vs in temporal.items()},
           'original_23_units':{n:arb_record(env[n]) for n in C['original_23_units']},
           'all_30_circuit_division_denominators':[
               {'index':i+1,'zero_excluded':True,'enclosure':arb_record(x,False)} for i,x in enumerate(divisions)],
           'all_53_nodes':{n:arb_record(x,False) for n,x in env.items()},
           'residual_consistency_checks':ball_residuals,
           'minimum_original_unit_absolute_lower_bound':min((x.abs_lower() for x in [env[n] for n in C['original_23_units']]),
                 key=exact_binary).str(14,more=True),
           'simple_uniform_original_unit_bound':'Every original intrinsic unit has absolute value > 0.1036 throughout the root enclosure.'},
      'numerical_convergence_checks':{'working_decimal_precisions':[600,900],'evaluations':numerics,
                          'absolute_coordinate_differences_600_vs_900':comparison},
      'scope_limits':['The one-root definition and interval arithmetic are exact/enclosing.',
                      'The six- and ten-decimal values are illustrative rounded values, with their rounding certified by enclosures.',
                      'The interpretation as a QLC uses the existing scheme identification and reconstruction theorem.',
                      'Residual intervals containing zero are consistency checks, not a replacement for exact source identities.',
                      'No curvature, dynamics, symmetry quotient or physical selection is calculated.']}
    (OUT/'worked_example_results.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    short={k:result['rigorous_evaluation'][k] for k in ['coordinate_enclosures','M0','M1','temporal_v0a']}
    print(json.dumps({'reader_interval_signs':simple['H_signs'],
          'coordinates':{n:x['certified_rounded_values']['10'] for n,x in short['coordinate_enclosures'].items()},
          'M0_6dp':[[x['certified_rounded_values']['6'] for x in row] for row in short['M0']],
          'M1_6dp':[[x['certified_rounded_values']['6'] for x in row] for row in short['M1']],
          'temporal_6dp':{n:[x['certified_rounded_values']['6'] for x in vs] for n,vs in short['temporal_v0a'].items()},
          'residuals':ball_residuals},indent=2),flush=True)

if __name__=='__main__':
    main()
