# Worked real QLC connection

This auxiliary illustration evaluates the same exact coefficient data used
by the complete counting proof. At q=(4/3,12/11,3/4), with all four metric
scales one, take the unique root of H in
(-400542/1000000,-400541/1000000) and apply the literal 53-node rational
reconstruction circuit.

With the package requirements installed, run from the package root:

```sh
QLC_WORKED_OUTPUT_DIR=../qlc-example-results python -B examples/worked_connection/replay_worked_example.py
```

The output directory must be new and outside the package. It must be
selected explicitly; the program never defaults to writing into the source
tree and rejects an existing output directory. Use `python -B` to avoid
creating bytecode files beside the published source.

`source_binding.json` binds exactly eight inputs by SHA256: the current
complete proof `supplement.tex`, the five centre coefficient files used by
the example, and both example implementation files. The replay validates
the complete inventory, relative filenames, regular internal files and all
hashes before producing output. The generated receipt records this source
binding. No historical manuscript version or earlier execution is required.

The fresh `worked_example_results.json` records the exact endpoint signs,
an independently checked one-root Descartes leaf, a nested dyadic bracket,
complete 4096-bit Arb enclosures and certified decimal rounding. All 30
division denominators exclude zero, and all 23 original units have absolute
value greater than 0.1036 throughout the certified bracket. The accompanying
`replay_stdout.txt` is the actual replay log.

`pilot.py` supplies the literal circuit interpreter and block assembly used
by the replay. Its exploratory standalone entry point is not needed for
reproduction. Numerical convergence cross-checks use mpmath, supplied with
SymPy; certified enclosures use python-flint Arb. No extra dependency beyond
the package requirements is needed.

Residual intervals containing zero are consistency checks. The
interpretation as an original QLC follows from the exact scheme
identification and reconstruction in the proof. This illustration does not
compute curvature, dynamics, a symmetry quotient or a physical selection.
