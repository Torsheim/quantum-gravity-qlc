"""Read-only exploratory selection of one already certified real leaf."""
from pathlib import Path
import json, itertools, sys, os
import mpmath as mp

if hasattr(sys, 'set_int_max_str_digits'):
    sys.set_int_max_str_digits(0)
SUBMISSION = Path(os.environ.get('QLC_SUBMISSION_ROOT',
    str(Path(__file__).resolve().parents[2])))
DATA = SUBMISSION/'certificates/centre'
H = json.loads((DATA/'minimal_polynomial.json').read_text())['coefficients_ascending']
C = json.loads((DATA/'rational_circuit.json').read_text())
U = json.loads((DATA/'u2_reconstruction.json').read_text())
PART = json.loads((DATA/'descartes_partition.json').read_text())

def horner(cs, x, zero):
    ans = zero
    for c in reversed(cs):
        ans = ans*x+c
    return ans

def determinant(matrix, one):
    n = len(matrix)
    states = {0: one}
    for mask in range(1, 1 << n):
        k = mask.bit_count()-1
        value = one*0
        for j in range(n):
            if mask & (1 << j):
                sign = -1 if (mask >> (j+1)).bit_count() % 2 else 1
                value += sign*matrix[k][j]*states[mask ^ (1 << j)]
        states[mask] = value
    return states[(1 << n)-1]

def circuit(parameter, scalar, divisions=None):
    env = {}
    def ev(e):
        if type(e) is int:
            return scalar(e)
        if type(e) is str:
            return env[e]
        op, *args = e
        if op == 'parameter': return parameter
        if op == 'univariate': return horner(U[args[0]], ev(args[1]), scalar(0))
        if op == 'bivariate':
            x, y = ev(args[1]), ev(args[2])
            rows = C[args[0]]
            xp = [scalar(1)]
            yp = [scalar(1)]
            for _ in range(max(t[1] for t in rows)): xp.append(xp[-1]*x)
            for _ in range(max(t[2] for t in rows)): yp.append(yp[-1]*y)
            return sum((c*xp[i]*yp[j] for c,i,j in rows), scalar(0))
        if op == 'det': return determinant([[ev(x) for x in row] for row in args[0]], scalar(1))
        if op == 'pow': return ev(args[0])**args[1]
        vals = [ev(x) for x in args]
        if op == 'add': return sum(vals, scalar(0))
        if op == 'mul':
            ans = scalar(1)
            for value in vals: ans *= value
            return ans
        if op == 'neg': return -vals[0]
        if op == 'div':
            if divisions is not None: divisions.append(vals[1])
            return vals[0]/vals[1]
        raise ValueError(op)
    for name, expression in C['nodes_in_evaluation_order']:
        env[name] = ev(expression)
    return env

def blocks(e, scalar):
    m, A, B = [e[x] for x in ['m','A','B']]
    z1,z2,z3 = [e['zeta'+str(i)] for i in range(1,4)]
    p0,s0 = e['p0'],e['t0']
    M0 = [[-m-2*z2/A, p0, scalar(0)], [2-p0,-m-2*z1/A-2*z3/B,s0], [scalar(0),2-s0,-m-2*z2/B]]
    M1 = [[e['a'],e['p'],e['r1']], [2-e['p'],e['b'],e['t1']], [2-e['r1'],2-e['t1'],e['c']]]
    Ps=[]
    for t,M in enumerate([M0,M1]):
        X = [e['zeta'+str(i)]/e['u'+str(i)] if t==0 else e['X'+str(i)] for i in range(1,4)]
        Y = [e['u'+str(i)] if t==0 else e['Y'+str(i)] for i in range(1,4)]
        P = [[m]+X]+[[Y[i]]+M[i] for i in range(3)]
        Ps.append(P)
    return M0,M1,Ps

if __name__ == '__main__':
    mp.mp.dps = 1100
    candidates=[]
    for half in ['negative','positive']:
        for leaf in PART[half]['leaves']:
            if leaf['variation']!=1: continue
            n=len(leaf['path']); k=int(leaf['path'],2)
            a=mp.mpf(k)*2**(19-n); b=mp.mpf(k+1)*2**(19-n)
            if half=='negative':a,b=-b,-a
            if (half=='negative' and -2 <= a <= -mp.mpf('0.25')) or (half=='positive' and 1<=a<=mp.mpf('1.5')):
                candidates.append((half,leaf['path'],a,b))
    results=[]
    for half,path,a,b in candidates:
        fa=horner(H,a,mp.mpf(0))
        for _ in range(600):
            m=(a+b)/2;fm=horner(H,m,mp.mpf(0))
            if mp.sign(fa)==mp.sign(fm):a,fa=m,fm
            else:b=m
        z=(a+b)/2
        e=circuit(z,mp.mpf)
        M0,M1,Ps=blocks(e,mp.mpf)
        residual=max(abs(sum(P[i][k]*P[k][j] for k in range(4))-(i==j)) for P in Ps for i in range(4) for j in range(4))
        units=[abs(e[n]) for n in C['original_23_units']]
        maxmatrix=max(abs(x) for M in [M0,M1] for row in M for x in row)
        record={'half':half,'path':path,'u':[mp.nstr(e[n],18) for n in ['u1','u2','u3','m']],'min_unit':mp.nstr(min(units),10),'max_M':mp.nstr(maxmatrix,10),'block_residual':mp.nstr(residual,8)}
        print(json.dumps(record),flush=True)
        results.append(record)
    (Path(__file__).parent/'pilot_results.json').write_text(json.dumps(results,indent=2)+'\n')
