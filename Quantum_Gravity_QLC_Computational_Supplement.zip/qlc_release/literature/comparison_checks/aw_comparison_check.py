"""Exact independent check of Aschieri--Weber Phi specialization and QLC mismatch.
From the package root, run:
    python -B literature/comparison_checks/aw_comparison_check.py
Only the Python standard library is needed. The analytic derivation, including
rational-tensor shift cancellation, is Appendix "An explicit comparison with
Aschieri--Weber compatibility" (label aw:appendix) in manuscript.pdf and
supplement.pdf. The optional --source-pdf identifies the inspected arXiv v2
PDF bytes; it is not required for the arithmetic checks.
"""
import argparse
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from hashlib import sha256
import json

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-pdf',type=Path,help='Optionally verify the bytes of the actually inspected arXiv v2 PDF.')
args=parser.parse_args()
expected_pdf_sha256='2c588e9c23b250a0c163b08ec21b5505b91e438a5396109106fd1eda30ee0413'
if args.source_pdf is not None:
    actual_pdf_sha256=sha256(args.source_pdf.read_bytes()).hexdigest()
    if actual_pdf_sha256 != expected_pdf_sha256:
        raise ValueError('The provided PDF does not match the inspected arXiv:2209.05453v2 bytes.')
    pdf_provenance={'primary_pdf_status':'reverified','source_pdf_sha256':actual_pdf_sha256}
else:
    pdf_provenance={'primary_pdf_status':'primarypdf_not_reverified'}

n=4
pairs=[(i,j) for i in range(n) for j in range(i,n)]
unknowns=[(i,a,b) for i in range(n) for a,b in pairs]
outputs=[(i,j,b) for i,j in pairs for b in range(n)]
q=[None,F(4,3),F(12,11),F(3,4)]
h=[[F(1)]+[-q[i]**t for i in range(1,n)] for t in (0,1)]
k=[[1/z for z in row] for row in h]

def rank(m):
    a=[row[:] for row in m];r=0
    for c in range(len(a[0])):
        pivot=next((j for j in range(r,len(a)) if a[j][c]),None)
        if pivot is None: continue
        a[r],a[pivot]=a[pivot],a[r]
        d=a[r][c];a[r]=[z/d for z in a[r]]
        for j in range(len(a)):
            if j!=r and a[j][c]:
                d=a[j][c];a[j]=[x-d*y for x,y in zip(a[j],a[r])]
        r+=1
    return r

def key(i,a,b):return i,min(a,b),max(a,b)
def Phi(A,weights):
    return {(i,j,b):weights[j]*A[key(i,j,b)]+weights[i]*A[key(j,i,b)] for i,j,b in outputs}
def invPhi(M,weights):
    def m(i,j,b):return M[min(i,j),max(i,j),b]
    return {(i,a,b):(weights[b]*m(i,a,b)+weights[a]*m(i,b,a)-weights[i]*m(a,b,i))/(2*weights[a]*weights[b]) for i,a,b in unknowns}

# Every basis column, at both slices: both inverse compositions exactly identity.
checks=[]
for t in (0,1):
    matrix=[[F(0) for _ in unknowns] for _ in outputs]
    for col,idx in enumerate(unknowns):
        A={u:F(int(u==idx)) for u in unknowns};M=Phi(A,k[t])
        if invPhi(M,k[t])!=A:raise ArithmeticError('Phi inverse fails')
        for row,idx2 in enumerate(outputs):matrix[row][col]=M[idx2]
    for idx in outputs:
        M={o:F(int(o==idx)) for o in outputs}
        if Phi(invPhi(M,k[t]),k[t])!=M:raise ArithmeticError('inverse Phi fails')
    checks.append({'slice':t,'Phi_rank':rank(matrix),'Phi_size':len(matrix)})

# Direct finite-Hopf check of the potentially delicate rational tensor shift.
# Delta^2(delta_z) = sum_{a XOR b XOR c=z} delta_a tensor delta_b tensor delta_c.
# AW (2.11), id tensor_sigma(f phi0), on invariant e_i tensor e_j gives
# coefficient sum f1(x) Ri[S(f2) f3](x). Compute this from delta_z, all x,i.
hopf_checks=0
for z,x,i in product(range(16),range(16),range(n)):
    value=0
    for a,b in product(range(16),repeat=2):
        c=z^a^b
        value+=int(a==x)*int(b==(x^(1<<i)))*int(c==(x^(1<<i)))
    if value!=int(z==x):raise ArithmeticError('rational tensor shift cancellation fails')
    hopf_checks+=1

# AW projected LC: M_ijb = delta_ij partial_b(k_i).
K=[]
for t in (0,1):
    M={(i,j,b):(k[1-t][i]-k[t][i] if i==j and b==0 else F(0)) for i,j,b in outputs}
    K.append(invPhi(M,k[t]))

# Natural left/right passage R = D nabla *, so K^i_ab = - R_a R_b conjugate(C^i_ba).
# All data here are real and K is symmetric in a,b.
def C(t,i,a,b):
    tt=t ^ int((a==0) != (b==0))
    return -K[tt][key(i,a,b)]

def shift(t,i):return t^int(i==0)
def sigma(t,i,l,a,b):
    # Translation degrees are represented by four-bit masks; bit flips are distinct.
    same_degree=((1<<i)^(1<<l))==((1<<a)^(1<<b))
    return F(int(a==l and b==i))-int(same_degree)*C(t,i,a,b)
def E(t,p,qq,r):
    out=F(int(qq==r))*(h[shift(t,p)][r]-h[t][r])+h[t][r]*C(t,r,p,qq)
    for i,j in product(range(n),repeat=2):
        out+=h[t][i]*C(shift(t,i),i,j,r)*sigma(t,i,j,p,qq)
    return out

obstruction=[]
for t in (0,1):
    U=[C(t,i,i,i) for i in range(n)]
    if any(U): raise ArithmeticError('AW diagonal U nonzero')
    for i in (1,2,3):
        Q=h[1-t][i]/h[t][i]
        residual=E(t,0,i,i)/h[t][i]
        if residual!=-(Q-1)**2/4 or not residual:raise ArithmeticError('metric residual identity fails')
        obstruction.append({'slice':t,'direction':i,'normalized_original_residual':str(residual)})

# Projection P23: Sym12(V^3)->Sym23(V^3), inverse T_abc=S_abc+S_bac-S_cab.
coords12=[(a,b,c) for a,b in pairs for c in range(n)]
coords23=[(a,b,c) for a in range(n) for b,c in pairs]
def c12(a,b,c):return (min(a,b),max(a,b),c)
def c23(a,b,c):return (a,min(b,c),max(b,c))
for coord in coords23:
    S={u:F(int(u==coord)) for u in coords23}
    def sval(a,b,c):return S[c23(a,b,c)]
    T={(a,b,c):sval(a,b,c)+sval(b,a,c)-sval(c,a,b) for a,b,c in coords12}
    for a,b,c in coords23:
        if (T[c12(a,b,c)]+T[c12(a,c,b)])/2 != S[a,b,c]:raise ArithmeticError('P23 inverse fails')

result={'status':'PASS',**pdf_provenance,
        'Phi':checks,'rational_tensor_delta_basis_checks':hopf_checks,'Phi_inverse_basis_checks':160,'P23_inverse_basis_checks':40,
        'AW_unique_LC_U':[str(C(0,i,i,i)) for i in range(n)],'our_trace_constraint_sumU':4,
        'original_variable_sigma_metric_obstruction':obstruction,
        'sigmaW_centrality_fails':[str(k[1][i]-k[0][i]) for i in (1,2,3)]}
print(json.dumps(result,indent=2))
