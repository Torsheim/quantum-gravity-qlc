#!/usr/bin/env python3
"""Reproduce the complete exact 512/204 certificate chain from this package.

Run: python -B verify.py --output /absolute/fresh/directory
The default checks normal and optimized Python. No previous output is input.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
GENERIC_RESULTS = (
    'finite_chart_boundary.json', 'exceptional_lines.json',
    'exceptional_lines_standardlib.json', 'finite_projection.json',
    'projection_exclusion.json', 'finite_rur.json',
    'support_reconstruction.json', 'proper_boundary.json', 'graph_jacobian.json')
CENTRE_STATUSES = {
    'quadratic': 'PASS', 'coprime': 'PASS', 'sylvester101': 'PASS',
    'modular': 'PASS', 'resultant': 'PASS', 'descartes': 'PASS',
    'factor': 'PASS_EXACT_FACTOR_SELECTION_IDENTITIES',
    'endpoints': 'PASS_EXACT_SIGN_CHANGE_LOWER_BOUND_AND_PARTITION',
    'cofactors': 'PASS_EXACT_DETERMINANT_IDENTITIES',
    'reconstruction_factors': 'PASS_EXACT_RECONSTRUCTION_FACTOR_AND_UNIT_IDENTITIES',
    'circuit_structure': 'PASS_LITERAL_FORMULA_BINDING', 'circuit': 'PASS'}

def require(ok, message):
    if not ok:
        raise RuntimeError(message)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write_json(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')

def protected_paths(root):
    paths = [root/'verify.py', root/'requirements.txt', root/'supplement.tex']
    for directory in ('audit', 'certificates', 'sections'):
        paths.extend(p for p in (root/directory).rglob('*') if p.is_file())
    return sorted(paths)

def verify_inputs(root):
    catalog = json.loads((root/'inputs.json').read_text())
    expected = catalog['files']
    actual = {p.relative_to(root).as_posix(): digest(p) for p in protected_paths(root)}
    require(actual == expected, 'input catalog mismatch: changed, missing or extra proof input')
    require(len([p for p in expected if p.startswith('certificates/')]) == 142,
            'complete 142-file coefficient inventory')
    for rel in expected:
        p = root/rel
        require(not p.is_symlink() and p.resolve().is_relative_to(root.resolve()),
                'proof inputs must be regular internal files: ' + rel)
    return actual

def environment():
    require(sys.version_info >= (3, 10), 'Python 3.10 or newer required; tested with 3.12.14')
    import sympy
    import flint
    require(sympy.__version__ == '1.14.0', 'install sympy==1.14.0 from requirements.txt')
    require(flint.__version__ == '0.9.0', 'install python-flint==0.9.0 from requirements.txt')
    return {'python': sys.version, 'sympy': sympy.__version__,
            'python_flint': flint.__version__,
            'flint': getattr(flint, '__FLINT_VERSION__', None)}

def execute(script, arguments, target, expected_status, optimized, env, cwd, fresh_parent=False):
    require(not target.exists(), 'old output is forbidden: ' + str(target))
    if fresh_parent:
        require(not target.parent.exists(), 'job directory must be new: ' + str(target.parent))
        target.parent.parent.mkdir(parents=True, exist_ok=True)
        log = target.parent.parent/(target.parent.name+'.driver.log')
    else:
        target.parent.mkdir(parents=True, exist_ok=True)
        log = target.with_suffix('.log')
    require(not log.exists(), 'old log is forbidden: ' + str(log))
    command = [sys.executable, '-B'] + (['-O'] if optimized else [])
    command += [str(script)] + list(map(str, arguments))
    started = time.monotonic()
    print('RUN', target.parent.name + '/' + target.stem, flush=True)
    with log.open('wb') as handle:
        process = subprocess.run(command, stdout=handle, stderr=subprocess.STDOUT,
                                 env=env, cwd=cwd)
    require(process.returncode == 0, 'child failed; inspect ' + str(log))
    require(target.is_file(), 'successful child produced no new receipt: ' + str(target))
    result = json.loads(target.read_text())
    require(result.get('status') == expected_status,
            'wrong or reduced-scope result for ' + target.name + ': ' + str(result.get('status')))
    print('PASS', target.parent.name + '/' + target.stem, flush=True)
    return {'script': 'audit/' + script.name, 'script_sha256': digest(script),
            'exit_code': process.returncode, 'result': target.name,
            'result_sha256': digest(target), 'log': log.name,
            'log_sha256': digest(log), 'elapsed_seconds': round(time.monotonic()-started, 3)}

def run_mode(work, output, optimized, workers):
    mode = 'optimized' if optimized else 'normal'
    out = output/mode
    out.mkdir()
    audit, data = work/'audit', work/'certificates/centre'
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', QLC_VERIFY_WORKERS=str(workers))
    jobs = []
    geometry = [
        ('components', 'geometry_components.py', [work/'sections/geometry.tex']),
        ('ring', 'geometry_ring.py', [work/'sections/geometry.tex']),
        ('blocks', 'geometry_blocks.py', [work/'certificates/geometry']),
        ('source_binding', 'geometry_source_binding.py', [work]),
        ('centre_binding', 'geometry_centre_binding.py', [work]),
        ('original_qlc', 'qlc_original_replay.py', [work])]
    for name, script, args in geometry:
        target = out/'geometry'/(name+'.json')
        jobs.append(execute(audit/script, args+[target], target, 'PASS', optimized, env, work))
    target = out/'generic_sign'/'compact_top_sign.json'
    jobs.append(execute(audit/'compact_top_sign.py', [work, target], target,
                        'PASS', optimized, env, work))
    generic = out/'generic'
    target = generic/'generic_replay.json'
    require(not generic.exists(), 'generic output must not preexist')
    jobs.append(execute(audit/'generic_certificate.py', ['--output', generic],
                        target, 'PASS', optimized, env, work, fresh_parent=True))
    centre = [
        ('quadratic', 'centre_quadratic.py', [data, data, None, data]),
        ('coprime', 'centre_coprime.py', [data, None]),
        ('sylvester101', 'centre_sylvester_mod101.py', [data, None]),
        ('modular', 'centre_modular.py', [data, data/'candidate_mod101.json', None]),
        ('resultant', 'centre_resultant.py', [data, data/'eliminant_certificate.json', None]),
        ('factor', 'centre_factor.py', [data/'eliminant_certificate.json', data/'candidate_mod101.json', data/'minimal_polynomial.json', None]),
        ('descartes', 'centre_descartes.py', [data/'minimal_polynomial.json', data/'descartes_partition.json', None]),
        ('endpoints', 'centre_endpoints.py', [data/'minimal_polynomial.json', data/'descartes_partition.json', None]),
        ('cofactors', 'centre_cofactors.py', [data, data/'cofactor_certificate.json', None]),
        ('reconstruction_factors', 'centre_reconstruction_factors.py', [data/'cofactor_certificate.json', data/'candidate_mod101.json', data/'minimal_polynomial.json', data/'u2_reconstruction.json', None]),
        ('circuit_structure', 'centre_circuit_structure.py', [data, None]),
        ('circuit', 'centre_circuit.py', [data, None])]
    for name, script, args in centre:
        target = out/'centre'/(name+'.json')
        jobs.append(execute(audit/script, [target if a is None else a for a in args],
                            target, CENTRE_STATUSES[name], optimized, env, work))
    require(len(jobs) == 20, 'all twenty fresh proof jobs required in each mode')
    for name in GENERIC_RESULTS:
        require(json.loads((generic/name).read_text()).get('status') == 'PASS',
                'missing generic mathematical result: ' + name)
    require(set(p.name for p in generic.glob('*.json')) == set(GENERIC_RESULTS) | {'generic_replay.json'},
            'unexpected generic result set')
    jobs[7]['children_result_sha256'] = {name: digest(generic/name) for name in GENERIC_RESULTS}
    jobs[7]['children_log_sha256'] = {p.name: digest(p) for p in sorted(generic.glob('*.log'))}
    write_json(out/'JOBS.json', {'status': 'PASS', 'optimized_python': optimized, 'jobs': jobs})
    return jobs

def compare_modes(output):
    normal, optimized = output/'normal', output/'optimized'
    paths = sorted(p.relative_to(normal) for group in ('geometry', 'centre')
                   for p in (normal/group).glob('*.json'))
    paths += [Path('generic')/name for name in GENERIC_RESULTS]
    paths += [Path('generic_sign/compact_top_sign.json')]
    require(len(paths) == 28, 'all 28 mathematical result pairs required')
    equal = {}
    for rel in paths:
        equal[rel.as_posix()] = (normal/rel).read_bytes() == (optimized/rel).read_bytes()
        require(equal[rel.as_posix()], 'normal/optimized mathematics differs: ' + str(rel))
    return equal

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=Path, help='new output directory outside this package')
    parser.add_argument('--mode', choices=['both', 'normal', 'optimized'], default='both')
    parser.add_argument('--workers', type=int, choices=range(1, 5), default=1,
                        help='parallel generic jobs; default1 for predictable memory use')
    args = parser.parse_args()
    output = args.output.resolve()
    require(not output.exists(), 'output directory already exists; choose a new one')
    require(not output.is_relative_to(ROOT), 'output must be outside the source package')
    before = verify_inputs(ROOT)
    installed = environment()
    output.mkdir(parents=True)
    started = time.monotonic()
    report = {'status': 'RUNNING', 'schema': 'qlc512204-reproduction-v1',
              'environment': installed, 'requested_mode': args.mode,
              'started_utc': datetime.now(timezone.utc).isoformat(),
              'workers': args.workers, 'proof_inputs_sha256': before}
    write_json(output/'RESULT.json', report)
    try:
        with tempfile.TemporaryDirectory(prefix='qlc-supplement-') as temp:
            work = Path(temp)/'source'
            work.mkdir()
            for rel in before:
                dest = work/rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(ROOT/rel, dest)
            # No evidence/, reviews/, old checks or reference verdicts enter this workspace.
            from audit.model_join import check
            join = check(work)
            require(join.get('status') == 'PASS', 'global model join failed')
            write_json(output/'MODEL_JOIN.json', join)
            modes = [False, True] if args.mode == 'both' else [args.mode == 'optimized']
            report['jobs'] = {}
            for optimized in modes:
                name = 'optimized' if optimized else 'normal'
                report['jobs'][name] = run_mode(work, output, optimized, args.workers)
            report['normal_optimized_mathematical_results_equal'] = compare_modes(output) if len(modes) == 2 else None
            require({rel: digest(work/rel) for rel in before} == before,
                    'staged proof input changed during arithmetic execution')
        require(verify_inputs(ROOT) == before, 'source input tree changed during replay')
        report.update(status='PASS', source_tree_unchanged=True,
                      all_required_proof_jobs_freshly_executed=True,
                      previous_outputs_used_as_inputs=False,
                      elapsed_seconds=round(time.monotonic()-started, 3),
                      scope='Exact coefficient certificates; the included written scheme, properness, length, Hensel and real-structure arguments remain essential.')
    except BaseException as error:
        report.update(status='FAIL', error=str(error), elapsed_seconds=round(time.monotonic()-started, 3))
        write_json(output/'RESULT.json', report)
        raise
    write_json(output/'RESULT.json', report)
    print('PASS complete exact certificate chain; see ' + str(output/'RESULT.json'), flush=True)

if __name__ == '__main__':
    main()
