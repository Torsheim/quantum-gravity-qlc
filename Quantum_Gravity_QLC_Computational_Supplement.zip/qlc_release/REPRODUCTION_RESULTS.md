# Current release: article 0.13 / supplement 2.3

30 October 2026. The complete documented command was executed freshly
in normal and optimized Python with a new output directory.

- Exit code: 0. Wall time: 733.118 seconds.
- Fresh normal jobs:20; fresh optimized jobs:20.
- Mathematical result pairs:28, all byte-identical.
- Fresh worked connection:completed.
- Python3.12.14, SymPy1.14.0, python-flint0.9.0, native FLINT3.6.0;
  mpmath1.3.0 is pinned for the example helper.
- All files in the release tree remained unchanged during this execution.
- All175 current protected counting inputs match this fresh replay exactly.

The complete receipt is evidence/replay/RESULT.json; counting and worked
example receipts are below that directory. Full resultant/cofactor checks
were used, with1193 resultant arguments and1152 arguments for each
cofactor determinant in each mode. No previous receipt is a proof input.

After this run, an unchanged AppendixA block was relocated within
manuscript.tex so that the AI disclosure immediately precedes References.
No supplement, coefficient, arithmetic implementation, requirement or
counting input changed in this final placement adjustment. The full
replay's exact source manifest is preserved at
evidence/replay_source_synchronization.json. Fresh final consistency and
the exact article-only source bridge are recorded in
evidence/release_source_check.json. This placement check is not falsely
presented as a second arithmetic run. The delivered reproduction command
checks the final manifest and can freshly rerun the complete chain.

Older receipts and administrative comparisons are preserved as historical
material in the full author archive, not as current scientific evidence.
The separate AW checker also ran freshly; evidence/aw_comparison.json
records its bounded exact checks. General scheme, properness, length,
Hensel and real-structure inferences remain written proof arguments.

## Subsequent AI-declaration wording update

The closing AI declaration and accompanying administrative text were
shortened at the author's request after the complete replay. The research
workflow disclosure and all mathematical text remain unchanged. No new
arithmetic replay is claimed for this wording-only update. All 175 protected
counting inputs still match the recorded complete replay exactly; the
updated final source manifest and source-consistency check bind this text.
